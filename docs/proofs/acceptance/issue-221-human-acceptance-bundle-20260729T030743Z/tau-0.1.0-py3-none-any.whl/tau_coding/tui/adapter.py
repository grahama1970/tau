"""Translate agent events into Textual TUI display state."""

from math import ceil

from tau_agent import (
    AgentEndEvent,
    AgentEvent,
    AgentStartEvent,
    ErrorEvent,
    MessageDeltaEvent,
    MessageEndEvent,
    MessageStartEvent,
    QueueUpdateEvent,
    RetryEvent,
    ThinkingDeltaEvent,
    ToolExecutionEndEvent,
    ToolExecutionStartEvent,
    ToolExecutionUpdateEvent,
)
from tau_coding.tui.state import ASSISTANT_LENGTH_STOP_ERROR_TEXT, TuiState


class TuiEventAdapter:
    """Apply portable agent events to mutable TUI display state."""

    def __init__(
        self,
        state: TuiState,
        *,
        extension_tool_sources: dict[str, str] | None = None,
        extension_tool_renderers: dict[str, object] | None = None,
    ) -> None:
        self.state = state
        self.extension_tool_sources = dict(extension_tool_sources or {})
        self.extension_tool_renderers = dict(extension_tool_renderers or {})

    def apply(self, event: AgentEvent) -> None:
        """Apply one agent event to the display state."""
        if isinstance(event, AgentStartEvent):
            self.state.running = True
            self.state.error = None
            return

        if isinstance(event, AgentEndEvent):
            self._flush_assistant_buffer()
            self.state.running = False
            return

        if isinstance(event, MessageStartEvent):
            if event.message_role == "assistant":
                self.state.assistant_buffer = ""
            return

        if isinstance(event, MessageDeltaEvent):
            self.state.assistant_buffer += event.delta
            return

        if isinstance(event, ThinkingDeltaEvent):
            self.state.add_thinking_delta(event.delta)
            return

        if isinstance(event, QueueUpdateEvent):
            self.state.update_queue(steering=event.steering, follow_up=event.follow_up)
            return

        if isinstance(event, MessageEndEvent):
            if event.message.role == "user":
                self.state.add_user_message(event.message.content)
                return
            if event.message.role == "tool":
                return
            text = event.message.content or self.state.assistant_buffer
            if text:
                self.state.add_item("assistant", text)
            if event.message.finish_reason == "length":
                self.state.add_item("error", ASSISTANT_LENGTH_STOP_ERROR_TEXT)
            self.state.assistant_buffer = ""
            return

        if isinstance(event, ToolExecutionStartEvent):
            self._flush_assistant_buffer()
            self.state.add_tool_call(
                event.tool_call,
                source=_extension_tool_source_label(
                    self.extension_tool_sources.get(event.tool_call.name)
                ),
                renderer=self.extension_tool_renderers.get(event.tool_call.name),
            )
            return

        if isinstance(event, ToolExecutionUpdateEvent):
            self._apply_pipeline_stage(event)
            self._apply_loop_monitor_status(event)
            self.state.add_item("tool", f"… {event.message}")
            return

        if isinstance(event, RetryEvent):
            self.state.add_item("status", _retry_status_message(event))
            return

        if isinstance(event, ToolExecutionEndEvent):
            self.state.record_tool_result_with_renderer(
                event.result,
                renderer=self.extension_tool_renderers.get(event.result.name),
            )
            return

        if isinstance(event, ErrorEvent):
            self._flush_assistant_buffer()
            if event.recoverable and event.message == "Agent run cancelled":
                self.state.add_item("status", "Agent run cancelled.")
                return
            self.state.error = event.message
            self.state.add_item("error", f"Error: {event.message}")
            if not event.recoverable:
                self.state.running = False

    def _flush_assistant_buffer(self) -> None:
        if self.state.assistant_buffer:
            self.state.add_item("assistant", self.state.assistant_buffer)
            self.state.assistant_buffer = ""

    def _apply_pipeline_stage(self, event: ToolExecutionUpdateEvent) -> None:
        if event.data is None:
            return
        stage = event.data.get("memory_stage")
        if stage is None:
            stage = event.data.get("pipeline_stage")
        if stage is None:
            stage = event.data.get("stage")
        if isinstance(stage, str):
            self.state.set_thinking_status(stage)

    def _apply_loop_monitor_status(self, event: ToolExecutionUpdateEvent) -> None:
        if event.data is None:
            return
        monitor_status = event.data.get("loop2_monitor")
        if monitor_status is None:
            monitor_status = event.data.get("tau_loop_monitor")
        self.state.set_loop_monitor_status_from_payload(monitor_status)


def _retry_status_message(event: RetryEvent) -> str:
    seconds = max(0, ceil(event.delay_seconds))
    return f"Retrying ({event.attempt}/{event.max_attempts}) in {seconds}s... (Escape to cancel)"


def _extension_tool_source_label(extension_name: str | None) -> str | None:
    if extension_name is None:
        return None
    return f"extension:{extension_name}"
