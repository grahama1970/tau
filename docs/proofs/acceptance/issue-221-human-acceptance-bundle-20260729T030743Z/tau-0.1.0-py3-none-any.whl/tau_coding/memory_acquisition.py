"""Graph Memory acquisition receipts for Tau DAG dispatch inputs."""

from __future__ import annotations

import hashlib
import json
import os
import re
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

MEMORY_INTENT_ACQUISITION_RECEIPT_SCHEMA = "tau.memory_intent_acquisition_receipt.v1"
EVIDENCE_CASE_ACQUISITION_RECEIPT_SCHEMA = "tau.evidence_case_acquisition_receipt.v1"
SKILL_CHAIN_SELECTION_RECEIPT_SCHEMA = "tau.skill_chain_selection_receipt.v1"
TOOL_CHAIN_SELECTION_RECEIPT_SCHEMA = "tau.tool_chain_selection_receipt.v1"
DEFAULT_MEMORY_URL = "http://127.0.0.1:8601"


def write_memory_intent_acquisition_receipt(
    *,
    query: str,
    receipt_path: Path,
    memory_url: str | None = None,
    scope: str = "tau",
    app: str = "tau",
    fast: bool = True,
    goal_hash: str | None = None,
    target: dict[str, Any] | None = None,
    timeout_seconds: float = 15.0,
) -> dict[str, Any]:
    """Call Graph Memory /intent and bind request/response artifacts to a receipt."""

    if not query.strip():
        raise RuntimeError("--query must be non-empty")
    resolved_receipt = receipt_path.expanduser().resolve()
    response_path = resolved_receipt.with_name(f"{resolved_receipt.stem}-response.json")
    request_payload: dict[str, Any] = {
        "q": query,
        "scope": scope,
        "app": app,
        "fast": fast,
    }
    if goal_hash:
        request_payload["goal_hash"] = goal_hash
    if target:
        request_payload["target"] = target
    base_url = _memory_url(memory_url)
    response_payload, call = _post_json(
        memory_url=base_url,
        path="/intent",
        payload=request_payload,
        timeout_seconds=timeout_seconds,
    )
    alerts = _intent_alerts(response_payload, call)
    receipt = _receipt(
        schema=MEMORY_INTENT_ACQUISITION_RECEIPT_SCHEMA,
        receipt_path=resolved_receipt,
        memory_url=base_url,
        endpoint="/intent",
        request_payload=request_payload,
        response_payload=response_payload,
        response_path=response_path,
        call=call,
        alerts=alerts,
        goal_hash=goal_hash,
        target=target,
        proves=[
            "Tau called Graph Memory /intent and captured the observable response.",
            "Tau hashed the Memory request and response artifacts.",
            "Tau checked that the response is an observable memory intent artifact.",
        ],
        does_not_prove=[
            "Memory fact truth.",
            "Dispatch should proceed without the memory/evidence gate.",
            "Provider/model semantic quality.",
            "The evidence case exists.",
        ],
    )
    _write_json(response_path, response_payload)
    _write_json(resolved_receipt, receipt)
    return receipt


def write_evidence_case_acquisition_receipt(
    *,
    intent_path: Path,
    receipt_path: Path,
    memory_url: str | None = None,
    question: str | None = None,
    scope: str = "tau",
    app: str = "tau",
    goal_hash: str | None = None,
    target: dict[str, Any] | None = None,
    timeout_seconds: float = 15.0,
) -> dict[str, Any]:
    """Call Graph Memory /create-evidence-case for a previously captured intent."""

    resolved_intent = intent_path.expanduser().resolve()
    intent_payload = _read_json_object(resolved_intent, label="memory intent")
    resolved_receipt = receipt_path.expanduser().resolve()
    response_path = resolved_receipt.with_name(f"{resolved_receipt.stem}-response.json")
    request_payload: dict[str, Any] = {
        "intent": intent_payload,
        "scope": scope,
        "app": app,
    }
    if question:
        request_payload["question"] = question
    if goal_hash:
        request_payload["goal_hash"] = goal_hash
    if target:
        request_payload["target"] = target
    base_url = _memory_url(memory_url)
    response_payload, call = _post_json(
        memory_url=base_url,
        path="/create-evidence-case",
        payload=request_payload,
        timeout_seconds=timeout_seconds,
    )
    alerts = _evidence_case_alerts(response_payload, call)
    receipt = _receipt(
        schema=EVIDENCE_CASE_ACQUISITION_RECEIPT_SCHEMA,
        receipt_path=resolved_receipt,
        memory_url=base_url,
        endpoint="/create-evidence-case",
        request_payload=request_payload,
        response_payload=response_payload,
        response_path=response_path,
        call=call,
        alerts=alerts,
        goal_hash=goal_hash,
        target=target,
        extra={
            "intent_path": str(resolved_intent),
            "intent_sha256": f"sha256:{_sha256(resolved_intent)}",
        },
        proves=[
            "Tau called Graph Memory /create-evidence-case and captured the response.",
            "Tau hashed the source intent, request, and response artifacts.",
            "Tau checked that the response is an observable evidence-case artifact.",
        ],
        does_not_prove=[
            "Evidence-case semantic completeness.",
            "Memory fact truth.",
            "Dispatch should proceed without the memory/evidence gate.",
            "Provider/model semantic quality.",
        ],
    )
    _write_json(response_path, response_payload)
    _write_json(resolved_receipt, receipt)
    return receipt


def write_skill_chain_selection_receipt(
    *,
    query: str,
    receipt_path: Path,
    memory_url: str | None = None,
    scope: str = "tau",
    app: str = "tau",
    k: int = 5,
    goal_hash: str | None = None,
    target: dict[str, Any] | None = None,
    fallback_skills: Sequence[Mapping[str, Any]] = (),
    timeout_seconds: float = 15.0,
) -> dict[str, Any]:
    """Call Graph Memory /recall for skill-chain selection and write a Tau receipt."""

    if not query.strip():
        raise RuntimeError("--query must be non-empty")
    if k < 1:
        raise RuntimeError("--k must be at least 1")
    resolved_receipt = receipt_path.expanduser().resolve()
    response_path = resolved_receipt.with_name(f"{resolved_receipt.stem}-response.json")
    request_payload: dict[str, Any] = {
        "q": query,
        "scope": scope,
        "app": app,
        "k": k,
        "brief": True,
    }
    if goal_hash:
        request_payload["goal_hash"] = goal_hash
    if target:
        request_payload["target"] = target
    base_url = _memory_url(memory_url)
    response_payload, call = _post_json(
        memory_url=base_url,
        path="/recall",
        payload=request_payload,
        timeout_seconds=timeout_seconds,
    )
    receipt = _skill_chain_receipt(
        receipt_path=resolved_receipt,
        memory_url=base_url,
        request_payload=request_payload,
        response_payload=response_payload,
        response_path=response_path,
        call=call,
        fallback_skills=fallback_skills,
        goal_hash=goal_hash,
        target=target,
    )
    _write_json(response_path, response_payload)
    _write_json(resolved_receipt, receipt)
    return receipt


def write_tool_chain_selection_receipt(
    *,
    query: str,
    receipt_path: Path,
    memory_url: str | None = None,
    scope: str = "tau",
    app: str = "tau",
    k: int = 5,
    goal_hash: str | None = None,
    target: dict[str, Any] | None = None,
    timeout_seconds: float = 15.0,
) -> dict[str, Any]:
    """Call Graph Memory /recall for advisory tool-chain selection."""

    if not query.strip():
        raise RuntimeError("--query must be non-empty")
    if k < 1:
        raise RuntimeError("--k must be at least 1")
    resolved_receipt = receipt_path.expanduser().resolve()
    response_path = resolved_receipt.with_name(f"{resolved_receipt.stem}-response.json")
    request_payload: dict[str, Any] = {
        "q": query,
        "scope": scope,
        "app": app,
        "k": k,
        "brief": True,
        "collections": ["tool_chains"],
        "recommendation": "tool_chain",
    }
    if goal_hash:
        request_payload["goal_hash"] = goal_hash
    if target:
        request_payload["target"] = target
    base_url = _memory_url(memory_url)
    response_payload, call = _post_json(
        memory_url=base_url,
        path="/recall",
        payload=request_payload,
        timeout_seconds=timeout_seconds,
    )
    receipt = _tool_chain_receipt(
        receipt_path=resolved_receipt,
        memory_url=base_url,
        request_payload=request_payload,
        response_payload=response_payload,
        response_path=response_path,
        call=call,
        goal_hash=goal_hash,
        target=target,
    )
    _write_json(response_path, response_payload)
    _write_json(resolved_receipt, receipt)
    return receipt


def _receipt(
    *,
    schema: str,
    receipt_path: Path,
    memory_url: str,
    endpoint: str,
    request_payload: dict[str, Any],
    response_payload: dict[str, Any],
    response_path: Path,
    call: dict[str, Any],
    alerts: list[dict[str, Any]],
    goal_hash: str | None,
    target: dict[str, Any] | None,
    proves: list[str],
    does_not_prove: list[str],
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    status = "PASS" if not alerts else "BLOCKED"
    request_sha256 = _payload_sha256(request_payload)
    response_sha256 = _payload_sha256(response_payload)
    receipt: dict[str, Any] = {
        "schema": schema,
        "ok": status == "PASS",
        "status": status,
        "mocked": False,
        "live": True,
        "provider_live": False,
        "memory_url": memory_url,
        "endpoint": endpoint,
        "goal_hash": goal_hash,
        "target": target,
        "receipt_path": str(receipt_path),
        "request_sha256": f"sha256:{request_sha256}",
        "response_path": str(response_path),
        "response_sha256": f"sha256:{response_sha256}",
        "response_schema": response_payload.get("schema"),
        "call": call,
        "alert_codes": [alert["code"] for alert in alerts],
        "alerts": alerts,
        "proof_scope": {
            "proves": proves,
            "does_not_prove": does_not_prove,
        },
        "timestamp": _utc_stamp(),
    }
    if extra:
        receipt.update(extra)
    return receipt


def _tool_chain_receipt(
    *,
    receipt_path: Path,
    memory_url: str,
    request_payload: dict[str, Any],
    response_payload: dict[str, Any],
    response_path: Path,
    call: dict[str, Any],
    goal_hash: str | None,
    target: dict[str, Any] | None,
) -> dict[str, Any]:
    request_sha256 = _payload_sha256(request_payload)
    response_sha256 = _payload_sha256(response_payload)
    chain = _valid_tool_chain(response_payload.get("tool_chain"))
    alerts = _tool_chain_alerts(call=call, chain=chain)
    status = "PASS" if chain and not alerts else "DEGRADED"
    selected_tools = [tool["name"] for tool in chain["tools"]] if chain else []
    return {
        "schema": TOOL_CHAIN_SELECTION_RECEIPT_SCHEMA,
        "ok": status == "PASS",
        "status": status,
        "mocked": False,
        "live": call.get("ok") is True,
        "provider_live": False,
        "memory_url": memory_url,
        "endpoint": "/recall",
        "goal_hash": goal_hash,
        "target": target,
        "receipt_path": str(receipt_path),
        "request_payload": request_payload,
        "request_sha256": f"sha256:{request_sha256}",
        "response_path": str(response_path),
        "response_sha256": f"sha256:{response_sha256}",
        "response_schema": response_payload.get("schema"),
        "found": response_payload.get("found"),
        "should_scan": response_payload.get("should_scan"),
        "confidence": response_payload.get("confidence"),
        "tool_chain": chain,
        "selected_tools": selected_tools,
        "selection_source": "memory_recall_tool_chain" if chain else None,
        "advisory_only": True,
        "mutating_tools_invoked": [],
        "call": call,
        "alert_codes": [alert["code"] for alert in alerts],
        "alerts": alerts,
        "proof_scope": {
            "proves": [
                "Tau called Graph Memory /recall for a tool-chain recommendation.",
                "Tau captured and hashed the Memory request and response artifacts.",
                "Tau accepts only an explicit Memory tool_chain as a PASS recommendation.",
                "Tau verifies ordered traversal edges connect the returned tool sequence.",
                "Tau records the recommendation as advisory context and invokes no Tau tools.",
            ],
            "does_not_prove": [
                "Memory corpus completeness.",
                "Memory graph traversal implementation correctness.",
                "The selected tool sequence is semantically optimal.",
                "Any recommended tool was executed.",
            ],
        },
        "timestamp": _utc_stamp(),
    }


def _valid_tool_chain(value: object) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    tools = _normalize_tool_chain_tools(value.get("tools"))
    if not tools:
        return None
    traversal_path = value.get("traversal_path")
    if not isinstance(traversal_path, list):
        return None
    path = [edge for edge in traversal_path if isinstance(edge, dict)]
    if not _tool_edges_connect_chain([tool["name"] for tool in tools], path):
        return None
    chain = dict(value)
    chain["tools"] = tools
    chain["traversal_path"] = path
    chain["hop_count"] = int(value.get("hop_count", max(len(tools) - 1, 0)))
    return chain


def _normalize_tool_chain_tools(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    tools: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, str):
            name = item.strip()
            if name:
                tools.append({"name": name})
        elif isinstance(item, dict):
            name = str(item.get("name") or "").strip()
            if name:
                normalized = dict(item)
                normalized["name"] = name
                tools.append(normalized)
    return tools


def _tool_edges_connect_chain(tool_names: list[str], traversal_path: list[dict[str, Any]]) -> bool:
    if len(tool_names) == 1:
        return True
    expected_edges = list(zip(tool_names, tool_names[1:], strict=False))
    observed_edges = set()
    for edge in traversal_path:
        from_tool = str(edge.get("from_tool") or edge.get("from") or "")
        to_tool = str(edge.get("to_tool") or edge.get("to") or "")
        observed_edges.add((from_tool, to_tool))
    return all(edge in observed_edges for edge in expected_edges)


def _tool_chain_alerts(
    *,
    call: dict[str, Any],
    chain: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    alerts = _call_alerts(call)
    if chain:
        return alerts
    code = "memory_recall_unavailable" if alerts else "tool_chain_missing"
    severity = "BLOCK" if alerts else "WARN"
    alerts.append(
        _alert(
            code,
            "Graph Memory /recall did not return a usable tool_chain recommendation.",
            {"tool_chain_available": False},
            severity=severity,
        )
    )
    return alerts


def _skill_chain_receipt(
    *,
    receipt_path: Path,
    memory_url: str,
    request_payload: dict[str, Any],
    response_payload: dict[str, Any],
    response_path: Path,
    call: dict[str, Any],
    fallback_skills: Sequence[Mapping[str, Any]],
    goal_hash: str | None,
    target: dict[str, Any] | None,
) -> dict[str, Any]:
    request_sha256 = _payload_sha256(request_payload)
    response_sha256 = _payload_sha256(response_payload)
    chain = _valid_skill_chain(response_payload.get("skill_chain"))
    fallback = (
        None
        if chain
        else _registry_fallback_skill(str(request_payload["q"]), fallback_skills)
    )
    alerts = _skill_chain_alerts(call=call, chain=chain, fallback=fallback)
    status = "PASS" if chain and not alerts else "DEGRADED" if fallback else "BLOCKED"
    selected_skills = (
        list(chain["skills"]) if chain else [str(fallback["name"])] if fallback else []
    )
    selection_source = (
        "memory_recall_brief" if chain else "registry_fallback" if fallback else None
    )
    return {
        "schema": SKILL_CHAIN_SELECTION_RECEIPT_SCHEMA,
        "ok": status == "PASS",
        "status": status,
        "mocked": False,
        "live": call.get("ok") is True,
        "provider_live": False,
        "memory_url": memory_url,
        "endpoint": "/recall",
        "goal_hash": goal_hash,
        "target": target,
        "receipt_path": str(receipt_path),
        "request_payload": request_payload,
        "request_sha256": f"sha256:{request_sha256}",
        "response_path": str(response_path),
        "response_sha256": f"sha256:{response_sha256}",
        "response_schema": response_payload.get("schema"),
        "found": response_payload.get("found"),
        "should_scan": response_payload.get("should_scan"),
        "confidence": response_payload.get("confidence"),
        "skill_chain": chain,
        "selected_skills": selected_skills,
        "selection_source": selection_source,
        "fallback_skill": fallback,
        "call": call,
        "alert_codes": [alert["code"] for alert in alerts],
        "alerts": alerts,
        "proof_scope": {
            "proves": [
                "Tau called Graph Memory /recall with brief skill-chain selection intent.",
                "Tau captured and hashed the Memory request and response artifacts.",
                "Tau accepts only an explicit Memory skill_chain as a PASS selection.",
                "Tau degrades explicitly to a single registry fallback when Memory is "
                "unavailable or silent.",
            ],
            "does_not_prove": [
                "Memory fact truth.",
                "The selected chain is semantically optimal.",
                "The full Tau system prompt has switched all sessions to selected-only skills.",
                "Provider/model semantic quality.",
            ],
        },
        "timestamp": _utc_stamp(),
    }


def _valid_skill_chain(value: object) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    skills = value.get("skills")
    if not isinstance(skills, list) or not skills:
        return None
    normalized = [item.strip() for item in skills if isinstance(item, str) and item.strip()]
    if not normalized:
        return None
    path_value = value.get("traversal_path")
    if path_value is None:
        path_value = value.get("path")
    if not isinstance(path_value, list):
        return None
    path = [item for item in path_value if isinstance(item, dict)]
    if not _skill_path_matches_chain(normalized, path):
        return None
    try:
        hop_count = int(value.get("hop_count", value.get("hops", max(len(path) - 1, 0))))
    except (TypeError, ValueError):
        return None
    if hop_count < max(len(normalized) - 1, 0):
        return None
    chain = dict(value)
    chain["skills"] = normalized
    chain["traversal_path"] = path
    chain["path"] = path
    chain["hop_count"] = hop_count
    chain["hops"] = hop_count
    return chain


def _skill_path_matches_chain(skills: list[str], path: list[dict[str, Any]]) -> bool:
    if len(skills) == 1:
        return True
    path_nodes: list[str] = []
    for item in path:
        node = item.get("node", item.get("skill", item.get("name")))
        if isinstance(node, str) and node.strip():
            path_nodes.append(node.strip())
    return path_nodes[: len(skills)] == skills


def _skill_chain_alerts(
    *,
    call: dict[str, Any],
    chain: dict[str, Any] | None,
    fallback: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    alerts = _call_alerts(call)
    if chain:
        return alerts
    code = "memory_recall_unavailable" if alerts else "skill_chain_missing"
    message = (
        "Graph Memory /recall did not return a usable skill_chain; registry fallback selected."
        if fallback
        else "Graph Memory /recall did not return a usable skill_chain and no fallback "
        "skill was available."
    )
    severity = "WARN" if fallback else "BLOCK"
    alerts.append(
        _alert(
            code,
            message,
            {"fallback_available": fallback is not None},
            severity=severity,
        )
    )
    return alerts


def _registry_fallback_skill(
    query: str,
    fallback_skills: Sequence[Mapping[str, Any]],
) -> dict[str, Any] | None:
    best: tuple[int, int, Mapping[str, Any]] | None = None
    query_terms = set(_word_terms(query))
    for index, skill in enumerate(fallback_skills):
        name = str(skill.get("name") or "").strip()
        if not name:
            continue
        description = str(skill.get("description") or "")
        terms = set(_word_terms(f"{name} {description}"))
        score = len(query_terms & terms)
        candidate = (score, -index, skill)
        if best is None or candidate > best:
            best = candidate
    if best is None:
        return None
    selected = best[2]
    return {
        "name": str(selected.get("name")),
        "description": str(selected.get("description") or ""),
        "score": best[0],
    }


def _word_terms(value: str) -> list[str]:
    return [term for term in re.findall(r"[a-z0-9]+", value.lower()) if len(term) > 1]


def _post_json(
    *,
    memory_url: str,
    path: str,
    payload: dict[str, Any],
    timeout_seconds: float,
) -> tuple[dict[str, Any], dict[str, Any]]:
    started = datetime.now(UTC)
    try:
        with httpx.Client(
            base_url=memory_url.rstrip("/"),
            timeout=httpx.Timeout(timeout_seconds, connect=min(timeout_seconds, 5.0)),
        ) as client:
            response = client.post(path, json=payload)
    except httpx.HTTPError as exc:
        return {}, _call(path=path, ok=False, started=started, error=str(exc))
    call = _call(path=path, ok=response.status_code < 400, started=started)
    call["status_code"] = response.status_code
    try:
        body = response.json()
    except json.JSONDecodeError:
        call["ok"] = False
        call["error"] = "response was not JSON"
        return {"raw": response.text}, call
    if not isinstance(body, dict):
        call["ok"] = False
        call["error"] = "response JSON was not an object"
        return {"value": body}, call
    return body, call


def _call(
    *,
    path: str,
    ok: bool,
    started: datetime,
    error: str | None = None,
) -> dict[str, Any]:
    duration_seconds = (datetime.now(UTC) - started).total_seconds()
    call: dict[str, Any] = {
        "ok": ok,
        "path": path,
        "duration_seconds": duration_seconds,
    }
    if error:
        call["error"] = error
    return call


def _intent_alerts(payload: dict[str, Any], call: dict[str, Any]) -> list[dict[str, Any]]:
    alerts = _call_alerts(call)
    schema = payload.get("schema")
    if not alerts and (not isinstance(schema, str) or not schema.startswith("memory.")):
        alerts.append(
            _alert(
                "invalid_memory_intent_schema",
                "Memory /intent response must include a memory.* schema.",
                {"observed_schema": schema},
            )
        )
    if not alerts and payload.get("memory_first") is not True:
        alerts.append(
            _alert(
                "memory_first_required",
                "Memory /intent response must set memory_first true.",
            )
        )
    return alerts


def _evidence_case_alerts(payload: dict[str, Any], call: dict[str, Any]) -> list[dict[str, Any]]:
    alerts = _call_alerts(call)
    schema = payload.get("schema")
    if not alerts and (not isinstance(schema, str) or "evidence" not in schema):
        alerts.append(
            _alert(
                "invalid_evidence_case_schema",
                "Memory /create-evidence-case response must include an evidence-case schema.",
                {"observed_schema": schema},
            )
        )
    return alerts


def _call_alerts(call: dict[str, Any]) -> list[dict[str, Any]]:
    if call.get("ok") is True:
        return []
    code = "memory_http_error"
    if call.get("error") == "response was not JSON":
        code = "memory_non_json_response"
    elif call.get("error") == "response JSON was not an object":
        code = "memory_non_object_response"
    return [
        _alert(
            code,
            "Graph Memory acquisition call failed.",
            {"call": call},
        )
    ]


def _alert(
    code: str,
    message: str,
    evidence: dict[str, Any] | None = None,
    *,
    severity: str = "BLOCK",
) -> dict[str, Any]:
    alert: dict[str, Any] = {"severity": severity, "code": code, "message": message}
    if evidence:
        alert["evidence"] = evidence
    return alert


def _memory_url(memory_url: str | None) -> str:
    value = memory_url or os.environ.get("MEMORY_DAEMON_URL") or DEFAULT_MEMORY_URL
    return value.rstrip("/")


def _payload_sha256(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json_object(path: Path, *, label: str) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"{label} is unreadable: {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError(f"{label} must be a JSON object: {path}")
    return payload


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _utc_stamp() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
