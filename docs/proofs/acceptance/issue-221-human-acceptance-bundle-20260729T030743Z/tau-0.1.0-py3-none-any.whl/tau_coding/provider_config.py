"""Durable provider configuration for Tau coding sessions."""

import hashlib
import json
from collections.abc import Callable, Sequence
from contextlib import suppress
from dataclasses import dataclass, field, replace
from datetime import UTC, date, datetime
from json import dumps, loads
from os import environ
from pathlib import Path
from shutil import copy2
from tempfile import NamedTemporaryFile
from typing import Any, Protocol

import httpx

from tau_ai import (
    DEFAULT_ANTHROPIC_BASE_URL,
    DEFAULT_OPENAI_CODEX_BASE_URL,
    DEFAULT_OPENAI_COMPATIBLE_MAX_RETRIES,
    DEFAULT_OPENAI_COMPATIBLE_MAX_RETRY_DELAY_SECONDS,
    DEFAULT_OPENAI_COMPATIBLE_TIMEOUT_SECONDS,
    AnthropicConfig,
    OpenAICompatibleConfig,
    ProviderHttpHooks,
)
from tau_ai.env import DEFAULT_OPENAI_COMPATIBLE_BASE_URL
from tau_coding.credentials import FileCredentialStore, credentials_path
from tau_coding.memory_acquisition import DEFAULT_MEMORY_URL
from tau_coding.paths import TauPaths
from tau_coding.provider_catalog import BUILTIN_PROVIDER_CATALOG, ProviderKind
from tau_coding.thinking import (
    DEFAULT_THINKING_LEVEL,
    ThinkingLevel,
    ThinkingParameter,
    anthropic_thinking_budget_for_level,
    normalize_thinking_level,
    normalize_thinking_levels,
    reasoning_effort_for_level,
)

DEFAULT_PROVIDER_NAME = "openai"
ANTHROPIC_AUTH_TOKEN_ENV = "ANTHROPIC_AUTH_TOKEN"
RUNTIME_API_KEY_ENV = "TAU_RUNTIME_API_KEY"
DEFAULT_MODEL = "gpt-5.5"
PROVIDER_ROUTING_RECEIPT_SCHEMA = "tau.provider_routing_receipt.v1"
ANTHROPIC_ADAPTIVE_THINKING_MODELS = frozenset({"claude-opus-5"})
ANTHROPIC_ADAPTIVE_THINKING_LEVELS: tuple[ThinkingLevel, ...] = (
    "off",
    "low",
    "medium",
    "high",
    "xhigh",
)


class ProviderConfigError(ValueError):
    """Raised when Tau provider configuration is invalid."""


class CredentialReader(Protocol):
    """Credential lookup used while building runtime provider config."""

    def get(self, name: str) -> str | None: ...


@dataclass(frozen=True, slots=True)
class OpenAICompatibleProviderConfig:
    """Durable settings for one OpenAI-compatible provider."""

    name: str
    base_url: str = DEFAULT_OPENAI_COMPATIBLE_BASE_URL
    api_key_env: str = "OPENAI_API_KEY"
    credential_name: str | None = None
    models: tuple[str, ...] = (DEFAULT_MODEL,)
    default_model: str = DEFAULT_MODEL
    context_windows: dict[str, int] = field(default_factory=dict)
    model_knowledge_cutoffs: dict[str, date] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = DEFAULT_OPENAI_COMPATIBLE_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_OPENAI_COMPATIBLE_MAX_RETRIES
    max_retry_delay_seconds: float = DEFAULT_OPENAI_COMPATIBLE_MAX_RETRY_DELAY_SECONDS
    thinking_levels: tuple[ThinkingLevel, ...] | None = None
    thinking_models: tuple[str, ...] = ()
    thinking_default: ThinkingLevel | None = None
    thinking_parameter: ThinkingParameter | None = None

    def __post_init__(self) -> None:
        _validate_provider_numbers(
            timeout_seconds=self.timeout_seconds,
            max_retries=self.max_retries,
            max_retry_delay_seconds=self.max_retry_delay_seconds,
        )
        _validate_context_windows(self.context_windows)
        _validate_model_knowledge_cutoffs(self.model_knowledge_cutoffs)
        _validate_thinking_config(
            thinking_levels=self.thinking_levels,
            thinking_models=self.thinking_models,
            thinking_default=self.thinking_default,
            thinking_parameter=self.thinking_parameter,
        )

    def to_json(self) -> dict[str, Any]:
        """Serialize this provider config to JSON-compatible data."""
        return {
            "name": self.name,
            "type": "openai-compatible",
            "base_url": self.base_url,
            "api_key_env": self.api_key_env,
            "credential_name": self.credential_name,
            "models": list(self.models),
            "default_model": self.default_model,
            "context_windows": dict(self.context_windows),
            "model_knowledge_cutoffs": _date_dict_to_json(self.model_knowledge_cutoffs),
            "headers": dict(self.headers),
            "timeout_seconds": self.timeout_seconds,
            "max_retries": self.max_retries,
            "max_retry_delay_seconds": self.max_retry_delay_seconds,
            "thinking_levels": (
                list(self.thinking_levels) if self.thinking_levels is not None else None
            ),
            "thinking_models": list(self.thinking_models),
            "thinking_default": self.thinking_default,
            "thinking_parameter": self.thinking_parameter,
        }


@dataclass(frozen=True, slots=True)
class AnthropicProviderConfig:
    """Durable settings for Anthropic's Messages API."""

    name: str = "anthropic"
    base_url: str = DEFAULT_ANTHROPIC_BASE_URL
    api_key_env: str = "ANTHROPIC_API_KEY"
    credential_name: str | None = "anthropic"
    models: tuple[str, ...] = ("claude-sonnet-4-6",)
    default_model: str = "claude-sonnet-4-6"
    context_windows: dict[str, int] = field(default_factory=dict)
    model_knowledge_cutoffs: dict[str, date] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = DEFAULT_OPENAI_COMPATIBLE_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_OPENAI_COMPATIBLE_MAX_RETRIES
    max_retry_delay_seconds: float = DEFAULT_OPENAI_COMPATIBLE_MAX_RETRY_DELAY_SECONDS
    thinking_levels: tuple[ThinkingLevel, ...] | None = None
    thinking_models: tuple[str, ...] = ()
    thinking_default: ThinkingLevel | None = None
    thinking_parameter: ThinkingParameter | None = None

    def __post_init__(self) -> None:
        _validate_provider_numbers(
            timeout_seconds=self.timeout_seconds,
            max_retries=self.max_retries,
            max_retry_delay_seconds=self.max_retry_delay_seconds,
        )
        _validate_context_windows(self.context_windows)
        _validate_model_knowledge_cutoffs(self.model_knowledge_cutoffs)
        _validate_thinking_config(
            thinking_levels=self.thinking_levels,
            thinking_models=self.thinking_models,
            thinking_default=self.thinking_default,
            thinking_parameter=self.thinking_parameter,
        )

    def to_json(self) -> dict[str, Any]:
        """Serialize this provider config to JSON-compatible data."""
        return {
            "name": self.name,
            "type": "anthropic",
            "base_url": self.base_url,
            "api_key_env": self.api_key_env,
            "credential_name": self.credential_name,
            "models": list(self.models),
            "default_model": self.default_model,
            "context_windows": dict(self.context_windows),
            "model_knowledge_cutoffs": _date_dict_to_json(self.model_knowledge_cutoffs),
            "headers": dict(self.headers),
            "timeout_seconds": self.timeout_seconds,
            "max_retries": self.max_retries,
            "max_retry_delay_seconds": self.max_retry_delay_seconds,
            "thinking_levels": (
                list(self.thinking_levels) if self.thinking_levels is not None else None
            ),
            "thinking_models": list(self.thinking_models),
            "thinking_default": self.thinking_default,
            "thinking_parameter": self.thinking_parameter,
        }


@dataclass(frozen=True, slots=True)
class OpenAICodexProviderConfig:
    """Durable settings for OpenAI Codex subscription OAuth."""

    name: str = "openai-codex"
    base_url: str = DEFAULT_OPENAI_CODEX_BASE_URL
    api_key_env: str = "OPENAI_CODEX_ACCESS_TOKEN"
    credential_name: str | None = "openai-codex"
    models: tuple[str, ...] = (
        "gpt-5.5",
        "gpt-5.4",
        "gpt-5.4-mini",
        "gpt-5.3-codex",
        "gpt-5.3-codex-spark",
        "gpt-5.2",
    )
    default_model: str = "gpt-5.5"
    context_windows: dict[str, int] = field(default_factory=dict)
    model_knowledge_cutoffs: dict[str, date] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = DEFAULT_OPENAI_COMPATIBLE_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_OPENAI_COMPATIBLE_MAX_RETRIES
    max_retry_delay_seconds: float = DEFAULT_OPENAI_COMPATIBLE_MAX_RETRY_DELAY_SECONDS
    thinking_levels: tuple[ThinkingLevel, ...] | None = None
    thinking_models: tuple[str, ...] = ()
    thinking_default: ThinkingLevel | None = None
    thinking_parameter: ThinkingParameter | None = None

    def __post_init__(self) -> None:
        _validate_provider_numbers(
            timeout_seconds=self.timeout_seconds,
            max_retries=self.max_retries,
            max_retry_delay_seconds=self.max_retry_delay_seconds,
        )
        _validate_context_windows(self.context_windows)
        _validate_model_knowledge_cutoffs(self.model_knowledge_cutoffs)
        _validate_thinking_config(
            thinking_levels=self.thinking_levels,
            thinking_models=self.thinking_models,
            thinking_default=self.thinking_default,
            thinking_parameter=self.thinking_parameter,
        )

    def to_json(self) -> dict[str, Any]:
        """Serialize this provider config to JSON-compatible data."""
        return {
            "name": self.name,
            "type": "openai-codex",
            "base_url": self.base_url,
            "api_key_env": self.api_key_env,
            "credential_name": self.credential_name,
            "models": list(self.models),
            "default_model": self.default_model,
            "context_windows": dict(self.context_windows),
            "model_knowledge_cutoffs": _date_dict_to_json(self.model_knowledge_cutoffs),
            "headers": dict(self.headers),
            "timeout_seconds": self.timeout_seconds,
            "max_retries": self.max_retries,
            "max_retry_delay_seconds": self.max_retry_delay_seconds,
            "thinking_levels": (
                list(self.thinking_levels) if self.thinking_levels is not None else None
            ),
            "thinking_models": list(self.thinking_models),
            "thinking_default": self.thinking_default,
            "thinking_parameter": self.thinking_parameter,
        }


type ProviderConfig = (
    OpenAICompatibleProviderConfig | AnthropicProviderConfig | OpenAICodexProviderConfig
)


@dataclass(frozen=True, slots=True)
class ScopedModelConfig:
    """A provider/model pair enabled for quick model cycling."""

    provider: str
    model: str

    def to_json(self) -> dict[str, str]:
        """Serialize this scoped model reference."""
        return {"provider": self.provider, "model": self.model}


@dataclass(frozen=True, slots=True)
class ProviderSettings:
    """Tau provider settings loaded from Tau home."""

    default_provider: str = DEFAULT_PROVIDER_NAME
    providers: tuple[ProviderConfig, ...] = field(
        default_factory=lambda: builtin_provider_configs()
    )
    scoped_models: tuple[ScopedModelConfig, ...] = ()

    def get_provider(self, name: str | None = None) -> ProviderConfig:
        """Return a configured provider by name."""
        target = name or self.default_provider
        for provider in self.providers:
            if provider.name == target:
                return provider
        raise ProviderConfigError(f"Unknown provider: {target}")

    def to_json(self) -> dict[str, Any]:
        """Serialize these settings to JSON-compatible data."""
        return {
            "default_provider": self.default_provider,
            "providers": [provider.to_json() for provider in self.providers],
            "scoped_models": [model.to_json() for model in self.scoped_models],
        }


@dataclass(frozen=True, slots=True)
class ProviderSelection:
    """Resolved provider/model selection for a Tau run."""

    provider: ProviderConfig
    model: str


def builtin_provider_configs() -> tuple[ProviderConfig, ...]:
    """Return Tau's built-in provider configs."""
    return tuple(
        provider_config_from_catalog_entry(entry.name) for entry in BUILTIN_PROVIDER_CATALOG
    )


def provider_config_from_catalog_entry(name: str) -> ProviderConfig:
    """Create a durable provider config from a built-in catalog entry."""
    for entry in BUILTIN_PROVIDER_CATALOG:
        if entry.name != name:
            continue
        context_windows = dict(entry.context_windows or {})
        if entry.kind == "anthropic":
            return AnthropicProviderConfig(
                name=entry.name,
                base_url=entry.base_url,
                api_key_env=entry.api_key_env,
                credential_name=entry.credential_name,
                models=entry.models,
                default_model=entry.default_model,
                context_windows=context_windows,
                model_knowledge_cutoffs=_date_dict_from_catalog(entry.model_knowledge_cutoffs),
                thinking_levels=entry.thinking_levels,
                thinking_models=entry.thinking_models,
                thinking_default=entry.thinking_default,
                thinking_parameter=entry.thinking_parameter,
            )
        if entry.kind == "openai-codex":
            return OpenAICodexProviderConfig(
                name=entry.name,
                base_url=entry.base_url,
                api_key_env=entry.api_key_env,
                credential_name=entry.credential_name,
                models=entry.models,
                default_model=entry.default_model,
                context_windows=context_windows,
                model_knowledge_cutoffs=_date_dict_from_catalog(entry.model_knowledge_cutoffs),
                thinking_levels=entry.thinking_levels,
                thinking_models=entry.thinking_models,
                thinking_default=entry.thinking_default,
                thinking_parameter=entry.thinking_parameter,
            )
        return OpenAICompatibleProviderConfig(
            name=entry.name,
            base_url=entry.base_url,
            api_key_env=entry.api_key_env,
            credential_name=entry.credential_name,
            models=entry.models,
            default_model=entry.default_model,
            context_windows=context_windows,
            model_knowledge_cutoffs=_date_dict_from_catalog(entry.model_knowledge_cutoffs),
            thinking_levels=entry.thinking_levels,
            thinking_models=entry.thinking_models,
            thinking_default=entry.thinking_default,
            thinking_parameter=entry.thinking_parameter,
        )
    raise ProviderConfigError(f"Unknown built-in provider: {name}")


def default_openai_provider_config() -> OpenAICompatibleProviderConfig:
    """Return Tau's default OpenAI-compatible provider entry."""
    provider = provider_config_from_catalog_entry(DEFAULT_PROVIDER_NAME)
    if not isinstance(provider, OpenAICompatibleProviderConfig):
        raise AssertionError("default OpenAI provider must be OpenAI-compatible")
    return provider


def provider_settings_path(paths: TauPaths | None = None) -> Path:
    """Return the durable provider settings path."""
    return (paths or TauPaths()).home / "providers.json"


def load_provider_settings(paths: TauPaths | None = None) -> ProviderSettings:
    """Load durable provider settings, falling back to env-compatible defaults."""
    path = provider_settings_path(paths)
    if not path.exists():
        return ProviderSettings()
    raw = loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ProviderConfigError("Provider settings must be a JSON object")
    return _with_builtin_catalog_models(provider_settings_from_json(raw), paths=paths)


def save_provider_settings(settings: ProviderSettings, paths: TauPaths | None = None) -> Path:
    """Write durable provider settings and return the path."""
    path = provider_settings_path(paths)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        with suppress(OSError):
            copy2(path, path.with_suffix(path.suffix + ".bak"))
    _atomic_write_text(path, dumps(settings.to_json(), indent=2, sort_keys=True) + "\n")
    return path


def save_default_provider_model(
    *,
    provider_name: str,
    model: str,
    paths: TauPaths | None = None,
    fallback_settings: ProviderSettings | None = None,
) -> ProviderSettings:
    """Reload settings, persist one default provider/model change, and return them."""
    settings = _load_provider_settings_for_write(paths, fallback_settings=fallback_settings)
    updated = set_default_provider_model(settings, provider_name=provider_name, model=model)
    save_provider_settings(updated, paths)
    return updated


def toggle_saved_scoped_model(
    *,
    provider_name: str,
    model: str,
    paths: TauPaths | None = None,
    fallback_settings: ProviderSettings | None = None,
) -> ProviderSettings:
    """Reload settings, toggle one scoped model, persist them, and return them."""
    settings = _load_provider_settings_for_write(paths, fallback_settings=fallback_settings)
    existing = list(settings.scoped_models)
    target = ScopedModelConfig(provider=provider_name, model=model)
    if target in existing:
        updated = replace(
            settings,
            scoped_models=tuple(item for item in existing if item != target),
        )
        save_provider_settings(updated, paths)
        return updated

    provider = settings.get_provider(provider_name)
    if model not in provider.models:
        raise ProviderConfigError(f"Model is not configured: {provider_name}:{model}")

    existing.append(target)
    updated = replace(settings, scoped_models=tuple(existing))
    save_provider_settings(updated, paths)
    return updated


def set_saved_scoped_models(
    choices: tuple[ScopedModelConfig, ...],
    *,
    paths: TauPaths | None = None,
    fallback_settings: ProviderSettings | None = None,
) -> ProviderSettings:
    """Reload settings, replace scoped models, persist them, and return them."""
    settings = _load_provider_settings_for_write(paths, fallback_settings=fallback_settings)
    available = {
        (provider.name, model)
        for provider in settings.providers
        for model in provider.models
    }
    existing_unavailable = {
        (item.provider, item.model)
        for item in settings.scoped_models
        if (item.provider, item.model) not in available
    }
    scoped: list[ScopedModelConfig] = []
    seen: set[tuple[str, str]] = set()
    for choice in choices:
        key = (choice.provider, choice.model)
        if key not in available and key not in existing_unavailable:
            raise ProviderConfigError(
                f"Model is not configured: {choice.provider}:{choice.model}"
            )
        if key not in seen:
            scoped.append(choice)
            seen.add(key)
    updated = replace(settings, scoped_models=tuple(scoped))
    save_provider_settings(updated, paths)
    return updated


def upsert_saved_provider(
    provider: ProviderConfig,
    *,
    set_default: bool = False,
    paths: TauPaths | None = None,
    fallback_settings: ProviderSettings | None = None,
) -> ProviderSettings:
    """Reload settings, upsert one provider entry, persist them, and return them."""
    settings = _load_provider_settings_for_write(paths, fallback_settings=fallback_settings)
    updated = upsert_provider(settings, provider, set_default=set_default)
    save_provider_settings(updated, paths)
    return updated


def _load_provider_settings_for_write(
    paths: TauPaths | None,
    *,
    fallback_settings: ProviderSettings | None = None,
) -> ProviderSettings:
    """Load the latest on-disk settings, falling back only when no file exists."""
    if provider_settings_path(paths).exists():
        return load_provider_settings(paths)
    if fallback_settings is not None:
        return fallback_settings
    return load_provider_settings(paths)


def set_default_provider_model(
    settings: ProviderSettings,
    *,
    provider_name: str,
    model: str,
) -> ProviderSettings:
    """Return settings with the default provider/model preference updated."""
    provider = settings.get_provider(provider_name)
    models = provider.models if model in provider.models else (*provider.models, model)
    updated_provider = replace(provider, models=models, default_model=model)
    providers = tuple(
        updated_provider if item.name == provider_name else item for item in settings.providers
    )
    return ProviderSettings(
        default_provider=provider_name,
        providers=providers,
        scoped_models=settings.scoped_models,
    )


def upsert_openai_compatible_provider(
    settings: ProviderSettings,
    provider: OpenAICompatibleProviderConfig,
    *,
    set_default: bool = False,
) -> ProviderSettings:
    """Return settings with an OpenAI-compatible provider added or replaced."""
    return upsert_provider(settings, provider, set_default=set_default)


def upsert_provider(
    settings: ProviderSettings,
    provider: ProviderConfig,
    *,
    set_default: bool = False,
) -> ProviderSettings:
    """Return settings with a provider added or replaced."""
    providers_by_name = {item.name: item for item in settings.providers}
    builtin_names = {entry.name for entry in BUILTIN_PROVIDER_CATALOG}
    if provider.name in providers_by_name and provider.name in builtin_names:
        provider = _merge_provider_config(providers_by_name[provider.name], provider)
    providers_by_name[provider.name] = provider
    default_provider = provider.name if set_default else settings.default_provider
    providers = tuple(providers_by_name[name] for name in sorted(providers_by_name))
    updated = ProviderSettings(
        default_provider=default_provider,
        providers=providers,
        scoped_models=settings.scoped_models,
    )
    updated.get_provider(default_provider)
    return updated


def _with_builtin_catalog_models(
    settings: ProviderSettings,
    *,
    paths: TauPaths | None = None,
) -> ProviderSettings:
    """Return settings with current built-in model catalogs merged in."""
    builtin_configs = {
        provider.name: provider
        for provider in (
            provider_config_from_catalog_entry(entry.name) for entry in BUILTIN_PROVIDER_CATALOG
        )
    }
    providers = tuple(
        _merge_provider_config(provider, builtin_configs[provider.name])
        if provider.name in builtin_configs
        else provider
        for provider in settings.providers
    )
    providers = _append_credentialed_builtin_providers(providers, builtin_configs, paths=paths)
    default_provider = settings.default_provider
    if default_provider not in {provider.name for provider in providers}:
        default_provider = providers[0].name if providers else DEFAULT_PROVIDER_NAME
    return ProviderSettings(
        default_provider=default_provider,
        providers=providers,
        scoped_models=settings.scoped_models,
    )


def _append_credentialed_builtin_providers(
    providers: tuple[ProviderConfig, ...],
    builtin_configs: dict[str, ProviderConfig],
    *,
    paths: TauPaths | None,
) -> tuple[ProviderConfig, ...]:
    """Append built-in providers that already have stored Tau credentials."""
    credential_store = FileCredentialStore(credentials_path(paths) if paths else None)
    provider_names = {provider.name for provider in providers}
    appended = list(providers)
    for entry in BUILTIN_PROVIDER_CATALOG:
        provider = builtin_configs[entry.name]
        if provider.name in provider_names:
            continue
        if provider_has_usable_credentials(provider, credential_reader=credential_store):
            appended.append(provider)
            provider_names.add(provider.name)
    return tuple(appended)


def _merge_provider_config(existing: ProviderConfig, incoming: ProviderConfig) -> ProviderConfig:
    """Merge a replacement provider config without losing local customizations."""
    if type(existing) is not type(incoming):
        return incoming
    models = _unique_strings((*incoming.models, *existing.models))
    default_model = (
        existing.default_model if existing.default_model in models else incoming.default_model
    )
    headers = {**existing.headers, **incoming.headers}
    context_windows = {**incoming.context_windows, **existing.context_windows}
    model_knowledge_cutoffs = {
        **incoming.model_knowledge_cutoffs,
        **existing.model_knowledge_cutoffs,
    }
    thinking_levels = (
        existing.thinking_levels
        if existing.thinking_levels is not None
        else incoming.thinking_levels
    )
    thinking_models = (
        existing.thinking_models
        if existing.thinking_levels is not None
        else incoming.thinking_models
    )
    thinking_default = (
        existing.thinking_default
        if existing.thinking_levels is not None
        else incoming.thinking_default
    )
    thinking_parameter = (
        existing.thinking_parameter
        if existing.thinking_levels is not None
        else incoming.thinking_parameter
    )
    return replace(
        incoming,
        models=models,
        default_model=default_model,
        headers=headers,
        context_windows=context_windows,
        model_knowledge_cutoffs=model_knowledge_cutoffs,
        thinking_levels=thinking_levels,
        thinking_models=thinking_models,
        thinking_default=thinking_default,
        thinking_parameter=thinking_parameter,
    )


def _unique_strings(values: tuple[str, ...]) -> tuple[str, ...]:
    """Return values with duplicates removed while preserving order."""
    return tuple(dict.fromkeys(values))


def _atomic_write_text(path: Path, text: str) -> None:
    """Write text through a sibling temp file and atomically replace the target."""
    temp_path: Path | None = None
    try:
        with NamedTemporaryFile(
            "w",
            dir=path.parent,
            encoding="utf-8",
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as temp_file:
            temp_path = Path(temp_file.name)
            temp_file.write(text)
            temp_file.flush()
        temp_path.replace(path)
    except Exception:
        if temp_path is not None:
            with suppress(OSError):
                temp_path.unlink()
        raise


def provider_settings_from_json(data: dict[str, Any]) -> ProviderSettings:
    """Parse provider settings from JSON-compatible data."""
    default_provider = _string(data.get("default_provider"), "default_provider")
    providers_data = data.get("providers")
    if not isinstance(providers_data, list) or not providers_data:
        raise ProviderConfigError("Provider settings must include at least one provider")
    providers = tuple(_provider_from_json(item) for item in providers_data)
    names = [provider.name for provider in providers]
    if len(set(names)) != len(names):
        raise ProviderConfigError("Provider names must be unique")
    scoped_models = _scoped_models_from_json(data.get("scoped_models"))
    return ProviderSettings(
        default_provider=default_provider,
        providers=providers,
        scoped_models=scoped_models,
    )


def _scoped_models_from_json(value: object) -> tuple[ScopedModelConfig, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ProviderConfigError("Provider settings field must be a list: scoped_models")
    scoped: list[ScopedModelConfig] = []
    seen: set[tuple[str, str]] = set()
    for item in value:
        if not isinstance(item, dict):
            raise ProviderConfigError("Provider scoped_models entries must be objects")
        provider = _string(item.get("provider"), "scoped_models.provider")
        model = _string(item.get("model"), "scoped_models.model")
        key = (provider, model)
        if key not in seen:
            scoped.append(ScopedModelConfig(provider=provider, model=model))
            seen.add(key)
    return tuple(scoped)


def resolve_provider_selection(
    settings: ProviderSettings,
    *,
    provider_name: str | None = None,
    model: str | None = None,
) -> ProviderSelection:
    """Resolve the provider and model for a run."""
    if provider_name is None and model is not None:
        parsed = _provider_model_from_model_arg(settings, model)
        if parsed is not None:
            provider_name, model = parsed
    provider = settings.get_provider(provider_name)
    selected_model = model or provider.default_model
    if not selected_model:
        raise ProviderConfigError(f"Provider {provider.name} does not define a default model")
    return ProviderSelection(provider=provider, model=selected_model)


def _provider_model_from_model_arg(
    settings: ProviderSettings,
    model: str,
) -> tuple[str, str] | None:
    for separator in ("/", ":"):
        provider_prefix, found, model_name = model.partition(separator)
        if not found or not provider_prefix or not model_name:
            continue
        with suppress(ProviderConfigError):
            settings.get_provider(provider_prefix)
            return provider_prefix, model_name
    return None


def provider_thinking_levels(
    provider: ProviderConfig,
    *,
    model: str | None = None,
) -> tuple[ThinkingLevel, ...]:
    """Return thinking levels supported by a provider/model pair."""
    if provider.thinking_levels is None:
        return ()
    selected_model = model or provider.default_model
    if provider.thinking_models and selected_model not in provider.thinking_models:
        return ()
    if (
        isinstance(provider, AnthropicProviderConfig)
        and selected_model in ANTHROPIC_ADAPTIVE_THINKING_MODELS
    ):
        return tuple(
            level
            for level in ANTHROPIC_ADAPTIVE_THINKING_LEVELS
            if level in provider.thinking_levels
        )
    return provider.thinking_levels


def provider_thinking_unavailable_reason(
    provider: ProviderConfig,
    *,
    model: str | None = None,
) -> str | None:
    """Explain why a provider/model pair has no configurable thinking modes."""
    selected_model = model or provider.default_model
    if provider.thinking_levels is None:
        if isinstance(provider, OpenAICodexProviderConfig):
            return (
                "OpenAI Codex subscription can stream reasoning output, but Tau does "
                "not have a validated Codex transport mapping for changing reasoning "
                "effort yet"
            )
        return f"Provider {provider.name} does not declare thinking_levels"
    if provider.thinking_models and selected_model not in provider.thinking_models:
        return f"{provider.name}:{selected_model} is not declared in thinking_models"
    return None


def provider_default_thinking_level(
    provider: ProviderConfig,
    *,
    model: str | None = None,
) -> ThinkingLevel | None:
    """Return the preferred thinking level for a provider/model pair."""
    levels = provider_thinking_levels(provider, model=model)
    if not levels:
        return None
    if provider.thinking_default in levels:
        return provider.thinking_default
    if DEFAULT_THINKING_LEVEL in levels:
        return DEFAULT_THINKING_LEVEL
    return levels[0]


def provider_model_knowledge_cutoff(
    provider: ProviderConfig,
    *,
    model: str | None = None,
) -> date | None:
    """Return the explicitly configured knowledge cutoff for a provider/model."""

    return provider.model_knowledge_cutoffs.get(model or provider.default_model)


def openai_compatible_config_from_provider(
    provider: OpenAICompatibleProviderConfig,
    *,
    credential_reader: CredentialReader | None = None,
    model: str | None = None,
    thinking_level: ThinkingLevel | None = None,
    hooks: ProviderHttpHooks | None = None,
) -> OpenAICompatibleConfig:
    """Build OpenAI-compatible runtime config from durable settings."""
    api_key = _api_key_from_provider(provider, credential_reader=credential_reader)
    base_url = provider.base_url
    if provider.name == DEFAULT_PROVIDER_NAME and provider.api_key_env == "OPENAI_API_KEY":
        base_url = environ.get("OPENAI_BASE_URL", provider.base_url)
    reasoning_effort = _reasoning_effort_from_provider(
        provider,
        model=model,
        thinking_level=thinking_level,
    )
    return OpenAICompatibleConfig(
        api_key=api_key,
        base_url=base_url.rstrip("/"),
        headers=provider.headers,
        timeout_seconds=provider.timeout_seconds,
        max_retries=provider.max_retries,
        max_retry_delay_seconds=provider.max_retry_delay_seconds,
        reasoning_effort=reasoning_effort,
        reasoning_effort_parameter=provider.thinking_parameter or "reasoning_effort",
        hooks=hooks,
    )


def anthropic_config_from_provider(
    provider: AnthropicProviderConfig,
    *,
    credential_reader: CredentialReader | None = None,
    model: str | None = None,
    thinking_level: ThinkingLevel | None = None,
    hooks: ProviderHttpHooks | None = None,
) -> AnthropicConfig:
    """Build Anthropic runtime config from durable settings."""
    api_key, use_bearer_auth = _anthropic_auth_from_provider(
        provider,
        credential_reader=credential_reader,
    )
    thinking_budget_tokens = _anthropic_thinking_budget_from_provider(
        provider,
        model=model,
        thinking_level=thinking_level,
    )
    thinking_mode, thinking_effort = _anthropic_thinking_mode_from_provider(
        provider,
        model=model,
        thinking_level=thinking_level,
    )
    return AnthropicConfig(
        api_key=api_key,
        base_url=provider.base_url.rstrip("/"),
        headers=provider.headers,
        use_bearer_auth=use_bearer_auth,
        timeout_seconds=provider.timeout_seconds,
        max_retries=provider.max_retries,
        max_retry_delay_seconds=provider.max_retry_delay_seconds,
        thinking_budget_tokens=thinking_budget_tokens,
        thinking_mode=thinking_mode,
        thinking_effort=thinking_effort,
        hooks=hooks,
    )


def provider_kind(provider: ProviderConfig) -> ProviderKind:
    """Return the durable provider kind."""
    if isinstance(provider, AnthropicProviderConfig):
        return "anthropic"
    if isinstance(provider, OpenAICodexProviderConfig):
        return "openai-codex"
    return "openai-compatible"


def provider_has_usable_credentials(
    provider: ProviderConfig,
    *,
    credential_reader: CredentialReader | None = None,
) -> bool:
    """Return whether Tau can attempt calls for this provider without prompting setup."""
    if provider.credential_name and credential_reader is not None:
        if isinstance(provider, OpenAICodexProviderConfig):
            get_oauth = getattr(credential_reader, "get_oauth", None)
            if get_oauth is not None and get_oauth(provider.credential_name) is not None:
                return True
        elif credential_reader.get(provider.credential_name):
            return True
    if isinstance(provider, AnthropicProviderConfig) and environ.get(ANTHROPIC_AUTH_TOKEN_ENV):
        return True
    return bool(environ.get(provider.api_key_env))


def write_provider_routing_receipt(
    *,
    query: str,
    receipt_path: Path,
    candidates: Sequence[dict[str, Any]],
    invoke_provider: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    memory_url: str | None = None,
    scope: str = "tau",
    app: str = "tau",
    k: int = 5,
    timeout_seconds: float = 15.0,
) -> dict[str, Any]:
    """Recommend and optionally exercise provider failover with a typed receipt."""

    if not query.strip():
        raise RuntimeError("--query must be non-empty")
    if k < 1:
        raise RuntimeError("--k must be at least 1")
    resolved_receipt = receipt_path.expanduser().resolve()
    response_path = resolved_receipt.with_name(f"{resolved_receipt.stem}-response.json")
    request_payload = {
        "q": query,
        "scope": scope,
        "app": app,
        "k": k,
        "brief": True,
        "collections": ["provider_routes"],
        "recommendation": "provider_route",
    }
    base_url = _provider_router_memory_url(memory_url)
    memory_payload, memory_call = _provider_router_post_json(
        memory_url=base_url,
        path="/recall",
        payload=request_payload,
        timeout_seconds=timeout_seconds,
    )
    ordered_candidates = _provider_route_candidates(
        memory_route=memory_payload.get("provider_route"),
        candidates=candidates,
    )
    receipt = _provider_route_receipt(
        receipt_path=resolved_receipt,
        response_path=response_path,
        memory_url=base_url,
        request_payload=request_payload,
        memory_payload=memory_payload,
        memory_call=memory_call,
        ordered_candidates=ordered_candidates,
        invoke_provider=invoke_provider,
    )
    _provider_router_write_json(response_path, memory_payload)
    _provider_router_write_json(resolved_receipt, receipt)
    return receipt


def _provider_route_receipt(
    *,
    receipt_path: Path,
    response_path: Path,
    memory_url: str,
    request_payload: dict[str, Any],
    memory_payload: dict[str, Any],
    memory_call: dict[str, Any],
    ordered_candidates: list[dict[str, Any]],
    invoke_provider: Callable[[dict[str, Any]], dict[str, Any]] | None,
) -> dict[str, Any]:
    events: list[dict[str, Any]] = []
    alerts: list[dict[str, Any]] = []
    memory_route = _valid_provider_route(memory_payload.get("provider_route"))
    if memory_call.get("ok") is not True:
        alerts.append(
            _provider_router_alert(
                "memory_recall_unavailable",
                "Graph Memory /recall did not return provider routing evidence.",
                severity="WARN",
                evidence={"call": memory_call},
            )
        )
    elif memory_route is None:
        alerts.append(
            _provider_router_alert(
                "provider_route_missing",
                "Graph Memory /recall did not return provider_route evidence.",
                severity="WARN",
            )
        )
    eligible = [
        candidate for candidate in ordered_candidates if _provider_candidate_eligible(candidate)
    ]
    if not eligible:
        alerts.append(
            _provider_router_alert(
                "no_eligible_provider",
                "No configured provider candidate is eligible for routing.",
                evidence={"candidates": ordered_candidates},
            )
        )
        selected = None
        status = "BLOCKED"
    else:
        selected, status = _exercise_provider_candidates(
            eligible=eligible,
            events=events,
            invoke_provider=invoke_provider,
        )
        if status == "PASS" and alerts:
            status = "DEGRADED"
    return {
        "schema": PROVIDER_ROUTING_RECEIPT_SCHEMA,
        "ok": status == "PASS",
        "status": status,
        "mocked": False,
        "live": memory_call.get("ok") is True,
        "provider_live": invoke_provider is not None,
        "memory_url": memory_url,
        "endpoint": "/recall",
        "receipt_path": str(receipt_path),
        "request_payload": request_payload,
        "request_sha256": f"sha256:{_provider_router_payload_sha256(request_payload)}",
        "response_path": str(response_path),
        "response_sha256": f"sha256:{_provider_router_payload_sha256(memory_payload)}",
        "response_schema": memory_payload.get("schema"),
        "found": memory_payload.get("found"),
        "confidence": memory_payload.get("confidence"),
        "memory_route": memory_route,
        "candidates": ordered_candidates,
        "selected": selected,
        "events": events,
        "alert_codes": [alert["code"] for alert in alerts],
        "alerts": alerts,
        "proof_scope": {
            "proves": [
                "Tau asked Graph Memory for provider_route evidence through /recall.",
                "Tau filtered candidates by credential/quota eligibility.",
                "Tau records typed provider failover events for retryable 429/quota responses.",
                "Tau fails closed when no provider candidate is eligible.",
            ],
            "does_not_prove": [
                "Memory corpus completeness.",
                "Provider semantic quality.",
                "Production provider calls unless provider_live is true.",
                "SciLLM runtime dispatch has adopted this helper everywhere.",
            ],
        },
        "timestamp": _provider_router_utc_stamp(),
    }


def _exercise_provider_candidates(
    *,
    eligible: list[dict[str, Any]],
    events: list[dict[str, Any]],
    invoke_provider: Callable[[dict[str, Any]], dict[str, Any]] | None,
) -> tuple[dict[str, Any] | None, str]:
    for index, candidate in enumerate(eligible):
        events.append({"type": "provider_selected", "candidate": candidate, "attempt": index + 1})
        if invoke_provider is None:
            return candidate, "PASS"
        result = invoke_provider(candidate)
        events.append({"type": "provider_result", "candidate": candidate, "result": result})
        if result.get("ok") is True:
            return candidate, "PASS"
        if _provider_result_retryable(result) and index + 1 < len(eligible):
            events.append(
                {
                    "type": "provider_failover",
                    "from": candidate,
                    "to": eligible[index + 1],
                    "reason": result.get("error") or f"status_{result.get('status_code')}",
                }
            )
            continue
        return None, "BLOCKED"
    return None, "BLOCKED"


def _provider_result_retryable(result: dict[str, Any]) -> bool:
    status_code = result.get("status_code")
    if status_code in {408, 409, 425, 429}:
        return True
    if isinstance(status_code, int) and status_code >= 500:
        return True
    return result.get("error") in {"quota_exhausted", "rate_limited"}


def _provider_route_candidates(
    *,
    memory_route: object,
    candidates: Sequence[dict[str, Any]],
) -> list[dict[str, Any]]:
    by_key = {
        (str(candidate.get("provider")), str(candidate.get("model"))): dict(candidate)
        for candidate in candidates
    }
    ordered: list[dict[str, Any]] = []
    route = _valid_provider_route(memory_route)
    if route:
        for recommendation in route.get("candidates", []):
            key = (str(recommendation.get("provider")), str(recommendation.get("model")))
            candidate = by_key.pop(key, None)
            if candidate is None:
                continue
            candidate["memory_evidence"] = recommendation
            ordered.append(candidate)
    ordered.extend(by_key.values())
    return ordered


def _valid_provider_route(value: object) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    candidates = value.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        return None
    normalized = []
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        provider = str(candidate.get("provider") or "").strip()
        model = str(candidate.get("model") or "").strip()
        if provider and model:
            item = dict(candidate)
            item["provider"] = provider
            item["model"] = model
            normalized.append(item)
    if not normalized:
        return None
    route = dict(value)
    route["candidates"] = normalized
    return route


def _provider_candidate_eligible(candidate: dict[str, Any]) -> bool:
    return bool(candidate.get("credential_ok", True)) and not bool(
        candidate.get("quota_exhausted", False)
    )


def _provider_router_post_json(
    *,
    memory_url: str,
    path: str,
    payload: dict[str, Any],
    timeout_seconds: float,
) -> tuple[dict[str, Any], dict[str, Any]]:
    started = datetime.now(UTC)
    try:
        with httpx.Client(
            base_url=memory_url.rstrip("/"),
            timeout=httpx.Timeout(timeout_seconds, connect=min(timeout_seconds, 5.0)),
        ) as client:
            response = client.post(path, json=payload)
    except httpx.HTTPError as exc:
        return {}, _provider_router_call(path=path, ok=False, started=started, error=str(exc))
    call = _provider_router_call(path=path, ok=response.status_code < 400, started=started)
    call["status_code"] = response.status_code
    try:
        body = response.json()
    except json.JSONDecodeError:
        call["ok"] = False
        call["error"] = "response was not JSON"
        return {"raw": response.text}, call
    if not isinstance(body, dict):
        call["ok"] = False
        call["error"] = "response JSON was not an object"
        return {"value": body}, call
    return body, call


def _provider_router_call(
    *,
    path: str,
    ok: bool,
    started: datetime,
    error: str | None = None,
) -> dict[str, Any]:
    call: dict[str, Any] = {
        "ok": ok,
        "path": path,
        "duration_seconds": (datetime.now(UTC) - started).total_seconds(),
    }
    if error:
        call["error"] = error
    return call


def _provider_router_alert(
    code: str,
    message: str,
    *,
    severity: str = "BLOCK",
    evidence: dict[str, Any] | None = None,
) -> dict[str, Any]:
    alert: dict[str, Any] = {"severity": severity, "code": code, "message": message}
    if evidence:
        alert["evidence"] = evidence
    return alert


def _provider_router_memory_url(memory_url: str | None) -> str:
    return (memory_url or environ.get("MEMORY_DAEMON_URL") or DEFAULT_MEMORY_URL).rstrip("/")


def _provider_router_payload_sha256(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _provider_router_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _provider_router_utc_stamp() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _reasoning_effort_from_provider(
    provider: OpenAICompatibleProviderConfig,
    *,
    model: str | None,
    thinking_level: ThinkingLevel | None,
) -> str | None:
    if thinking_level is None or provider.thinking_parameter not in {
        "reasoning_effort",
        "reasoning.effort",
    }:
        return None

    levels = provider_thinking_levels(provider, model=model)
    if not levels:
        return None

    normalized = normalize_thinking_level(thinking_level)
    if normalized not in levels:
        selected_model = model or provider.default_model
        available = ", ".join(levels)
        raise ProviderConfigError(
            f"Thinking mode {normalized} is not available for "
            f"{provider.name}:{selected_model}. Available modes: {available}"
        )
    return reasoning_effort_for_level(normalized)


def _anthropic_thinking_budget_from_provider(
    provider: AnthropicProviderConfig,
    *,
    model: str | None,
    thinking_level: ThinkingLevel | None,
) -> int | None:
    if thinking_level is None or provider.thinking_parameter != "anthropic.thinking":
        return None

    selected_model = model or provider.default_model
    if selected_model in ANTHROPIC_ADAPTIVE_THINKING_MODELS:
        return None

    levels = provider_thinking_levels(provider, model=selected_model)
    if not levels:
        return None

    normalized = normalize_thinking_level(thinking_level)
    if normalized not in levels:
        available = ", ".join(levels)
        raise ProviderConfigError(
            f"Thinking mode {normalized} is not available for "
            f"{provider.name}:{selected_model}. Available modes: {available}"
        )
    return anthropic_thinking_budget_for_level(normalized)


def _anthropic_thinking_mode_from_provider(
    provider: AnthropicProviderConfig,
    *,
    model: str | None,
    thinking_level: ThinkingLevel | None,
) -> tuple[str, str | None]:
    selected_model = model or provider.default_model
    if selected_model not in ANTHROPIC_ADAPTIVE_THINKING_MODELS:
        return "budget", None
    if thinking_level is None or provider.thinking_parameter != "anthropic.thinking":
        return "budget", None

    levels = provider_thinking_levels(provider, model=selected_model)
    if not levels:
        return "budget", None

    normalized = normalize_thinking_level(thinking_level)
    if normalized not in levels:
        available = ", ".join(levels)
        raise ProviderConfigError(
            f"Thinking mode {normalized} is not available for "
            f"{provider.name}:{selected_model}. Available modes: {available}"
        )
    if normalized == "off":
        return "disabled", None
    effort = "max" if normalized == "xhigh" else normalized
    return "adaptive", effort


def _provider_from_json(data: object) -> ProviderConfig:
    if not isinstance(data, dict):
        raise ProviderConfigError("Provider entries must be JSON objects")
    provider_type = _string(data.get("type"), "providers[].type")
    if provider_type not in {"openai-compatible", "anthropic", "openai-codex"}:
        raise ProviderConfigError(f"Unsupported provider type: {provider_type}")
    name = _string(data.get("name"), "providers[].name")
    base_url = _string(data.get("base_url"), f"providers[{name}].base_url").rstrip("/")
    api_key_env = _string(data.get("api_key_env"), f"providers[{name}].api_key_env")
    credential_name = _optional_string(
        data.get("credential_name"), f"providers[{name}].credential_name"
    )
    models = _string_tuple(data.get("models"), f"providers[{name}].models")
    default_model = _string(data.get("default_model"), f"providers[{name}].default_model")
    context_windows = _context_window_dict(
        data.get("context_windows", {}), f"providers[{name}].context_windows"
    )
    model_knowledge_cutoffs = _date_dict(
        data.get("model_knowledge_cutoffs", {}),
        f"providers[{name}].model_knowledge_cutoffs",
    )
    headers = _string_dict(data.get("headers", {}), f"providers[{name}].headers")
    timeout_seconds = _positive_float(
        data.get("timeout_seconds", DEFAULT_OPENAI_COMPATIBLE_TIMEOUT_SECONDS),
        f"providers[{name}].timeout_seconds",
    )
    max_retries = _non_negative_int(
        data.get("max_retries", DEFAULT_OPENAI_COMPATIBLE_MAX_RETRIES),
        f"providers[{name}].max_retries",
    )
    max_retry_delay_seconds = _non_negative_float(
        data.get(
            "max_retry_delay_seconds",
            DEFAULT_OPENAI_COMPATIBLE_MAX_RETRY_DELAY_SECONDS,
        ),
        f"providers[{name}].max_retry_delay_seconds",
    )
    thinking_levels = _optional_thinking_levels(
        data.get("thinking_levels"), f"providers[{name}].thinking_levels"
    )
    thinking_models = _optional_string_tuple(
        data.get("thinking_models"), f"providers[{name}].thinking_models"
    )
    thinking_default = _optional_thinking_level(
        data.get("thinking_default"), f"providers[{name}].thinking_default"
    )
    thinking_parameter = _optional_thinking_parameter(
        data.get("thinking_parameter"), f"providers[{name}].thinking_parameter"
    )
    if default_model not in models:
        models = (*models, default_model)
    if provider_type == "anthropic":
        return AnthropicProviderConfig(
            name=name,
            base_url=base_url,
            api_key_env=api_key_env,
            credential_name=credential_name,
            models=models,
            default_model=default_model,
            context_windows=context_windows,
            model_knowledge_cutoffs=model_knowledge_cutoffs,
            headers=headers,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries,
            max_retry_delay_seconds=max_retry_delay_seconds,
            thinking_levels=thinking_levels,
            thinking_models=thinking_models,
            thinking_default=thinking_default,
            thinking_parameter=thinking_parameter,
        )
    if provider_type == "openai-codex":
        return OpenAICodexProviderConfig(
            name=name,
            base_url=base_url,
            api_key_env=api_key_env,
            credential_name=credential_name,
            models=models,
            default_model=default_model,
            context_windows=context_windows,
            model_knowledge_cutoffs=model_knowledge_cutoffs,
            headers=headers,
            timeout_seconds=timeout_seconds,
            max_retries=max_retries,
            max_retry_delay_seconds=max_retry_delay_seconds,
            thinking_levels=thinking_levels,
            thinking_models=thinking_models,
            thinking_default=thinking_default,
            thinking_parameter=thinking_parameter,
        )
    return OpenAICompatibleProviderConfig(
        name=name,
        base_url=base_url,
        api_key_env=api_key_env,
        credential_name=credential_name,
        models=models,
        default_model=default_model,
        context_windows=context_windows,
        model_knowledge_cutoffs=model_knowledge_cutoffs,
        headers=headers,
        timeout_seconds=timeout_seconds,
        max_retries=max_retries,
        max_retry_delay_seconds=max_retry_delay_seconds,
        thinking_levels=thinking_levels,
        thinking_models=thinking_models,
        thinking_default=thinking_default,
        thinking_parameter=thinking_parameter,
    )


def _api_key_from_provider(
    provider: ProviderConfig,
    *,
    credential_reader: CredentialReader | None,
) -> str:
    runtime_api_key = environ.get(RUNTIME_API_KEY_ENV)
    if runtime_api_key:
        return runtime_api_key

    if provider.credential_name and credential_reader is not None:
        credential = credential_reader.get(provider.credential_name)
        if credential:
            return credential

    api_key = environ.get(provider.api_key_env)
    if api_key:
        return api_key
    credential_hint = f" or run /login {provider.name}" if provider.credential_name else ""
    raise RuntimeError(f"Missing provider API key. Set {provider.api_key_env}{credential_hint}.")


def _anthropic_auth_from_provider(
    provider: AnthropicProviderConfig,
    *,
    credential_reader: CredentialReader | None,
) -> tuple[str, bool]:
    runtime_api_key = environ.get(RUNTIME_API_KEY_ENV)
    if runtime_api_key:
        return runtime_api_key, False

    if provider.credential_name and credential_reader is not None:
        credential = credential_reader.get(provider.credential_name)
        if credential:
            return credential, False

    auth_token = environ.get(ANTHROPIC_AUTH_TOKEN_ENV)
    if auth_token:
        return auth_token, True

    api_key = environ.get(provider.api_key_env)
    if api_key:
        return api_key, False
    credential_hint = f" or run /login {provider.name}" if provider.credential_name else ""
    raise RuntimeError(
        "Missing provider API key. "
        f"Set {ANTHROPIC_AUTH_TOKEN_ENV} or {provider.api_key_env}{credential_hint}."
    )


def _validate_provider_numbers(
    *,
    timeout_seconds: float,
    max_retries: int,
    max_retry_delay_seconds: float,
) -> None:
    if isinstance(timeout_seconds, bool) or timeout_seconds <= 0:
        raise ProviderConfigError("Provider timeout_seconds must be greater than 0")
    if not isinstance(max_retries, int) or isinstance(max_retries, bool) or max_retries < 0:
        raise ProviderConfigError("Provider max_retries must be 0 or greater")
    if (
        not isinstance(max_retry_delay_seconds, int | float)
        or isinstance(max_retry_delay_seconds, bool)
        or max_retry_delay_seconds < 0
    ):
        raise ProviderConfigError("Provider max_retry_delay_seconds must be 0 or greater")


def _validate_context_windows(context_windows: dict[str, int]) -> None:
    for model, context_window in context_windows.items():
        if not isinstance(model, str) or not model.strip():
            raise ProviderConfigError("Provider context_windows keys must be non-empty strings")
        if (
            not isinstance(context_window, int)
            or isinstance(context_window, bool)
            or context_window <= 0
        ):
            raise ProviderConfigError("Provider context_windows values must be positive integers")


def _validate_model_knowledge_cutoffs(model_knowledge_cutoffs: dict[str, date]) -> None:
    for model, cutoff in model_knowledge_cutoffs.items():
        if not isinstance(model, str) or not model.strip():
            raise ProviderConfigError(
                "Provider model_knowledge_cutoffs keys must be non-empty strings"
            )
        if not isinstance(cutoff, date):
            raise ProviderConfigError("Provider model_knowledge_cutoffs values must be dates")


def _validate_thinking_config(
    *,
    thinking_levels: tuple[ThinkingLevel, ...] | None,
    thinking_models: tuple[str, ...],
    thinking_default: ThinkingLevel | None,
    thinking_parameter: ThinkingParameter | None,
) -> None:
    if thinking_levels is None:
        if thinking_models or thinking_default is not None or thinking_parameter is not None:
            raise ProviderConfigError(
                "Provider thinking_levels must be set before thinking metadata"
            )
        return
    try:
        normalized = normalize_thinking_levels(thinking_levels)
    except ValueError as exc:
        raise ProviderConfigError(str(exc)) from exc
    if normalized != thinking_levels:
        raise ProviderConfigError("Provider thinking_levels must be normalized")
    if any(not isinstance(model, str) or not model.strip() for model in thinking_models):
        raise ProviderConfigError("Provider thinking_models must contain non-empty strings")
    if thinking_default is not None and thinking_default not in thinking_levels:
        raise ProviderConfigError("Provider thinking_default must be in thinking_levels")
    if thinking_parameter not in {
        None,
        "reasoning_effort",
        "reasoning.effort",
        "anthropic.thinking",
    }:
        raise ProviderConfigError(
            "Provider thinking_parameter must be reasoning_effort, reasoning.effort, "
            "or anthropic.thinking"
        )


def _reject_unimplemented_thinking_config(
    *,
    provider_type: str,
    thinking_levels: tuple[ThinkingLevel, ...] | None,
) -> None:
    if thinking_levels is not None:
        raise ProviderConfigError(f"{provider_type} thinking controls are not implemented yet")


def _optional_string(value: object, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ProviderConfigError(f"Provider field must be a non-empty string: {field_name}")
    return value.strip()


def _string(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProviderConfigError(f"Provider field must be a non-empty string: {field_name}")
    return value.strip()


def _string_tuple(value: object, field_name: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value:
        raise ProviderConfigError(f"Provider field must be a non-empty string list: {field_name}")
    items = tuple(item.strip() for item in value if isinstance(item, str) and item.strip())
    if len(items) != len(value):
        raise ProviderConfigError(f"Provider field must be a string list: {field_name}")
    return items


def _optional_string_tuple(value: object, field_name: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ProviderConfigError(f"Provider field must be a string list: {field_name}")
    items = tuple(item.strip() for item in value if isinstance(item, str) and item.strip())
    if len(items) != len(value):
        raise ProviderConfigError(f"Provider field must be a string list: {field_name}")
    return items


def _optional_thinking_levels(
    value: object,
    field_name: str,
) -> tuple[ThinkingLevel, ...] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        raise ProviderConfigError(f"Provider field must be a thinking mode list: {field_name}")
    try:
        return normalize_thinking_levels(value)
    except ValueError as exc:
        raise ProviderConfigError(str(exc)) from exc


def _optional_thinking_level(value: object, field_name: str) -> ThinkingLevel | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ProviderConfigError(f"Provider field must be a thinking mode: {field_name}")
    try:
        return normalize_thinking_level(value)
    except ValueError as exc:
        raise ProviderConfigError(str(exc)) from exc


def _optional_thinking_parameter(
    value: object,
    field_name: str,
) -> ThinkingParameter | None:
    if value is None:
        return None
    if value == "reasoning_effort":
        return "reasoning_effort"
    if value == "reasoning.effort":
        return "reasoning.effort"
    if value == "anthropic.thinking":
        return "anthropic.thinking"
    raise ProviderConfigError(
        f"Provider field must be reasoning_effort, reasoning.effort, "
        f"or anthropic.thinking: {field_name}"
    )


def _string_dict(value: object, field_name: str) -> dict[str, str]:
    if not isinstance(value, dict):
        raise ProviderConfigError(f"Provider field must be a string object: {field_name}")
    items: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not key.strip():
            raise ProviderConfigError(f"Provider field must be a string object: {field_name}")
        if not isinstance(item, str) or not item.strip():
            raise ProviderConfigError(f"Provider field must be a string object: {field_name}")
        items[key.strip()] = item.strip()
    return items


def _context_window_dict(value: object, field_name: str) -> dict[str, int]:
    if not isinstance(value, dict):
        raise ProviderConfigError(f"Provider field must be an integer object: {field_name}")
    items: dict[str, int] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not key.strip():
            raise ProviderConfigError(f"Provider field must be an integer object: {field_name}")
        if not isinstance(item, int) or isinstance(item, bool) or item <= 0:
            raise ProviderConfigError(
                f"Provider field values must be positive integers: {field_name}"
            )
        items[key.strip()] = item
    return items


def _date_dict(value: object, field_name: str) -> dict[str, date]:
    if not isinstance(value, dict):
        raise ProviderConfigError(f"Provider field must be a date object: {field_name}")
    items: dict[str, date] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not key.strip():
            raise ProviderConfigError(f"Provider field must be a date object: {field_name}")
        if not isinstance(item, str) or not item.strip():
            raise ProviderConfigError(f"Provider field values must be ISO dates: {field_name}")
        try:
            parsed = date.fromisoformat(item.strip())
        except ValueError as exc:
            raise ProviderConfigError(
                f"Provider field values must be ISO dates: {field_name}"
            ) from exc
        items[key.strip()] = parsed
    return items


def _date_dict_from_catalog(value: dict[str, str] | None) -> dict[str, date]:
    if not value:
        return {}
    return _date_dict(value, "builtin.model_knowledge_cutoffs")


def _date_dict_to_json(value: dict[str, date]) -> dict[str, str]:
    return {model: cutoff.isoformat() for model, cutoff in value.items()}


def _positive_float(value: object, field_name: str) -> float:
    if not isinstance(value, int | float) or isinstance(value, bool):
        raise ProviderConfigError(f"Provider field must be a positive number: {field_name}")
    converted = float(value)
    if converted <= 0:
        raise ProviderConfigError(f"Provider field must be greater than 0: {field_name}")
    return converted


def _non_negative_int(value: object, field_name: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ProviderConfigError(f"Provider field must be a non-negative integer: {field_name}")
    if value < 0:
        raise ProviderConfigError(f"Provider field must be 0 or greater: {field_name}")
    return value


def _non_negative_float(value: object, field_name: str) -> float:
    if not isinstance(value, int | float) or isinstance(value, bool):
        raise ProviderConfigError(f"Provider field must be a non-negative number: {field_name}")
    converted = float(value)
    if converted < 0:
        raise ProviderConfigError(f"Provider field must be 0 or greater: {field_name}")
    return converted
