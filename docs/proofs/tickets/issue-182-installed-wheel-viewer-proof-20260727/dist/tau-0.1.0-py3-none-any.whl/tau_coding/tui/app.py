"""Minimal Textual app for Tau coding sessions."""

import asyncio
import base64
import binascii
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import webbrowser
from collections.abc import AsyncIterator, Callable, Mapping, Sequence
from contextlib import suppress
from dataclasses import dataclass, fields, replace
from datetime import datetime
from functools import partial
from html import unescape as html_unescape
from html.parser import HTMLParser
from inspect import isawaitable, signature
from io import StringIO
from math import ceil
from pathlib import Path
from time import monotonic
from typing import Any, ClassVar, Literal, Protocol, cast
from urllib.parse import parse_qsl, unquote, urlencode, urlparse, urlunparse

from rich.cells import cell_len
from rich.console import Console, Group, RenderableType
from rich.markdown import Markdown
from rich.padding import Padding
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from textual import events, on
from textual.app import App, ComposeResult
from textual.binding import Binding, BindingsMap
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.events import Key, Resize
from textual.geometry import Spacing
from textual.screen import ModalScreen
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import (
    Button,
    Footer,
    Header,
    Input,
    Label,
    ListItem,
    ListView,
    Static,
    TextArea,
)
from textual.worker import Worker

from tau_agent import (
    AgentEndEvent,
    AgentEvent,
    AgentStartEvent,
    ErrorEvent,
    MessageDeltaEvent,
    MessageEndEvent,
    MessageStartEvent,
    QueueUpdateEvent,
    RetryEvent,
    ThinkingDeltaEvent,
    ToolExecutionEndEvent,
    ToolExecutionStartEvent,
    ToolExecutionUpdateEvent,
)
from tau_agent.messages import AgentMessage
from tau_agent.tools import AgentTool
from tau_ai import ProviderErrorEvent, ProviderEvent
from tau_ai.provider import CancellationToken
from tau_coding.commands import (
    CommandRegistry,
    CommandResult,
    create_default_command_registry,
    daxnuts_easter_message,
)
from tau_coding.credentials import FileCredentialStore, OAuthCredential, credentials_path
from tau_coding.dag_viewer.projection import build_dag_live_snapshot, load_dag_replay
from tau_coding.dag_viewer.receipt_index import build_receipt_index
from tau_coding.dag_viewer.server import RunningDagViewerServer, create_dag_viewer_server
from tau_coding.oauth import OAuthAuthInfo, OAuthPrompt, login_openai_codex
from tau_coding.paths import TauPaths
from tau_coding.pending_decisions import (
    PendingDecision,
    collect_pending_decisions,
    pending_decision_lines,
    pending_decision_report,
)
from tau_coding.prompt_templates import PromptTemplate
from tau_coding.provider_catalog import (
    BUILTIN_PROVIDER_CATALOG,
    ProviderCatalogEntry,
    builtin_provider_entry,
)
from tau_coding.provider_config import (
    ANTHROPIC_AUTH_TOKEN_ENV,
    RUNTIME_API_KEY_ENV,
    ProviderConfig,
    ProviderSelection,
    ProviderSettings,
    load_provider_settings,
    provider_config_from_catalog_entry,
    provider_has_usable_credentials,
    provider_settings_path,
    resolve_provider_selection,
    upsert_saved_provider,
)
from tau_coding.provider_runtime import create_model_provider
from tau_coding.resources import TauResourcePaths
from tau_coding.run_status import build_dag_viewer_link
from tau_coding.session import (
    CodingSession,
    CodingSessionConfig,
    ModelChoice,
    SessionTreeBranchResult,
    SessionTreeChoice,
    jsonl_session_storage,
    parse_terminal_command,
)
from tau_coding.session_manager import CodingSessionRecord, SessionManager
from tau_coding.skills import Skill
from tau_coding.system_prompt import ProjectContextFile
from tau_coding.thinking import (
    DEFAULT_THINKING_LEVEL,
    THINKING_LEVEL_DESCRIPTIONS,
    THINKING_LEVELS,
    ThinkingLevel,
    next_thinking_level,
)
from tau_coding.trust import (
    DefaultProjectTrust,
    ProjectTrustOption,
    ProjectTrustState,
    ProjectTrustStore,
    ProjectTrustStoreEntry,
)
from tau_coding.tui.adapter import TuiEventAdapter
from tau_coding.tui.autocomplete import (
    CompletionItem,
    CompletionOption,
    CompletionState,
    build_completion_state,
    build_completion_state_async,
)
from tau_coding.tui.config import (
    DEFAULT_AUTOCOMPLETE_MAX_VISIBLE,
    DEFAULT_AUTOMATIC_TUI_THEME_SETTING,
    TAU_DARK_THEME,
    ProjectTuiSettings,
    TuiKeybindings,
    TuiQueueDrainMode,
    TuiSettings,
    TuiTheme,
    available_tui_theme_names,
    load_project_tui_settings,
    load_tui_settings,
    project_tui_settings_path,
    save_project_tui_settings,
    save_tui_settings,
    tui_settings_path,
)
from tau_coding.tui.file_drop import normalize_dropped_paths
from tau_coding.tui.pty_proof import pty_input_received_line, pty_ready_line
from tau_coding.tui.state import (
    ChatItem,
    ToolImagePayload,
    TuiState,
    format_terminal_command_result_block,
    format_terminal_command_running_block,
)
from tau_coding.tui.terminal_image import TerminalImage, TerminalImageOptions
from tau_coding.tui.terminal_notification import TerminalNotificationController
from tau_coding.tui.terminal_title import TerminalTitleController
from tau_coding.tui.widgets import (
    CompactSessionInfo,
    DagRunStatusPane,
    SessionSidebar,
    ThemedMarkdownWidget,
    TranscriptView,
    _git_branch,
    markdown_visual_payloads,
    render_completion_suggestions,
)
from tau_coding.workflows.catalog import get_workflow, list_workflows
from tau_coding.workflows.contracts import WorkflowDefinition

type BindingEntry = Binding | tuple[str, str] | tuple[str, str, str]
type SessionPickerSortMode = Literal["threaded", "recent", "relevance", "name"]
SIDEBAR_MIN_WIDTH = 96
SIDEBAR_MIN_HEIGHT = 24
ACTIVITY_TICK_SECONDS = 0.15
ACTIVITY_COLOR_FADE_STEPS = 24
ACTIVITY_INDICATOR_HEIGHT = 3
EXTENSION_BRANCH_WATCH_INTERVAL_SECONDS = 0.5
DAG_RUN_STATUS_POLL_SECONDS = 0.75
TERMINAL_PROGRESS_ACTIVE_SEQUENCE = "\x1b]9;4;3\x07"
TERMINAL_PROGRESS_CLEAR_SEQUENCE = "\x1b]9;4;0;\x07"
COMPLETION_MAX_VISIBLE_LINES = DEFAULT_AUTOCOMPLETE_MAX_VISIBLE
AUTOCOMPLETE_MAX_VISIBLE_CHOICES = (3, 5, 7, 10, 15, 20)
EDITOR_PADDING_X_CHOICES = (0, 1, 2, 3)
OUTPUT_PADDING_X_CHOICES = (0, 1)
IMAGE_WIDTH_CELL_CHOICES = (60, 80, 120)
HTTP_IDLE_TIMEOUT_MS_CHOICES = (60_000, 300_000, 600_000, 3_600_000, 0)
QUEUED_MESSAGE_PREVIEW_CHARS = 120
NO_STORED_CREDENTIALS_MESSAGE = (
    "No stored credentials to remove. /logout only removes credentials saved by /login; "
    "environment variables and providers.json config are unchanged."
)
ANTHROPIC_SUBSCRIPTION_AUTH_WARNING = (
    "Anthropic subscription auth is active. Third-party harness usage draws from extra usage "
    "and is billed per token, not your Claude plan limits. Manage extra usage at "
    "https://claude.ai/settings/usage."
)
ANTHROPIC_SUBSCRIPTION_AUTH_PREFIX = "sk-ant-oat"
TREE_RUNNING_MESSAGE = "Tau is already working. Press Escape to cancel before branching."


class LoginRequiredProvider:
    """Placeholder provider used so the TUI can open before login."""

    def __init__(self, message: str) -> None:
        self.message = message

    async def aclose(self) -> None:
        """Close provider resources."""

    def stream_response(
        self,
        *,
        model: str,
        system: str,
        messages: list[AgentMessage],
        tools: list[AgentTool],
        signal: CancellationToken | None = None,
    ) -> AsyncIterator[ProviderEvent]:
        """Surface a login-needed provider error."""
        del model, system, messages, tools, signal

        async def iterator() -> AsyncIterator[ProviderEvent]:
            yield ProviderErrorEvent(message=self.message)

        return iterator()


class CompletionActionTarget(Protocol):
    """App actions used by the prompt input completion bindings."""

    def action_accept_completion(self) -> None: ...

    def action_cancel(self) -> None: ...

    def action_completion_next(self) -> None: ...

    def action_completion_previous(self) -> None: ...

    def action_refresh_completions_for_cursor(self) -> None: ...

    def action_open_command_palette(self) -> None: ...

    def action_open_session_picker(self) -> None: ...

    def action_new_session(self) -> None: ...

    def action_open_tree_picker(self) -> None: ...

    def action_open_fork_picker(self) -> None: ...

    def action_handle_extension_terminal_input(self, data: str) -> str | None: ...

    def action_cycle_thinking(self) -> None: ...

    def action_cycle_model(self) -> None: ...

    def action_cycle_model_previous(self) -> None: ...

    def action_open_model_picker(self) -> None: ...

    def action_toggle_tool_results(self) -> None: ...

    def action_open_dag_viewer_handoff(self) -> None: ...

    def action_toggle_thinking(self) -> None: ...

    def action_open_external_editor(self) -> None: ...

    def action_paste_clipboard(self) -> None: ...

    def action_dequeue_messages(self) -> None: ...

    def action_copy_last_message(self) -> None: ...

    def action_suspend_process(self) -> None: ...

    def action_edit_queued_follow_up(self) -> bool: ...

    async def action_run_extension_shortcut(self, key: str) -> bool: ...

    async def action_submit_prompt(self) -> None: ...

    async def action_submit_follow_up(self) -> None: ...


class SessionCompletionRecord(Protocol):
    """Session metadata needed to render resume picker completions."""

    id: str
    title: str | None
    model: str
    cwd: Path
    updated_at: float
    parent_session_id: str | None


class ToolsReferenceSearchInput(Input):
    """Search input that keeps tool-reference navigation local."""

    def _reference(self) -> ToolsReferenceScreen:
        return cast(ToolsReferenceScreen, self.screen)

    def on_key(self, event: Key) -> None:
        """Route navigation without changing the search text."""
        keybindings = self._reference().keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            self._reference().action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            self._reference().action_cursor_down()
        elif _matches_configured_or_default_key(event.key, keybindings.select_cancel, "escape"):
            event.stop()
            event.prevent_default()
            self._reference().action_cancel()
        elif _matches_configured_or_default_key(event.key, keybindings.select_confirm, "enter"):
            event.stop()
            event.prevent_default()
            self._reference().action_open_selected()

    def action_open_selected(self) -> None:
        self._reference().action_open_selected()


class ToolsReferenceScreen(ModalScreen[None]):
    """Searchable read-only reference for active session tools."""

    def __init__(
        self,
        tools: Sequence[AgentTool],
        *,
        extension_sources: Mapping[str, str] | None = None,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.extension_sources = dict(extension_sources or {})
        self.tools = self._order_tools(tools)
        self.visible_tools = self.tools
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the tool reference."""
        with Vertical(id="tools-reference"):
            yield Static("Available tools", id="tools-reference-title")
            yield ToolsReferenceSearchInput(
                placeholder="Search tools",
                id="tools-reference-search",
            )
            yield Static(
                self._table_row("Tool", "Origin", "Description"),
                id="tools-reference-header",
            )
            yield ListView(id="tools-reference-list")
            yield Static(self._help_text(), id="tools-reference-help")

    def on_mount(self) -> None:
        """Populate the list and focus search on open."""
        self._refresh_tools("")
        self.query_one("#tools-reference-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter tools as the search text changes."""
        if event.input.id != "tools-reference-search":
            return
        event.stop()
        self._refresh_tools(event.value)

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Open the selected tool's full description."""
        event.stop()
        self._open_tool(event.index)

    def on_key(self, event: Key) -> None:
        """Route configured picker keys when the list is focused."""
        if (
            _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up")
            or event.key == "k"
        ):
            event.stop()
            self.action_cursor_up()
        elif (
            _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down")
            or event.key == "j"
        ):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_open_selected()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def action_cursor_up(self) -> None:
        self._move_tool_cursor(-1)

    def action_cursor_down(self) -> None:
        self._move_tool_cursor(1)

    def action_open_selected(self) -> None:
        tool_list = self.query_one("#tools-reference-list", ListView)
        if tool_list.index is not None:
            self._open_tool(tool_list.index)

    def action_cancel(self) -> None:
        self.dismiss(None)

    def _move_tool_cursor(self, direction: Literal[-1, 1]) -> None:
        tool_list = self.query_one("#tools-reference-list", ListView)
        if not self.visible_tools:
            tool_list.index = None
            return
        current_index = tool_list.index if tool_list.index is not None else 0
        tool_list.index = (current_index + direction) % len(self.visible_tools)

    def _open_tool(self, index: int) -> None:
        if index >= len(self.visible_tools):
            return
        tool = self.visible_tools[index]
        self.app.push_screen(
            CommandOutputScreen(
                f"{tool.name} - {self._source_label(tool)}",
                tool.description or "No description",
                theme=self.theme,
                keybindings=self.keybindings,
            )
        )

    def _refresh_tools(self, query: str) -> None:
        tokens = _query_tokens(query)
        self.visible_tools = tuple(
            tool
            for tool in self.tools
            if _query_tokens_match(
                tokens,
                f"{tool.name} {tool.description} {self._source_label(tool)}",
            )
        )
        tool_list = self.query_one("#tools-reference-list", ListView)
        tool_list.clear()
        if not self.visible_tools:
            message = "No tools available." if not self.tools else "No tools match your search."
            tool_list.append(ListItem(Label(message, markup=False), disabled=True))
            tool_list.index = None
            return
        tool_list.extend(
            [
                ListItem(
                    Label(
                        self._table_row(
                            tool.name,
                            self._source_label(tool),
                            f"{len(tool.description)} chars",
                        ),
                        markup=False,
                    )
                )
                for tool in self.visible_tools
            ]
        )
        tool_list.index = 0

    def _order_tools(self, tools: Sequence[AgentTool]) -> tuple[AgentTool, ...]:
        tools_by_name = {tool.name: tool for tool in tools}
        builtins = sorted(
            (tool for tool in tools if tool.name not in self.extension_sources),
            key=lambda tool: tool.name.casefold(),
        )
        extension_tools: list[AgentTool] = []
        seen_extensions: set[str] = set()
        for extension in self.extension_sources.values():
            if extension in seen_extensions:
                continue
            seen_extensions.add(extension)
            extension_tools.extend(
                tools_by_name[tool_name]
                for tool_name, source in self.extension_sources.items()
                if source == extension and tool_name in tools_by_name
            )
        return tuple([*builtins, *extension_tools])

    def _table_row(self, name: str, source: str, description: str) -> str:
        name_width = max((len(tool.name) for tool in self.tools), default=len("Tool"))
        source_width = max(
            (len(self._source_label(tool)) for tool in self.tools),
            default=len("Origin"),
        )
        return (
            f"{name:<{max(name_width, len('Tool'))}}  "
            f"{source:<{max(source_width, len('Origin'))}}  {description}"
        )

    def _source_label(self, tool: AgentTool) -> str:
        extension = self.extension_sources.get(tool.name)
        return extension if extension is not None else "Built in"

    def _help_text(self) -> str:
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        return f"{confirm_key} opens description - {cancel_key} closes"


class SkillPickerSearchInput(Input):
    """Search input that keeps skill-picker navigation local."""

    def _picker(self) -> SkillPickerScreen:
        return cast(SkillPickerScreen, self.screen)

    def on_key(self, event: Key) -> None:
        """Route picker control keys before the input edits its text."""
        keybindings = self._picker().keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            self._picker().action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            self._picker().action_cursor_down()
        elif _matches_configured_or_default_key(event.key, keybindings.select_cancel, "escape"):
            event.stop()
            event.prevent_default()
            self._picker().action_cancel()
        elif _matches_configured_or_default_key(event.key, keybindings.select_confirm, "enter"):
            event.stop()
            event.prevent_default()
            self._picker().action_select_cursor()
        elif event.key == "f1":
            event.stop()
            event.prevent_default()
            self._picker().action_show_description()
        elif event.key == "ctrl+enter":
            event.stop()
            event.prevent_default()
            self._picker().action_show_in_transcript()


@dataclass(frozen=True, slots=True)
class SkillPickerResult:
    """A skill selection and the requested inspection action."""

    skill: Skill
    action: Literal["insert", "transcript"]


class SkillPickerScreen(ModalScreen[SkillPickerResult | None]):
    """Searchable modal containing every loaded skill."""

    def __init__(
        self,
        skills: Sequence[Skill],
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.skills = tuple(sorted(skills, key=lambda skill: skill.name.casefold()))
        self.visible_skills = self.skills
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the skills picker."""
        with Vertical(id="skill-picker"):
            yield Static("Skills", id="skill-picker-title")
            yield SkillPickerSearchInput(placeholder="Search skills", id="skill-picker-search")
            yield ListView(id="skill-picker-list")
            yield Static("", id="skill-picker-help")

    def on_mount(self) -> None:
        """Populate the list and focus search on open."""
        self.query_one("#skill-picker-search", Input).focus()
        self._refresh_skill_list("")

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter skills as the search text changes."""
        if event.input.id == "skill-picker-search":
            event.stop()
            self._refresh_skill_list(event.value)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Insert the highlighted skill when search is submitted."""
        if event.input.id == "skill-picker-search":
            event.stop()
            self.action_select_cursor()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Insert the selected skill."""
        event.stop()
        self.action_select_cursor()

    def on_key(self, event: Key) -> None:
        """Route configured picker keys when the list is focused."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()
        elif event.key == "f1":
            event.stop()
            self.action_show_description()
        elif event.key == "ctrl+enter":
            event.stop()
            self.action_show_in_transcript()

    def action_cursor_up(self) -> None:
        self._move_skill_cursor(-1)

    def action_cursor_down(self) -> None:
        self._move_skill_cursor(1)

    def action_select_cursor(self) -> None:
        skill = self._selected_skill()
        if skill is not None:
            self.dismiss(SkillPickerResult(skill, "insert"))

    def action_show_description(self) -> None:
        skill = self._selected_skill()
        if skill is not None:
            self.app.push_screen(
                CommandOutputScreen(
                    f"Skill description: {skill.name}",
                    skill.description or "No description",
                    theme=self.theme,
                    keybindings=self.keybindings,
                )
            )

    def action_show_in_transcript(self) -> None:
        skill = self._selected_skill()
        if skill is not None:
            self.dismiss(SkillPickerResult(skill, "transcript"))

    def action_cancel(self) -> None:
        self.dismiss(None)

    def _move_skill_cursor(self, direction: Literal[-1, 1]) -> None:
        skill_list = self.query_one("#skill-picker-list", ListView)
        if not self.visible_skills:
            skill_list.index = None
            return
        current_index = skill_list.index if skill_list.index is not None else 0
        skill_list.index = (current_index + direction) % len(self.visible_skills)

    def _selected_skill(self) -> Skill | None:
        index = self.query_one("#skill-picker-list", ListView).index
        if index is None or not self.visible_skills:
            return None
        return self.visible_skills[index]

    def _refresh_skill_list(self, search: str) -> None:
        tokens = _query_tokens(search)
        self.visible_skills = tuple(
            skill
            for skill in self.skills
            if _query_tokens_match(tokens, f"{skill.name} {skill.description or ''}")
        )
        skill_list = self.query_one("#skill-picker-list", ListView)
        skill_list.clear()
        skill_list.extend(
            ListItem(
                Horizontal(
                    Label(skill.name, classes="skill-picker-name", markup=False),
                    Label(
                        skill.description or "No description",
                        classes="skill-picker-description",
                        markup=False,
                    ),
                    classes="skill-picker-row",
                )
            )
            for skill in self.visible_skills
        )
        skill_list.index = 0 if self.visible_skills else None
        select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        if not self.skills:
            help_text = f"No skills loaded - {cancel_key} closes"
        elif not self.visible_skills:
            help_text = f"No matching skills - {cancel_key} closes"
        else:
            help_text = f"{select_key} inserts - F1 describes - Ctrl+Enter shows full skill"
        self.query_one("#skill-picker-help", Static).update(help_text)


class PromptTemplatePickerSearchInput(Input):
    """Search input that keeps prompt-template picker navigation local."""

    def _picker(self) -> PromptTemplatePickerScreen:
        return cast(PromptTemplatePickerScreen, self.screen)

    def on_key(self, event: Key) -> None:
        """Route picker control keys before the input edits its text."""
        keybindings = self._picker().keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            self._picker().action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            self._picker().action_cursor_down()
        elif _matches_configured_or_default_key(event.key, keybindings.select_cancel, "escape"):
            event.stop()
            event.prevent_default()
            self._picker().action_cancel()
        elif _matches_configured_or_default_key(event.key, keybindings.select_confirm, "enter"):
            event.stop()
            event.prevent_default()
            self._picker().action_select_cursor()


class PromptTemplatePickerScreen(ModalScreen[str | None]):
    """Searchable picker for loaded prompt templates."""

    def __init__(
        self,
        templates: Sequence[PromptTemplate],
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.templates = tuple(sorted(templates, key=lambda item: item.name.casefold()))
        self.visible_templates = self.templates
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the prompt template picker."""
        with Vertical(id="prompt-template-picker"):
            yield Static("Prompt templates", id="prompt-template-picker-title")
            yield PromptTemplatePickerSearchInput(
                placeholder="Search prompt templates",
                id="prompt-template-picker-search",
            )
            yield ListView(id="prompt-template-picker-list")
            yield Static("", id="prompt-template-picker-help")

    def on_mount(self) -> None:
        """Populate the list and focus search on open."""
        self.query_one("#prompt-template-picker-search", Input).focus()
        self._refresh_list("")

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter prompt templates as the search text changes."""
        if event.input.id != "prompt-template-picker-search":
            return
        event.stop()
        self._refresh_list(event.value)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Select the highlighted prompt template."""
        if event.input.id == "prompt-template-picker-search":
            event.stop()
            self.action_select_cursor()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Select the clicked prompt template."""
        event.stop()
        self.action_select_cursor()

    def on_key(self, event: Key) -> None:
        """Route configured picker keys when the list is focused."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def action_cursor_up(self) -> None:
        self._move_template_cursor(-1)

    def action_cursor_down(self) -> None:
        self._move_template_cursor(1)

    def action_select_cursor(self) -> None:
        picker_list = self.query_one("#prompt-template-picker-list", ListView)
        if self.visible_templates and picker_list.index is not None:
            self.dismiss(self.visible_templates[picker_list.index].name)

    def action_cancel(self) -> None:
        self.dismiss(None)

    def _move_template_cursor(self, direction: Literal[-1, 1]) -> None:
        picker_list = self.query_one("#prompt-template-picker-list", ListView)
        if not self.visible_templates:
            picker_list.index = None
            return
        current_index = picker_list.index if picker_list.index is not None else 0
        picker_list.index = (current_index + direction) % len(self.visible_templates)

    def _refresh_list(self, search: str) -> None:
        tokens = _query_tokens(search)
        self.visible_templates = tuple(
            template
            for template in self.templates
            if _query_tokens_match(tokens, f"{template.name} {template.description or ''}")
        )
        picker_list = self.query_one("#prompt-template-picker-list", ListView)
        picker_list.clear()
        picker_list.extend(
            ListItem(
                Label(
                    f"/{template.name} - {template.description or 'No description'}",
                    markup=False,
                )
            )
            for template in self.visible_templates
        )
        picker_list.index = 0 if self.visible_templates else None
        select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        if self.visible_templates:
            help_text = f"{select_key} selects - {cancel_key} closes"
        elif self.templates:
            help_text = f"No matching prompt templates - {cancel_key} closes"
        else:
            help_text = f"No prompt templates loaded - {cancel_key} closes"
        self.query_one("#prompt-template-picker-help", Static).update(help_text)


class PromptInput(TextArea):
    """Multiline prompt input with completion key bindings."""

    BINDINGS: ClassVar[list[BindingEntry]] = []
    LARGE_PASTE_CHAR_THRESHOLD: ClassVar[int] = 1000
    LARGE_PASTE_LINE_THRESHOLD: ClassVar[int] = 10
    PASTE_MARKER_PATTERN: ClassVar[re.Pattern[str]] = re.compile(
        r"\[paste #(?P<id>\d+)(?P<suffix>(?: (?:\+\d+ lines|\d+ chars))?)\]"
    )
    shell_mode_style: str = ""

    def __init__(
        self,
        *,
        tui_keybindings: TuiKeybindings | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.tui_keybindings = tui_keybindings or TuiKeybindings()
        self._base_bindings = self._bindings.copy()
        self._footer_mode: Literal["normal", "completion", "running"] = "normal"
        self._dag_viewer_handoff_available = False
        self._paste_counter = 0
        self._paste_markers: dict[str, str] = {}
        self._kill_ring: list[str] = []
        self._last_prompt_edit: Literal["kill", "yank"] | None = None
        self._last_yank_range: tuple[int, int] | None = None
        self._undo_stack: list[tuple[str, int, dict[str, str], int]] = []
        self._jump_direction: Literal["forward", "backward"] | None = None
        self._prompt_history: list[str] = []
        self._prompt_history_index = -1
        self._prompt_history_draft: tuple[str, tuple[int, int], dict[str, str], int] | None = None
        self._setting_history_text = False
        self._apply_prompt_bindings()

    def set_footer_mode(
        self,
        mode: Literal["normal", "completion", "running"],
        *,
        dag_viewer_handoff_available: bool = False,
    ) -> None:
        """Switch the prompt bindings shown by Textual's built-in footer."""
        if (
            mode == self._footer_mode
            and dag_viewer_handoff_available == self._dag_viewer_handoff_available
        ):
            return
        self._footer_mode = mode
        self._dag_viewer_handoff_available = dag_viewer_handoff_available
        self._apply_prompt_bindings()
        self.refresh_bindings()

    def _apply_prompt_bindings(self) -> None:
        self._bindings = BindingsMap.merge(
            [
                self._base_bindings,
                BindingsMap(
                    _prompt_bindings(
                        self.tui_keybindings,
                        mode=self._footer_mode,
                        dag_viewer_handoff_available=self._dag_viewer_handoff_available,
                    )
                ),
            ]
        )

    @property
    def value(self) -> str:
        """Compatibility alias for tests and code that previously used Input.value."""
        return self.text

    @value.setter
    def value(self, text: str) -> None:
        self._exit_prompt_history()
        self.text = text
        self.cursor_position = len(text)
        self.clear_paste_markers()
        self._last_prompt_edit = None
        self._last_yank_range = None
        self._undo_stack.clear()
        self._jump_direction = None

    def watch_text(self, old_text: str, new_text: str) -> None:
        """Leave history browsing when regular editing changes the prompt."""
        del old_text, new_text
        if not self._setting_history_text:
            self._exit_prompt_history()

    def add_to_history(self, text: str) -> None:
        """Add submitted prompt text for Pi-style up/down recall."""
        prompt = text.strip()
        if not prompt:
            return
        if self._prompt_history and self._prompt_history[0] == prompt:
            return
        self._prompt_history.insert(0, prompt)
        del self._prompt_history[100:]

    def clear_paste_markers(self) -> None:
        """Forget compacted paste payloads when replacing editor contents."""
        self._paste_counter = 0
        self._paste_markers.clear()

    def prune_paste_markers(self) -> None:
        """Drop removed paste payloads and keep visible marker IDs contiguous."""
        if not self._paste_markers:
            self._paste_counter = 0
            return
        next_markers: dict[str, str] = {}

        def replace_marker(match: re.Match[str]) -> str:
            marker = match.group(0)
            content = self._paste_markers.get(marker)
            if content is None:
                return marker
            next_id = len(next_markers) + 1
            next_marker = f"[paste #{next_id}{match.group('suffix') or ''}]"
            next_markers[next_marker] = content
            return next_marker

        next_text = self.PASTE_MARKER_PATTERN.sub(replace_marker, self.text)
        if next_text != self.text:
            self.text = next_text
        self._paste_markers = next_markers
        self._paste_counter = len(next_markers)

    def _valid_paste_marker_spans(self) -> list[tuple[int, int, str]]:
        if not self._paste_markers:
            return []
        spans: list[tuple[int, int, str]] = []
        for match in self.PASTE_MARKER_PATTERN.finditer(self.text):
            marker = match.group(0)
            if marker in self._paste_markers:
                spans.append((match.start(), match.end(), marker))
        return spans

    def _paste_marker_span_touching_cursor(
        self,
        *,
        direction: Literal["backward", "forward"],
    ) -> tuple[int, int, str] | None:
        cursor = self.cursor_position
        for start, end, marker in self._valid_paste_marker_spans():
            if direction == "backward" and start < cursor <= end:
                return start, end, marker
            if direction == "forward" and start <= cursor < end:
                return start, end, marker
        return None

    def _snap_cursor_out_of_paste_marker(
        self,
        *,
        direction: Literal["backward", "forward"],
    ) -> bool:
        cursor = self.cursor_position
        for start, end, _marker in self._valid_paste_marker_spans():
            if direction == "backward" and end == cursor:
                self.cursor_position = start
                return True
            if direction == "forward" and start == cursor:
                self.cursor_position = end
                return True
            if start < cursor < end:
                self.cursor_position = start if direction == "backward" else end
                return True
        return False

    def _delete_paste_marker_span(
        self,
        start: int,
        end: int,
        marker: str,
        *,
        prepend_kill: bool,
    ) -> None:
        self._push_undo_snapshot()
        self._push_kill(marker, prepend=prepend_kill)
        text = self.text
        self.text = f"{text[:start]}{text[end:]}"
        self._paste_markers.pop(marker, None)
        self.prune_paste_markers()
        self.cursor_position = start

    def expanded_text(self) -> str:
        """Return prompt text with compacted paste markers expanded."""
        text = self.text
        for marker, content in self._paste_markers.items():
            text = text.replace(marker, content)
        return text

    def insert_paste_text(self, text: str) -> None:
        """Insert clipboard text, compacting large pastes behind Pi-style markers."""
        dropped_paths = normalize_dropped_paths(text)
        if dropped_paths is not None:
            self._insert_dropped_paths(dropped_paths)
            return

        filtered = _normalize_pasted_text(text)
        if not filtered:
            return

        if filtered.startswith(("/", "~", ".")):
            row, column = self.cursor_location
            line = self.text.split("\n")[row] if self.text else ""
            char_before_cursor = line[column - 1] if column > 0 else ""
            if char_before_cursor and (char_before_cursor.isalnum() or char_before_cursor == "_"):
                filtered = f" {filtered}"

        lines = filtered.split("\n")
        is_large_paste = (
            len(lines) > self.LARGE_PASTE_LINE_THRESHOLD
            or len(filtered) > self.LARGE_PASTE_CHAR_THRESHOLD
        )
        if is_large_paste:
            self._push_undo_snapshot()
            self._paste_counter += 1
            if len(lines) > self.LARGE_PASTE_LINE_THRESHOLD:
                marker = f"[paste #{self._paste_counter} +{len(lines)} lines]"
            else:
                marker = f"[paste #{self._paste_counter} {len(filtered)} chars]"
            self._paste_markers[marker] = filtered
            self.insert(marker)
            return

        self._push_undo_snapshot()
        self.insert(filtered)

    def on_paste(self, event: events.Paste) -> None:
        """Handle file drops and collapse very large pasted text."""
        dropped_paths = normalize_dropped_paths(event.text)
        if dropped_paths is not None:
            event.stop()
            event.prevent_default()
            self._insert_dropped_paths(dropped_paths)
            return
        filtered = _normalize_pasted_text(event.text)
        if (
            len(filtered.split("\n")) <= self.LARGE_PASTE_LINE_THRESHOLD
            and len(filtered) <= self.LARGE_PASTE_CHAR_THRESHOLD
        ):
            return
        event.stop()
        event.prevent_default()
        self.insert_paste_text(event.text)

    def _insert_dropped_paths(self, insertion: str) -> None:
        """Insert dropped paths at the cursor, separated from surrounding text."""
        position = self.cursor_position
        before = self.text[:position]
        after = self.text[position:]
        if before and not before[-1].isspace():
            insertion = f" {insertion}"
        if not after or not after[0].isspace():
            insertion = f"{insertion} "
        self._push_undo_snapshot()
        self.insert(insertion)

    @property
    def cursor_position(self) -> int:
        """Return a flat cursor offset for Input compatibility."""
        row, column = self.cursor_location
        lines = self.text.split("\n")
        return sum(len(line) + 1 for line in lines[:row]) + column

    @cursor_position.setter
    def cursor_position(self, offset: int) -> None:
        text = self.text
        bounded = max(0, min(offset, len(text)))
        before = text[:bounded]
        self.move_cursor((before.count("\n"), len(before.rsplit("\n", 1)[-1])))

    def _refresh_completions_after_cursor_move(self) -> None:
        try:
            has_completion_options = self._has_completion_options()
        except Exception:  # noqa: BLE001 - unmounted prompt widgets have no active Textual app
            return
        if has_completion_options:
            self._completion_target().action_refresh_completions_for_cursor()

    def action_accept_completion(self) -> None:
        """Accept the selected app-level completion."""
        self._completion_target().action_accept_completion()

    def action_completion_next(self) -> None:
        """Select the next app-level completion or move down in the prompt."""
        if self._has_completion_options():
            self._completion_target().action_completion_next()
        else:
            self.action_cursor_down()

    def action_completion_previous(self) -> None:
        """Select the previous app-level completion or move up in the prompt."""
        if self._has_completion_options():
            self._completion_target().action_completion_previous()
        elif self._completion_target().action_edit_queued_follow_up():
            return
        else:
            self.action_cursor_up()

    def action_cursor_up(self) -> None:
        """Move up or browse prompt history from the first prompt line."""
        row, column = self.cursor_location
        if self._prompt_history_text_changed():
            self._exit_prompt_history()
            result = super().action_cursor_up()
            if isawaitable(result):
                self.run_worker(result)
            return
        can_browse_history = (
            self._is_prompt_empty() or self._prompt_history_index >= 0 or column == 0
        )
        if self._prompt_history and row <= 0 and can_browse_history:
            self._navigate_prompt_history(-1)
            return
        if row <= 0 and column > 0:
            self.move_cursor((0, 0))
            self._refresh_completions_after_cursor_move()
            return
        result = super().action_cursor_up()
        if isawaitable(result):
            self.run_worker(result)
        self._refresh_completions_after_cursor_move()

    def action_cursor_down(self) -> None:
        """Move down or restore the live draft after prompt history browsing."""
        row, _column = self.cursor_location
        lines = self.text.split("\n")
        if self._prompt_history_text_changed():
            self._exit_prompt_history()
            result = super().action_cursor_down()
            if isawaitable(result):
                self.run_worker(result)
            return
        if self._prompt_history_index >= 0 and row >= len(lines) - 1:
            self._navigate_prompt_history(1)
            return
        result = super().action_cursor_down()
        if isawaitable(result):
            self.run_worker(result)
        self._refresh_completions_after_cursor_move()

    def action_cursor_left(self) -> None:
        """Move left and refresh any open prompt completion context."""
        if self._snap_cursor_out_of_paste_marker(direction="backward"):
            self._refresh_completions_after_cursor_move()
            return
        result = super().action_cursor_left()
        if isawaitable(result):
            self.run_worker(result)
        self._snap_cursor_out_of_paste_marker(direction="backward")
        self._refresh_completions_after_cursor_move()

    def action_cursor_right(self) -> None:
        """Move right and refresh any open prompt completion context."""
        if self._snap_cursor_out_of_paste_marker(direction="forward"):
            self._refresh_completions_after_cursor_move()
            return
        result = super().action_cursor_right()
        if isawaitable(result):
            self.run_worker(result)
        self._snap_cursor_out_of_paste_marker(direction="forward")
        self._refresh_completions_after_cursor_move()

    def _navigate_prompt_history(self, direction: Literal[-1, 1]) -> None:
        next_index = self._prompt_history_index - direction
        if next_index < -1 or next_index >= len(self._prompt_history):
            return
        if self._prompt_history_index == -1 and next_index >= 0:
            self._push_undo_snapshot()
            self._prompt_history_draft = (
                self.text,
                self.cursor_location,
                dict(self._paste_markers),
                self._paste_counter,
            )
        self._prompt_history_index = next_index
        if next_index == -1:
            draft = self._prompt_history_draft
            self._prompt_history_draft = None
            if draft is None:
                self._set_prompt_history_text("", cursor_placement="end")
                return
            text, cursor_location, paste_markers, paste_counter = draft
            self._setting_history_text = True
            try:
                self.text = text
                self._paste_markers = dict(paste_markers)
                self._paste_counter = paste_counter
                self.move_cursor(cursor_location)
            finally:
                self._setting_history_text = False
            return
        cursor_placement: Literal["start", "end"] = "start" if direction == -1 else "end"
        self._set_prompt_history_text(
            self._prompt_history[next_index],
            cursor_placement=cursor_placement,
        )

    def _set_prompt_history_text(
        self,
        text: str,
        *,
        cursor_placement: Literal["start", "end"],
    ) -> None:
        self._setting_history_text = True
        try:
            self.text = text
            self.clear_paste_markers()
            location = (0, 0) if cursor_placement == "start" else _text_end_location(text)
            self.move_cursor(location)
        finally:
            self._setting_history_text = False

    def _exit_prompt_history(self) -> None:
        self._prompt_history_index = -1
        self._prompt_history_draft = None

    def _is_prompt_empty(self) -> bool:
        return self.text == ""

    def _prompt_history_text_changed(self) -> bool:
        index = self._prompt_history_index
        if index < 0 or index >= len(self._prompt_history):
            return False
        return self.text != self._prompt_history[index]

    def action_cancel(self) -> None:
        """Run the app-level cancel action."""
        self._completion_target().action_cancel()

    def action_open_command_palette(self) -> None:
        """Open the app-level command palette."""
        self._completion_target().action_open_command_palette()

    def action_command_palette_or_delete_to_line_end(self) -> None:
        """Use Ctrl+K as Pi line-end delete when editing, or commands when empty."""
        if self.text:
            self.action_delete_to_line_end()
            return
        self._completion_target().action_open_command_palette()

    def action_open_session_picker(self) -> None:
        """Open the app-level session picker."""
        self._completion_target().action_open_session_picker()

    def action_new_session(self) -> None:
        """Start a new app-level session."""
        self._completion_target().action_new_session()

    def action_open_tree_picker(self) -> None:
        """Open the app-level session tree picker."""
        self._completion_target().action_open_tree_picker()

    def action_open_fork_picker(self) -> None:
        """Open the app-level fork picker."""
        self._completion_target().action_open_fork_picker()

    def action_cycle_thinking(self) -> None:
        """Cycle the app-level thinking mode."""
        self._completion_target().action_cycle_thinking()

    def action_cycle_model(self) -> None:
        """Cycle the app-level scoped model."""
        self._completion_target().action_cycle_model()

    def action_cycle_model_previous(self) -> None:
        """Cycle the app-level scoped model backwards."""
        self._completion_target().action_cycle_model_previous()

    def action_open_model_picker(self) -> None:
        """Open the app-level model picker."""
        self._completion_target().action_open_model_picker()

    def action_toggle_tool_results(self) -> None:
        """Toggle app-level tool result display."""
        self._completion_target().action_toggle_tool_results()

    def action_toggle_thinking(self) -> None:
        """Toggle app-level thinking-token display."""
        self._completion_target().action_toggle_thinking()

    def action_open_external_editor(self) -> None:
        """Open the current prompt in the configured external editor."""
        self._completion_target().action_open_external_editor()

    def action_paste_clipboard(self) -> None:
        """Paste system clipboard text into the prompt."""
        self._completion_target().action_paste_clipboard()

    def action_dequeue_messages(self) -> None:
        """Restore queued messages into the prompt."""
        self._completion_target().action_dequeue_messages()

    def action_copy_last_message(self) -> None:
        """Copy the last agent/assistant message."""
        self._completion_target().action_copy_last_message()

    def action_suspend_process(self) -> None:
        """Suspend the Tau process to the background."""
        self._completion_target().action_suspend_process()

    async def action_clear_prompt(self) -> None:
        """Clear the current prompt."""
        if self.selected_text:
            return
        app = self._completion_target()
        now = monotonic()
        last_clear_at = getattr(app, "_last_clear_prompt_at", None)
        if last_clear_at is not None and now - last_clear_at <= 0.5:
            app._last_clear_prompt_at = None
            result = app.action_quit()
            if isawaitable(result):
                await result
            return
        app._last_clear_prompt_at = now
        if self.text:
            self._push_undo_snapshot()
            self.text = ""
            self.clear_paste_markers()
            self.move_cursor((0, 0))

    def action_delete_to_line_start(self) -> None:
        """Delete prompt text from the cursor back to the current line start."""
        if self.selected_text:
            return
        text = self.text
        if not text:
            return
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="backward")
        if paste_marker_span is not None:
            self._last_prompt_edit = None
            self._last_yank_range = None
            start, end, marker = paste_marker_span
            self._delete_paste_marker_span(start, end, marker, prepend_kill=True)
            return
        row, column = self.cursor_location
        lines = text.split("\n")
        if row >= len(lines):
            return
        if column <= 0:
            if row <= 0:
                return
            self._push_undo_snapshot()
            previous_line_length = len(lines[row - 1])
            lines[row - 1] = f"{lines[row - 1]}{lines[row]}"
            del lines[row]
            self.text = "\n".join(lines)
            self._push_kill("\n", prepend=True)
            self.prune_paste_markers()
            self.move_cursor((row - 1, previous_line_length))
            return
        line_start_offset = sum(len(line) + 1 for line in lines[:row])
        delete_end_offset = line_start_offset + column
        self._push_undo_snapshot()
        self._push_kill(text[line_start_offset:delete_end_offset], prepend=True)
        self.text = text[:line_start_offset] + text[delete_end_offset:]
        self.prune_paste_markers()
        self.move_cursor((row, 0))

    def action_delete_word_backward(self) -> None:
        """Delete prompt text from the cursor back to the previous word boundary."""
        if self.selected_text:
            return
        text = self.text
        if not text:
            return
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="backward")
        if paste_marker_span is not None:
            self._last_prompt_edit = None
            self._last_yank_range = None
            start, end, marker = paste_marker_span
            self._delete_paste_marker_span(start, end, marker, prepend_kill=True)
            return
        row, column = self.cursor_location
        lines = text.split("\n")
        if row >= len(lines):
            return
        if column <= 0:
            if row <= 0:
                return
            self._push_undo_snapshot()
            previous_line_length = len(lines[row - 1])
            lines[row - 1] = f"{lines[row - 1]}{lines[row]}"
            del lines[row]
            self.text = "\n".join(lines)
            self._push_kill("\n", prepend=True)
            self.prune_paste_markers()
            self.move_cursor((row - 1, previous_line_length))
            return
        current_line = lines[row]
        delete_start = _find_word_delete_start(current_line, column)
        if delete_start == column:
            return
        self._push_undo_snapshot()
        self._push_kill(current_line[delete_start:column], prepend=True)
        lines[row] = f"{current_line[:delete_start]}{current_line[column:]}"
        self.text = "\n".join(lines)
        self.prune_paste_markers()
        self.move_cursor((row, delete_start))

    def action_delete_word_forward(self) -> None:
        """Delete prompt text from the cursor forward to the next word boundary."""
        if self.selected_text:
            return
        text = self.text
        if not text:
            return
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="forward")
        if paste_marker_span is not None:
            self._last_prompt_edit = None
            self._last_yank_range = None
            start, end, marker = paste_marker_span
            self._delete_paste_marker_span(start, end, marker, prepend_kill=False)
            return
        row, column = self.cursor_location
        lines = text.split("\n")
        if row >= len(lines):
            return
        current_line = lines[row]
        if column >= len(current_line):
            if row >= len(lines) - 1:
                return
            self._push_undo_snapshot()
            lines[row] = f"{current_line}{lines[row + 1]}"
            del lines[row + 1]
            self.text = "\n".join(lines)
            self._push_kill("\n", prepend=False)
            self.prune_paste_markers()
            self.move_cursor((row, len(current_line)))
            return
        delete_end = _find_word_delete_end(current_line, column)
        if delete_end == column:
            return
        self._push_undo_snapshot()
        self._push_kill(current_line[column:delete_end], prepend=False)
        lines[row] = f"{current_line[:column]}{current_line[delete_end:]}"
        self.text = "\n".join(lines)
        self.prune_paste_markers()
        self.move_cursor((row, column))

    def action_delete_to_line_end(self) -> None:
        """Delete prompt text from the cursor forward to the current line end."""
        if self.selected_text:
            return
        text = self.text
        if not text:
            return
        row, column = self.cursor_location
        lines = text.split("\n")
        if row >= len(lines):
            return
        current_line = lines[row]
        if column < len(current_line):
            self._push_undo_snapshot()
            self._push_kill(current_line[column:], prepend=False)
            lines[row] = current_line[:column]
            self.text = "\n".join(lines)
            self.prune_paste_markers()
            self.move_cursor((row, column))
            return
        if row < len(lines) - 1:
            self._push_undo_snapshot()
            lines[row] = f"{current_line}{lines[row + 1]}"
            del lines[row + 1]
            self.text = "\n".join(lines)
            self._push_kill("\n", prepend=False)
            self.prune_paste_markers()
            self.move_cursor((row, len(current_line)))

    def action_delete_character_forward(self) -> None:
        """Delete the character under the cursor."""
        if self.selected_text:
            return
        text = self.text
        if not text:
            return
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="forward")
        if paste_marker_span is not None:
            self._last_prompt_edit = None
            self._last_yank_range = None
            start, end, marker = paste_marker_span
            self._delete_paste_marker_span(start, end, marker, prepend_kill=False)
            return
        row, column = self.cursor_location
        lines = text.split("\n")
        if row >= len(lines):
            return
        current_line = lines[row]
        self._last_prompt_edit = None
        self._last_yank_range = None
        if column < len(current_line):
            self._push_undo_snapshot()
            lines[row] = f"{current_line[:column]}{current_line[column + 1 :]}"
            self.text = "\n".join(lines)
            self.prune_paste_markers()
            self.move_cursor((row, column))
            return
        if row < len(lines) - 1:
            self._push_undo_snapshot()
            lines[row] = f"{current_line}{lines[row + 1]}"
            del lines[row + 1]
            self.text = "\n".join(lines)
            self.prune_paste_markers()
            self.move_cursor((row, len(current_line)))

    def action_delete_character_backward(self) -> None:
        """Delete the character before the cursor."""
        if self.selected_text:
            return
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="backward")
        if paste_marker_span is not None:
            self._last_prompt_edit = None
            self._last_yank_range = None
            start, end, marker = paste_marker_span
            self._delete_paste_marker_span(start, end, marker, prepend_kill=True)
            return
        result = super().action_delete_left()
        if isawaitable(result):
            self.run_worker(result)
        self.prune_paste_markers()

    def action_move_to_line_start(self) -> None:
        """Move the prompt cursor to the start of the current line."""
        self._last_prompt_edit = None
        self._last_yank_range = None
        row, _column = self.cursor_location
        self.move_cursor((row, 0))
        self._refresh_completions_after_cursor_move()

    def action_move_to_line_end(self) -> None:
        """Move the prompt cursor to the end of the current line."""
        self._last_prompt_edit = None
        self._last_yank_range = None
        row, _column = self.cursor_location
        lines = self.text.split("\n")
        line = lines[row] if row < len(lines) else ""
        self.move_cursor((row, len(line)))
        self._refresh_completions_after_cursor_move()

    def action_move_word_backward(self) -> None:
        """Move the prompt cursor back by one Pi-style word boundary."""
        self._last_prompt_edit = None
        self._last_yank_range = None
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="backward")
        if paste_marker_span is not None:
            start, _end, _marker = paste_marker_span
            self.cursor_position = start
            self._refresh_completions_after_cursor_move()
            return
        row, column = self.cursor_location
        lines = self.text.split("\n")
        if row >= len(lines):
            return
        if column <= 0:
            if row > 0:
                self.move_cursor((row - 1, len(lines[row - 1])))
                self._refresh_completions_after_cursor_move()
            return
        self.move_cursor((row, _find_word_delete_start(lines[row], column)))
        self._refresh_completions_after_cursor_move()

    def action_move_word_forward(self) -> None:
        """Move the prompt cursor forward by one Pi-style word boundary."""
        self._last_prompt_edit = None
        self._last_yank_range = None
        paste_marker_span = self._paste_marker_span_touching_cursor(direction="forward")
        if paste_marker_span is not None:
            _start, end, _marker = paste_marker_span
            self.cursor_position = end
            self._refresh_completions_after_cursor_move()
            return
        row, column = self.cursor_location
        lines = self.text.split("\n")
        if row >= len(lines):
            return
        if column >= len(lines[row]):
            if row < len(lines) - 1:
                self.move_cursor((row + 1, 0))
                self._refresh_completions_after_cursor_move()
            return
        self.move_cursor((row, _find_word_delete_end(lines[row], column)))
        self._refresh_completions_after_cursor_move()

    def action_start_jump_forward(self) -> None:
        """Arm Pi-style forward character jump mode."""
        self._last_prompt_edit = None
        self._last_yank_range = None
        self._jump_direction = "forward"

    def action_start_jump_backward(self) -> None:
        """Arm Pi-style backward character jump mode."""
        self._last_prompt_edit = None
        self._last_yank_range = None
        self._jump_direction = "backward"

    def action_jump_to_character(self, character: str) -> None:
        """Move the cursor to the next matching character in the armed direction."""
        direction = self._jump_direction
        self._jump_direction = None
        if direction is None or not character:
            return
        row, column = self.cursor_location
        lines = self.text.split("\n")
        if direction == "forward":
            for line_index in range(row, len(lines)):
                line = lines[line_index]
                search_from = column + 1 if line_index == row else 0
                match_column = line.find(character, search_from)
                if match_column != -1:
                    self.move_cursor((line_index, match_column))
                    self._refresh_completions_after_cursor_move()
                    return
            return
        for line_index in range(row, -1, -1):
            line = lines[line_index]
            search_to = column if line_index == row else len(line)
            match_column = line.rfind(character, 0, search_to)
            if match_column != -1:
                self.move_cursor((line_index, match_column))
                self._refresh_completions_after_cursor_move()
                return

    def action_yank_kill_ring(self) -> None:
        """Insert the most recently deleted prompt text at the cursor."""
        killed_text = self._peek_kill()
        if not killed_text:
            return
        start = self.cursor_position
        self._push_undo_snapshot()
        self._replace_prompt_range(start, start, killed_text)
        self._last_prompt_edit = "yank"
        self._last_yank_range = (start, start + len(killed_text))

    def action_yank_pop_kill_ring(self) -> None:
        """Replace the previous yank with the next kill-ring entry."""
        if self._last_prompt_edit != "yank" or self._last_yank_range is None:
            return
        if len(self._kill_ring) <= 1:
            return
        start, end = self._last_yank_range
        text = self.text
        if start < 0 or end > len(text) or start > end:
            return
        self._push_undo_snapshot()
        without_last_yank = f"{text[:start]}{text[end:]}"
        self._rotate_kill_ring()
        killed_text = self._peek_kill()
        if not killed_text:
            return
        self.text = f"{without_last_yank[:start]}{killed_text}{without_last_yank[start:]}"
        self.prune_paste_markers()
        self.cursor_position = start + len(killed_text)
        self._last_prompt_edit = "yank"
        self._last_yank_range = (start, start + len(killed_text))

    def _push_kill(self, text: str, *, prepend: bool) -> None:
        if not text:
            return
        if self._last_prompt_edit == "kill" and self._kill_ring:
            previous = self._kill_ring.pop()
            self._kill_ring.append(f"{text}{previous}" if prepend else f"{previous}{text}")
        else:
            self._kill_ring.append(text)
        self._last_prompt_edit = "kill"
        self._last_yank_range = None

    def _peek_kill(self) -> str | None:
        return self._kill_ring[-1] if self._kill_ring else None

    def _rotate_kill_ring(self) -> None:
        if len(self._kill_ring) > 1:
            self._kill_ring.insert(0, self._kill_ring.pop())

    def _replace_prompt_range(self, start: int, end: int, replacement: str) -> None:
        text = self.text
        start = min(max(start, 0), len(text))
        end = min(max(end, start), len(text))
        self.text = f"{text[:start]}{replacement}{text[end:]}"
        self.prune_paste_markers()
        self.cursor_position = start + len(replacement)

    def _push_undo_snapshot(self) -> None:
        self._undo_stack.append(
            (self.text, self.cursor_position, dict(self._paste_markers), self._paste_counter)
        )

    def action_undo_prompt_edit(self) -> None:
        """Restore the previous prompt-edit snapshot."""
        if not self._undo_stack:
            return
        text, cursor_position, paste_markers, paste_counter = self._undo_stack.pop()
        self.text = text
        self._paste_markers = paste_markers
        self._paste_counter = paste_counter
        self.cursor_position = cursor_position
        self._last_prompt_edit = None
        self._last_yank_range = None

    def get_line(self, line_index: int) -> Text:
        """Retrieve one prompt line, coloring terminal commands like a running tool."""
        line = super().get_line(line_index)
        if not self.shell_mode_style:
            return line
        span = _terminal_command_prefix_span(self.text)
        if span is None:
            return line
        start, _ = span
        line.stylize(self.shell_mode_style, start if line_index == 0 else 0)
        return line

    async def action_submit_follow_up(self) -> None:
        """Submit the prompt as an app-level follow-up."""
        await self._completion_target().action_submit_follow_up()

    async def action_submit_prompt(self) -> None:
        """Submit the prompt through the app-level action."""
        await self._completion_target().action_submit_prompt()

    def action_insert_newline(self) -> None:
        """Insert a newline in the prompt."""
        self._push_undo_snapshot()
        self.insert("\n")

    def _insert_newline_from_backslash_enter(self) -> bool:
        """Convert a preceding backslash into a newline for Pi-style Enter fallback."""
        cursor_position = self.cursor_position
        if cursor_position <= 0 or self.text[cursor_position - 1] != "\\":
            return False
        self._push_undo_snapshot()
        self._replace_prompt_range(cursor_position - 1, cursor_position, "\n")
        return True

    async def action_quit(self) -> None:
        """Quit the app through the app-level action."""
        if self.text:
            self.action_delete_character_forward()
            return
        await self.app.action_quit()

    def action_scroll_down(self) -> None:
        """Use down arrow for completion selection while focused."""
        self.action_completion_next()

    def action_scroll_up(self) -> None:
        """Use up arrow for completion selection while focused."""
        self.action_completion_previous()

    async def on_key(self, event: Key) -> None:
        """Route completion and submission keys before default input handling."""
        keybindings = self.tui_keybindings
        listener_replacement = self._completion_target().action_handle_extension_terminal_input(
            _terminal_input_event_data(event)
        )
        if listener_replacement is not None:
            event.stop()
            event.prevent_default()
            if listener_replacement:
                self._push_undo_snapshot()
                self.insert(listener_replacement)
            return
        if self._jump_direction is not None:
            event.stop()
            event.prevent_default()
            if event.key in {"ctrl+]", "ctrl+alt+]"}:
                self._jump_direction = None
                return
            character = _jump_character_from_key(event.key)
            if character is None:
                self._jump_direction = None
                return
            self.action_jump_to_character(character)
        elif await self._completion_target().action_run_extension_shortcut(event.key):
            event.stop()
            event.prevent_default()
        elif _matches_configured_key(event.key, keybindings.queue_follow_up):
            event.stop()
            event.prevent_default()
            await self._completion_target().action_submit_follow_up()
        elif _matches_configured_key(event.key, keybindings.dequeue_messages):
            event.stop()
            event.prevent_default()
            self._completion_target().action_dequeue_messages()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.submit_prompt,
            "enter",
        ):
            event.stop()
            event.prevent_default()
            if self._insert_newline_from_backslash_enter():
                return
            await self._completion_target().action_submit_prompt()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.insert_newline,
            "shift+enter",
        ) or (
            event.key == "ctrl+j"
            and not _matches_configured_key(event.key, keybindings.command_palette)
        ):
            event.stop()
            event.prevent_default()
            self._push_undo_snapshot()
            self.insert("\n")
        elif event.key == "shift+space":
            event.stop()
            event.prevent_default()
            self._push_undo_snapshot()
            self.insert(" ")
        elif _matches_configured_key(event.key, keybindings.accept_completion):
            event.stop()
            self._completion_target().action_accept_completion()
        elif _matches_configured_key(event.key, keybindings.cancel):
            event.stop()
            self._completion_target().action_cancel()
        elif self.text and _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_to_line_end,
            "ctrl+k",
        ):
            event.stop()
            event.prevent_default()
            self.action_delete_to_line_end()
        elif _matches_configured_key(event.key, keybindings.command_palette):
            event.stop()
            self._completion_target().action_open_command_palette()
        elif _matches_configured_key(event.key, keybindings.session_picker):
            event.stop()
            self._completion_target().action_open_session_picker()
        elif keybindings.session_new and _matches_configured_key(
            event.key, keybindings.session_new
        ):
            event.stop()
            self._completion_target().action_new_session()
        elif keybindings.session_tree and _matches_configured_key(
            event.key, keybindings.session_tree
        ):
            event.stop()
            self._completion_target().action_open_tree_picker()
        elif keybindings.session_fork and _matches_configured_key(
            event.key, keybindings.session_fork
        ):
            event.stop()
            self._completion_target().action_open_fork_picker()
        elif keybindings.session_resume and _matches_configured_key(
            event.key, keybindings.session_resume
        ):
            event.stop()
            self._completion_target().action_open_session_picker()
        elif _is_thinking_cycle_key(event.key, keybindings.thinking_cycle):
            event.stop()
            self._completion_target().action_cycle_thinking()
        elif _matches_configured_key(event.key, keybindings.model_cycle):
            event.stop()
            self._completion_target().action_cycle_model()
        elif _matches_configured_key(event.key, keybindings.model_cycle_previous):
            event.stop()
            self._completion_target().action_cycle_model_previous()
        elif _matches_configured_key(event.key, keybindings.model_picker):
            event.stop()
            self._completion_target().action_open_model_picker()
        elif _matches_configured_key(event.key, keybindings.toggle_tool_results):
            event.stop()
            self._completion_target().action_toggle_tool_results()
        elif _matches_configured_key(event.key, keybindings.toggle_thinking):
            event.stop()
            self._completion_target().action_toggle_thinking()
        elif _matches_configured_key(event.key, keybindings.external_editor):
            event.stop()
            self._completion_target().action_open_external_editor()
        elif _matches_configured_key(event.key, keybindings.paste_clipboard):
            event.stop()
            event.prevent_default()
            self._completion_target().action_paste_clipboard()
        elif _matches_configured_key(event.key, keybindings.copy_last_message):
            event.stop()
            event.prevent_default()
            self._completion_target().action_copy_last_message()
        elif _matches_configured_key(event.key, keybindings.suspend):
            event.stop()
            event.prevent_default()
            self._completion_target().action_suspend_process()
        elif _matches_configured_key(event.key, keybindings.copy_message):
            if self.selected_text:
                return
            event.stop()
            event.prevent_default()
            await self.action_clear_prompt()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_to_line_start,
            "ctrl+u",
        ):
            event.stop()
            event.prevent_default()
            self.action_delete_to_line_start()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_word_backward,
            "ctrl+w,alt+backspace",
        ):
            event.stop()
            event.prevent_default()
            self.action_delete_word_backward()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_word_forward,
            "alt+d,alt+delete",
        ):
            event.stop()
            event.prevent_default()
            self.action_delete_word_forward()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_to_line_end,
            "ctrl+k",
        ):
            event.stop()
            event.prevent_default()
            self.action_delete_to_line_end()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_char_backward,
            "backspace",
        ):
            event.stop()
            event.prevent_default()
            self.action_delete_character_backward()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_delete_char_forward,
            "delete,ctrl+d",
        ) and (event.key != "ctrl+d" or self.text):
            event.stop()
            event.prevent_default()
            self.action_delete_character_forward()
        elif _matches_configured_or_default_key(event.key, keybindings.editor_yank, "ctrl+y"):
            event.stop()
            event.prevent_default()
            self.action_yank_kill_ring()
        elif _matches_configured_or_default_key(event.key, keybindings.editor_yank_pop, "alt+y"):
            event.stop()
            event.prevent_default()
            self.action_yank_pop_kill_ring()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_line_start,
            "home,ctrl+a",
        ):
            event.stop()
            event.prevent_default()
            self.action_move_to_line_start()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_line_end,
            "end,ctrl+e",
        ):
            event.stop()
            event.prevent_default()
            self.action_move_to_line_end()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_left,
            "left,ctrl+b",
        ):
            event.stop()
            event.prevent_default()
            self._last_prompt_edit = None
            self._last_yank_range = None
            self.action_cursor_left()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_right,
            "right,ctrl+f",
        ):
            event.stop()
            event.prevent_default()
            self._last_prompt_edit = None
            self._last_yank_range = None
            self.action_cursor_right()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_word_left,
            "alt+left,ctrl+left,alt+b",
        ):
            event.stop()
            event.prevent_default()
            self.action_move_word_backward()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_word_right,
            "alt+right,ctrl+right,alt+f",
        ):
            event.stop()
            event.prevent_default()
            self.action_move_word_forward()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_undo,
            "ctrl+-,ctrl+minus",
        ):
            event.stop()
            event.prevent_default()
            self.action_undo_prompt_edit()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_page_up,
            "pageup",
        ):
            event.stop()
            event.prevent_default()
            self.action_cursor_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_page_down,
            "pagedown",
        ):
            event.stop()
            event.prevent_default()
            self.action_cursor_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_jump_forward,
            "ctrl+]",
        ):
            event.stop()
            event.prevent_default()
            self.action_start_jump_forward()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_jump_backward,
            "ctrl+alt+]",
        ):
            event.stop()
            event.prevent_default()
            self.action_start_jump_backward()
        elif _matches_configured_key(event.key, keybindings.completion_next):
            event.stop()
            if self._has_completion_options():
                self._completion_target().action_completion_next()
            else:
                self.action_cursor_down()
        elif _matches_configured_key(event.key, keybindings.completion_previous):
            event.stop()
            self.action_completion_previous()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_down,
            "down",
        ):
            event.stop()
            event.prevent_default()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.editor_cursor_up,
            "up",
        ):
            event.stop()
            event.prevent_default()
            self.action_cursor_up()
        elif _matches_configured_key(event.key, keybindings.quit):
            event.stop()
            await self.action_quit()
        else:
            self._last_prompt_edit = None
            self._last_yank_range = None

    def _has_completion_options(self) -> bool:
        completion_state = getattr(self.app, "_completion_state", None)
        return bool(getattr(completion_state, "items", ()))

    def _completion_target(self) -> CompletionActionTarget:
        return cast(CompletionActionTarget, self.app)


class SessionPickerScreen(ModalScreen[str | None]):
    """Searchable modal picker for indexed sessions."""

    def __init__(
        self,
        records: Sequence[SessionCompletionRecord],
        *,
        theme: TuiTheme,
        all_records: Sequence[SessionCompletionRecord] | None = None,
        current_session_id: str | None = None,
        keybindings: TuiKeybindings | None = None,
        rename_session: Callable[[str, str], SessionCompletionRecord | None] | None = None,
        delete_session: Callable[[str], bool] | None = None,
    ) -> None:
        super().__init__()
        self.current_records = tuple(records)
        self.all_records = tuple(all_records if all_records is not None else records)
        self.filtered_records = self.current_records
        self.theme = theme
        self.current_session_id = current_session_id
        self.keybindings = keybindings or TuiKeybindings()
        self.search_value = ""
        self.scope: Literal["current", "all"] = "current"
        self.mode: Literal["list", "rename"] = "list"
        self.rename_target_id: str | None = None
        self.rename_previous_query = ""
        self.rename_session = rename_session
        self.delete_confirm_target_id: str | None = None
        self.delete_session = delete_session
        self.named_only = False
        self.show_path = False
        self.sort_mode: SessionPickerSortMode = "threaded"

    def compose(self) -> ComposeResult:
        """Compose the session picker."""
        with Vertical(id="session-picker"):
            yield Static("Sessions", id="session-picker-title")
            yield Input(placeholder="Search sessions", id="session-picker-search")
            yield ListView(
                *[
                    ListItem(
                        Label(
                            _session_picker_label(
                                record,
                                show_path=self.show_path,
                                current_session_id=self.current_session_id,
                            ),
                            markup=False,
                        )
                    )
                    for record in self.filtered_records
                ],
                id="session-picker-list",
            )
            yield Static("", id="session-picker-help")

    def on_mount(self) -> None:
        """Focus search input for Pi-style picker filtering."""
        self._refresh_session_list()
        self.query_one("#session-picker-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter sessions as the search value changes."""
        if event.input.id != "session-picker-search":
            return
        if self.mode == "rename":
            return
        self.search_value = event.value
        self._refresh_session_list()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Select the highlighted filtered session from the search input."""
        if event.input.id != "session-picker-search":
            return
        event.stop()
        if self.mode == "rename":
            self._confirm_rename(event.value)
            return
        self.action_select_cursor()

    def _refresh_session_list(self) -> None:
        """Rebuild the visible session rows from the current search query."""
        if self.mode == "rename":
            return
        self.query_one("#session-picker-title", Static).update(_session_picker_title(self.scope))
        records = self.current_records if self.scope == "current" else self.all_records
        self.filtered_records = _filter_session_picker_records(
            records,
            self.search_value,
            named_only=self.named_only,
            sort_mode=self.sort_mode,
        )
        tree_depths = (
            _session_picker_thread_depths(self.filtered_records)
            if self.sort_mode == "threaded"
            else {}
        )
        session_list = self.query_one("#session-picker-list", ListView)
        session_list.clear()
        session_list.extend(
            ListItem(
                Label(
                    _session_picker_label(
                        record,
                        show_path=self.show_path,
                        current_session_id=self.current_session_id,
                        thread_depth=tree_depths.get(record.id, 0),
                    ),
                    markup=False,
                )
            )
            for record in self.filtered_records
        )
        session_list.index = 0 if self.filtered_records else None
        scope_state = f"scope:{self.scope}"
        named_state = "named:on" if self.named_only else "named:off"
        path_state = "path:on" if self.show_path else "path:off"
        sort_state = f"sort:{_session_picker_sort_label(self.sort_mode)}"
        named_key = _key_hint_with_default(self.keybindings.session_toggle_named_filter, "ctrl+n")
        path_key = _key_hint_with_default(self.keybindings.session_toggle_path, "ctrl+p")
        sort_key = _key_hint_with_default(self.keybindings.session_toggle_sort, "ctrl+s")
        rename_key = _key_hint_with_default(self.keybindings.session_rename, "ctrl+r,f2")
        delete_key = _key_hint_with_default(self.keybindings.session_delete, "ctrl+d")
        select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        if self.filtered_records:
            help_text = (
                f'Type to search, re:<pattern> regex, or "phrase" exact - '
                f"Tab {scope_state} - {named_key} {named_state} - {path_key} {path_state} - "
                f"{sort_key} {sort_state} - "
                f"{rename_key} rename - {delete_key} delete - "
                f"{select_key} selects - {cancel_key} closes"
            )
        else:
            empty_message = _session_picker_empty_message(
                scope=self.scope,
                named_only=self.named_only,
                named_key=named_key,
            )
            help_text = (
                f'{empty_message} - re:<pattern> regex, "phrase" exact - '
                f"Tab {scope_state} - {named_key} {named_state} - {path_key} {path_state} - "
                f"{sort_key} {sort_state} - {cancel_key} closes"
            )
        self.query_one("#session-picker-help", Static).update(help_text)

    def on_key(self, event: Key) -> None:
        """Route session picker keys to the list."""
        if self.mode == "rename":
            return
        if self.delete_confirm_target_id is not None:
            if (
                _matches_configured_or_default_key(
                    event.key,
                    self.keybindings.select_confirm,
                    "enter",
                )
                or _matches_configured_or_default_key(
                    event.key,
                    self.keybindings.session_delete,
                    "ctrl+d",
                )
                or (
                    not self.search_value.strip()
                    and _matches_configured_or_default_key(
                        event.key,
                        self.keybindings.session_delete_noninvasive,
                        "ctrl+backspace",
                    )
                )
            ):
                event.stop()
                self.action_confirm_delete_session()
                return
            if _matches_configured_or_default_key(
                event.key,
                self.keybindings.select_cancel,
                "escape",
            ):
                event.stop()
                self.delete_confirm_target_id = None
                self._refresh_session_list()
                return
            event.stop()
            return
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.delete_confirm_target_id = None
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.delete_confirm_target_id = None
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.delete_confirm_target_id = None
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.delete_confirm_target_id = None
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            self.action_toggle_scope()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.session_delete,
            "ctrl+d",
        ):
            event.stop()
            self.action_delete_session()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.session_rename,
            "ctrl+r,f2",
        ):
            event.stop()
            self.action_start_rename()
        elif (
            _matches_configured_or_default_key(
                event.key,
                self.keybindings.session_delete_noninvasive,
                "ctrl+backspace",
            )
            and not self.search_value.strip()
        ):
            event.stop()
            self.action_delete_session_noninvasive()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.session_toggle_named_filter,
            "ctrl+n",
        ):
            event.stop()
            self.action_toggle_named_filter()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.session_toggle_path,
            "ctrl+p",
        ):
            event.stop()
            self.action_toggle_path()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.session_toggle_sort,
            "ctrl+s",
        ):
            event.stop()
            self.action_toggle_sort()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected session id."""
        if self.mode != "list":
            return
        if event.index < 0 or event.index >= len(self.filtered_records):
            return
        self.dismiss(self.filtered_records[event.index].id)

    def action_cursor_up(self) -> None:
        """Move to the previous session."""
        self.query_one("#session-picker-list", ListView).action_cursor_up()

    def action_cursor_down(self) -> None:
        """Move to the next session."""
        self.query_one("#session-picker-list", ListView).action_cursor_down()

    def action_page_up(self) -> None:
        """Move up by a page of sessions."""
        self._move_session_page(-1)

    def action_page_down(self) -> None:
        """Move down by a page of sessions."""
        self._move_session_page(1)

    def _move_session_page(self, direction: Literal[-1, 1]) -> None:
        """Move the selected session by a viewport-sized page."""
        if not self.filtered_records:
            return
        session_list = self.query_one("#session-picker-list", ListView)
        current_index = session_list.index if session_list.index is not None else 0
        page_size = max(1, session_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        next_index = current_index + (direction * page_size)
        session_list.index = max(0, min(len(self.filtered_records) - 1, next_index))

    def action_select_cursor(self) -> None:
        """Select the highlighted session."""
        if self.mode != "list":
            return
        if not self.filtered_records:
            return
        self.query_one("#session-picker-list", ListView).action_select_cursor()

    def action_start_rename(self) -> None:
        """Rename the highlighted session."""
        if self.rename_session is None or self.mode != "list":
            return
        self.delete_confirm_target_id = None
        selected = self._selected_session_record()
        if selected is None:
            return
        self.mode = "rename"
        self.rename_target_id = selected.id
        self.rename_previous_query = self.search_value
        title = _named_session_title(selected.title) or ""
        search = self.query_one("#session-picker-search", Input)
        search.placeholder = "Rename session"
        search.value = title
        search.focus()
        self.query_one("#session-picker-title", Static).update("Rename Session")
        save_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        self.query_one("#session-picker-help", Static).update(
            f"{save_key} saves - {cancel_key} cancels rename"
        )

    def _confirm_rename(self, value: str) -> None:
        """Save the active rename target and return to list mode."""
        name = value.strip()
        if not name:
            self.query_one("#session-picker-help", Static).update("Session name is required.")
            return
        if any(char in name for char in "\r\n\t"):
            self.query_one("#session-picker-help", Static).update(
                "Session name must be a single line."
            )
            return
        target_id = self.rename_target_id
        rename_session = self.rename_session
        if target_id is None or rename_session is None:
            self._exit_rename_mode()
            return
        updated = rename_session(target_id, name)
        if updated is None:
            self.query_one("#session-picker-help", Static).update(f"Unknown session: {target_id}")
            return
        self.current_records = _replace_session_picker_record(self.current_records, updated)
        self.all_records = _replace_session_picker_record(self.all_records, updated)
        self._exit_rename_mode()

    def _exit_rename_mode(self) -> None:
        """Return from rename mode to list mode."""
        self.mode = "list"
        self.rename_target_id = None
        self.search_value = self.rename_previous_query
        search = self.query_one("#session-picker-search", Input)
        search.placeholder = "Search sessions"
        search.value = self.search_value
        self.query_one("#session-picker-title", Static).update(_session_picker_title(self.scope))
        self._refresh_session_list()

    def _selected_session_record(self) -> SessionCompletionRecord | None:
        """Return the currently highlighted filtered session."""
        if not self.filtered_records:
            return None
        index = self.query_one("#session-picker-list", ListView).index
        if index is None or index < 0 or index >= len(self.filtered_records):
            return None
        return self.filtered_records[index]

    def action_delete_session(self) -> None:
        """Delete the highlighted session after a second delete press confirms it."""
        if self.delete_session is None or self.mode != "list":
            return
        selected = self._selected_session_record()
        if selected is None:
            return
        if selected.id == self.current_session_id:
            self.delete_confirm_target_id = None
            self.query_one("#session-picker-help", Static).update(
                "Cannot delete the active session."
            )
            return
        if self.delete_confirm_target_id != selected.id:
            self.delete_confirm_target_id = selected.id
            confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            delete_key = _key_hint_with_default(self.keybindings.session_delete, "ctrl+d")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            self.query_one("#session-picker-help", Static).update(
                f"Press {delete_key} again or {confirm_key} to delete this session - "
                f"{cancel_key} cancels"
            )
            return
        self.action_confirm_delete_session()

    def action_confirm_delete_session(self) -> None:
        """Delete the pending session delete target."""
        target_id = self.delete_confirm_target_id
        if target_id is None or self.delete_session is None:
            return
        selected = next(
            (record for record in self.filtered_records if record.id == target_id),
            None,
        )
        if selected is None:
            self.delete_confirm_target_id = None
            self._refresh_session_list()
            return
        self.delete_confirm_target_id = None
        if not self.delete_session(target_id):
            self.query_one("#session-picker-help", Static).update(
                f"Failed to delete session: {target_id}"
            )
            return
        self.current_records = _remove_session_picker_record(self.current_records, target_id)
        self.all_records = _remove_session_picker_record(self.all_records, target_id)
        self._refresh_session_list()

    def action_delete_session_noninvasive(self) -> None:
        """Delete only when the picker query is empty."""
        if self.search_value.strip():
            return
        self.action_delete_session()

    def action_toggle_scope(self) -> None:
        """Toggle between current-project sessions and all indexed sessions."""
        self.delete_confirm_target_id = None
        self.scope = "all" if self.scope == "current" else "current"
        self._refresh_session_list()

    def action_toggle_named_filter(self) -> None:
        """Toggle whether the picker shows only named sessions."""
        self.delete_confirm_target_id = None
        self.named_only = not self.named_only
        self._refresh_session_list()

    def action_toggle_path(self) -> None:
        """Toggle session path visibility."""
        self.delete_confirm_target_id = None
        self.show_path = not self.show_path
        self._refresh_session_list()

    def action_toggle_sort(self) -> None:
        """Toggle session sort order."""
        self.delete_confirm_target_id = None
        sort_order: tuple[SessionPickerSortMode, ...] = (
            "threaded",
            "recent",
            "relevance",
        )
        self.sort_mode = sort_order[(sort_order.index(self.sort_mode) + 1) % len(sort_order)]
        self._refresh_session_list()

    def action_cancel(self) -> None:
        """Close the picker without selecting a session."""
        if self.mode == "rename":
            self._exit_rename_mode()
            return
        if self.delete_confirm_target_id is not None:
            self.delete_confirm_target_id = None
            self._refresh_session_list()
            return
        self.dismiss(None)


@dataclass(frozen=True, slots=True)
class TreePickerResult:
    """Tree-picker branch selection."""

    entry_id: str
    summarize: bool = False
    custom_instructions: str | None = None


SettingsPickerKey = Literal[
    "autocomplete_max_visible",
    "auto_resize_images",
    "block_images",
    "clear_on_shrink",
    "editor_padding_x",
    "enable_skill_commands",
    "image_width_cells",
    "output_padding_x",
    "quiet_startup",
    "collapse_changelog",
    "sidebar_position",
    "show_images",
    "show_hardware_cursor",
    "show_terminal_progress",
    "anthropic_extra_usage_warning",
    "theme",
    "turn_notification",
    "auto_compact",
    "steering_mode",
    "follow_up_mode",
    "http_idle_timeout_ms",
    "default_project_trust",
    "auto_copy_selection",
    "external_editor",
    "hide_thinking",
    "thinking_level",
    "double_escape_action",
    "tree_filter_mode",
]


@dataclass(frozen=True, slots=True)
class SettingsPickerItem:
    """One durable TUI setting row."""

    key: SettingsPickerKey
    label: str
    value: str
    description: str = ""


class SettingsPickerSearchInput(Input):
    """Search input that keeps settings-picker control keys local to the picker."""

    def _picker(self) -> SettingsPickerScreen:
        return cast(SettingsPickerScreen, self.screen)

    def on_key(self, event: Key) -> None:
        """Route picker control keys before the input edits its text."""
        keybindings = self._picker().keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            self._picker().action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            self._picker().action_cursor_down()
        elif (
            _matches_configured_or_default_key(
                event.key,
                keybindings.select_confirm,
                "enter",
            )
            or event.key == "space"
        ):
            event.stop()
            event.prevent_default()
            self._picker().action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            event.prevent_default()
            self._picker().action_cancel()


class SettingsPickerScreen(ModalScreen[None]):
    """Modal picker for durable TUI settings."""

    def __init__(
        self,
        settings: TuiSettings,
        *,
        apply_settings: Callable[[TuiSettings], None],
        thinking_levels: Sequence[ThinkingLevel] = THINKING_LEVELS,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.settings = settings
        self.apply_settings = apply_settings
        self.thinking_levels = tuple(thinking_levels) or THINKING_LEVELS
        self.keybindings = keybindings or TuiKeybindings()
        self.search_value = ""
        self.filtered_items = _settings_picker_items(settings)

    def compose(self) -> ComposeResult:
        """Compose the settings picker."""
        with Vertical(id="settings-picker"):
            yield Static("Settings", id="settings-picker-title")
            yield SettingsPickerSearchInput(
                placeholder="Search settings",
                id="settings-picker-search",
            )
            yield ListView(
                *self._list_items(),
                id="settings-picker-list",
            )
            yield Static(self._help_text(), id="settings-picker-help")

    def on_mount(self) -> None:
        """Focus the settings search input."""
        self._refresh_settings_list(0)
        self.query_one("#settings-picker-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter settings as the search value changes."""
        if event.input.id != "settings-picker-search":
            return
        self.search_value = event.value
        self._refresh_settings_list(0)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Change the highlighted filtered setting from the search input."""
        if event.input.id != "settings-picker-search":
            return
        event.stop()
        self.action_select_cursor()

    def on_key(self, event: Key) -> None:
        """Route settings picker keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Change the selected setting and keep the picker open."""
        if event.index >= len(self.filtered_items):
            return
        self._change_setting(event.index)

    def action_cursor_up(self) -> None:
        """Move to the previous setting."""
        self._move(-1)
        self._refresh_help_text()

    def action_cursor_down(self) -> None:
        """Move to the next setting."""
        self._move(1)
        self._refresh_help_text()

    def action_select_cursor(self) -> None:
        """Change the highlighted setting."""
        settings_list = self.query_one("#settings-picker-list", ListView)
        if settings_list.index is None:
            return
        self._change_setting(settings_list.index)

    def action_cancel(self) -> None:
        """Close the settings picker."""
        self.dismiss(None)

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Refresh the selected setting description as the highlight changes."""
        if event.list_view.id == "settings-picker-list":
            self._refresh_help_text()

    def _change_setting(self, index: int) -> None:
        if index >= len(self.filtered_items):
            return
        selected_key = self.filtered_items[index].key
        if selected_key == "external_editor":
            self.app.push_screen(
                ExtensionInputScreen(
                    "External editor",
                    placeholder="Command, e.g. code --wait or vim",
                    prefill=self.settings.external_editor or "",
                    keybindings=self.keybindings,
                ),
                self._handle_external_editor_result,
            )
            return
        self.settings = _next_tui_settings(
            self.settings,
            selected_key,
            thinking_levels=self.thinking_levels,
        )
        self.apply_settings(self.settings)
        self._refresh_settings_list(index)

    def _handle_external_editor_result(self, command: str | None) -> None:
        if command is None:
            return
        self.settings = replace(self.settings, external_editor=command.strip() or None)
        self.apply_settings(self.settings)
        settings_list = self.query_one("#settings-picker-list", ListView)
        index = settings_list.index if settings_list.index is not None else 0
        self._refresh_settings_list(index)

    def _move(self, direction: Literal[-1, 1]) -> None:
        settings_list = self.query_one("#settings-picker-list", ListView)
        if not self.filtered_items:
            settings_list.index = None
            return
        current_index = settings_list.index if settings_list.index is not None else 0
        settings_list.index = (current_index + direction) % len(self.filtered_items)

    def _refresh_settings_list(self, index: int) -> None:
        self.filtered_items = _filter_settings_picker_items(
            _settings_picker_items(self.settings),
            self.search_value,
        )
        settings_list = self.query_one("#settings-picker-list", ListView)
        settings_list.clear()
        settings_list.extend(self._list_items())
        settings_list.index = (
            min(index, len(settings_list.children) - 1) if self.filtered_items else None
        )
        self._refresh_help_text()

    def _list_items(self) -> list[ListItem]:
        if not self.filtered_items:
            return [ListItem(Label(_settings_picker_empty_label(self), markup=False))]
        return [
            ListItem(Label(_settings_picker_label(item), markup=False))
            for item in self.filtered_items
        ]

    def _help_text(self) -> str:
        change_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        if not self.filtered_items:
            return f"No matching settings - {cancel_key} closes"
        try:
            settings_list = self.query_one("#settings-picker-list", ListView)
        except NoMatches:
            return f"Type to search - {change_key}/Space changes - {cancel_key} closes"
        index = settings_list.index
        if index is None or index >= len(self.filtered_items):
            return f"Type to search - {change_key}/Space changes - {cancel_key} closes"
        description = self.filtered_items[index].description.strip()
        if description:
            return f"{description} - {change_key}/Space changes - {cancel_key} closes"
        return f"Type to search - {change_key}/Space changes - {cancel_key} closes"

    def _refresh_help_text(self) -> None:
        self.query_one("#settings-picker-help", Static).update(self._help_text())


class ThinkingPickerListView(ListView):
    """List view that keeps thinking-picker navigation local."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("up", "thinking_cursor_up", "Up", priority=True),
        Binding("down", "thinking_cursor_down", "Down", priority=True),
        Binding("enter", "thinking_select_cursor", "Select", priority=True),
        Binding("escape", "thinking_cancel", "Cancel", priority=True),
    ]

    def _picker(self) -> ThinkingPickerScreen:
        return cast(ThinkingPickerScreen, self.screen)

    def action_thinking_cursor_up(self) -> None:
        """Move to the previous thinking level."""
        self._picker().action_cursor_up()

    def action_thinking_cursor_down(self) -> None:
        """Move to the next thinking level."""
        self._picker().action_cursor_down()

    def action_thinking_select_cursor(self) -> None:
        """Select the highlighted thinking level."""
        self._picker().action_select_cursor()

    def action_thinking_cancel(self) -> None:
        """Close the picker without changing thinking level."""
        self._picker().action_cancel()


class ThinkingPickerScreen(ModalScreen[str | None]):
    """Modal picker for the active model's thinking levels."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("up", "cursor_up", "Up", priority=True),
        Binding("down", "cursor_down", "Down", priority=True),
        Binding("enter", "select_cursor", "Select", priority=True),
        Binding("escape", "cancel", "Cancel", priority=True),
    ]

    def __init__(
        self,
        current_level: str,
        thinking_levels: Sequence[ThinkingLevel],
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.current_level = current_level
        self.thinking_levels = tuple(thinking_levels)
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the thinking-level picker."""
        with Vertical(id="thinking-picker"):
            yield Static("Thinking", id="thinking-picker-title")
            yield ThinkingPickerListView(
                *self._list_items(),
                id="thinking-picker-list",
            )
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            yield Static(
                f"{select_key} selects - {cancel_key} cancels",
                id="thinking-picker-help",
            )

    def on_mount(self) -> None:
        """Focus the thinking-level list and preselect the current level."""
        thinking_list = self.query_one("#thinking-picker-list", ListView)
        try:
            thinking_list.index = self.thinking_levels.index(
                cast(ThinkingLevel, self.current_level)
            )
        except ValueError:
            thinking_list.index = 0 if self.thinking_levels else None
        thinking_list.focus()

    def on_key(self, event: Key) -> None:
        """Route picker keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected thinking level."""
        if event.index >= len(self.thinking_levels):
            return
        self.dismiss(self.thinking_levels[event.index])

    def action_cursor_up(self) -> None:
        """Move to the previous thinking level."""
        self._move(-1)

    def action_cursor_down(self) -> None:
        """Move to the next thinking level."""
        self._move(1)

    def action_select_cursor(self) -> None:
        """Select the highlighted thinking level."""
        self.query_one("#thinking-picker-list", ListView).action_select_cursor()

    def action_cancel(self) -> None:
        """Close the picker without changing thinking level."""
        self.dismiss(None)

    def _move(self, direction: Literal[-1, 1]) -> None:
        if not self.thinking_levels:
            return
        thinking_list = self.query_one("#thinking-picker-list", ListView)
        current_index = thinking_list.index if thinking_list.index is not None else 0
        thinking_list.index = (current_index + direction) % len(self.thinking_levels)

    def _list_items(self) -> list[ListItem]:
        return [
            ListItem(Label(_thinking_picker_label(level, self.current_level), markup=False))
            for level in self.thinking_levels
        ]


class ImageVisibilityPickerScreen(ModalScreen[bool | None]):
    """Modal picker for inline tool image rendering."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("up", "cursor_up", "Up", priority=True),
        Binding("down", "cursor_down", "Down", priority=True),
        Binding("enter", "select_cursor", "Select", priority=True),
        Binding("escape", "cancel", "Cancel", priority=True),
    ]

    def __init__(
        self,
        current_value: bool,
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.current_value = current_value
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the image visibility picker."""
        with Vertical(id="image-visibility-picker"):
            yield Static("Images", id="image-visibility-picker-title")
            yield ListView(
                *self._list_items(),
                id="image-visibility-picker-list",
            )
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            yield Static(
                f"{select_key} selects - {cancel_key} cancels",
                id="image-visibility-picker-help",
            )

    def on_mount(self) -> None:
        """Focus the image visibility list and preselect the current setting."""
        image_list = self.query_one("#image-visibility-picker-list", ListView)
        image_list.index = 0 if self.current_value else 1
        image_list.focus()

    def on_key(self, event: Key) -> None:
        """Route picker keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected image visibility setting."""
        if event.index == 0:
            self.dismiss(True)
        elif event.index == 1:
            self.dismiss(False)

    def action_cursor_up(self) -> None:
        """Move to the previous image visibility option."""
        self._move(-1)

    def action_cursor_down(self) -> None:
        """Move to the next image visibility option."""
        self._move(1)

    def action_select_cursor(self) -> None:
        """Select the highlighted image visibility option."""
        self.query_one("#image-visibility-picker-list", ListView).action_select_cursor()

    def action_cancel(self) -> None:
        """Close the picker without changing image visibility."""
        self.dismiss(None)

    def _move(self, direction: Literal[-1, 1]) -> None:
        image_list = self.query_one("#image-visibility-picker-list", ListView)
        current_index = image_list.index if image_list.index is not None else 0
        image_list.index = (current_index + direction) % 2

    def _list_items(self) -> list[ListItem]:
        return [
            ListItem(
                Label(
                    _image_visibility_picker_label(
                        True,
                        current_value=self.current_value,
                    ),
                    markup=False,
                )
            ),
            ListItem(
                Label(
                    _image_visibility_picker_label(
                        False,
                        current_value=self.current_value,
                    ),
                    markup=False,
                )
            ),
        ]


@dataclass(frozen=True, slots=True)
class FirstTimeSetupChoice:
    """One first-run setup option."""

    label: str
    value: str | None
    description: str


class FirstTimeSetupScreen(ModalScreen[TuiSettings | None]):
    """First-run setup screen for choosing Tau's initial TUI theme."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("up", "cursor_up", "Up", priority=True),
        Binding("down", "cursor_down", "Down", priority=True),
        Binding("enter", "select_cursor", "Select", priority=True),
        Binding("escape", "cancel", "Cancel", priority=True),
    ]

    def __init__(
        self,
        settings: TuiSettings,
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.settings = settings
        self.keybindings = keybindings or TuiKeybindings()
        self.choices = _first_time_setup_choices()

    def compose(self) -> ComposeResult:
        """Compose the first-run setup screen."""
        with Vertical(id="first-time-setup"):
            yield Static("Welcome to Tau", id="first-time-setup-title")
            yield Static("Choose an initial theme.", id="first-time-setup-description")
            yield ListView(*self._list_items(), id="first-time-setup-list")
            yield Static(self._help_text(), id="first-time-setup-help")

    def on_mount(self) -> None:
        """Focus the setup list and preselect the current theme."""
        setup_list = self.query_one("#first-time-setup-list", ListView)
        setup_list.index = _first_time_setup_selected_index(self.choices, self.settings.theme)
        setup_list.focus()
        self.call_after_refresh(setup_list.focus)

    def on_key(self, event: Key) -> None:
        """Route setup keys to the list."""
        if (
            _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up")
            or event.key == "k"
        ):
            event.stop()
            self.action_cursor_up()
        elif (
            _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down")
            or event.key == "j"
        ):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Apply the selected first-run choice."""
        event.stop()
        self.action_select()

    def action_cursor_up(self) -> None:
        """Move to the previous setup option."""
        setup_list = self.query_one("#first-time-setup-list", ListView)
        index = setup_list.index if setup_list.index is not None else 0
        setup_list.index = (index - 1) % len(self.choices)

    def action_cursor_down(self) -> None:
        """Move to the next setup option."""
        setup_list = self.query_one("#first-time-setup-list", ListView)
        index = setup_list.index if setup_list.index is not None else 0
        setup_list.index = (index + 1) % len(self.choices)

    def action_select(self) -> None:
        """Select the highlighted setup option."""
        setup_list = self.query_one("#first-time-setup-list", ListView)
        index = setup_list.index
        if index is None or index >= len(self.choices):
            return
        choice = self.choices[index]
        if choice.value is None:
            self.dismiss(None)
            return
        self.dismiss(replace(self.settings, theme=choice.value))

    def action_select_cursor(self) -> None:
        """Select the highlighted setup row."""
        self.query_one("#first-time-setup-list", ListView).action_select_cursor()

    def action_cancel(self) -> None:
        """Skip first-run setup."""
        self.dismiss(None)

    def _list_items(self) -> list[ListItem]:
        return [
            ListItem(Label(f"{choice.label} - {choice.description}", markup=False))
            for choice in self.choices
        ]

    def _help_text(self) -> str:
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        return f"{confirm_key} selects - {cancel_key} skips setup"


class TrustPickerScreen(ModalScreen[ProjectTrustOption | None]):
    """Modal picker for project trust decisions."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("k", "cursor_up", "Up", priority=True),
        Binding("j", "cursor_down", "Down", priority=True),
    ]

    def __init__(
        self,
        state: ProjectTrustState,
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.trust_state = state
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the trust picker."""
        with Vertical(id="trust-picker"):
            yield Static("Project trust", id="trust-picker-title")
            yield Static(str(self.trust_state.cwd), id="trust-picker-cwd", markup=False)
            yield Static(
                f"Saved decision: {_project_trust_decision_label(self.trust_state.saved_decision)}",
                id="trust-picker-current",
                markup=False,
            )
            yield Static(
                f"Current session: {_project_trust_session_label(self.trust_state)}",
                id="trust-picker-session",
                markup=False,
            )
            yield ListView(
                *self._list_items(),
                id="trust-picker-list",
            )
            save_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            yield Static(f"{save_key} saves - {cancel_key} closes", id="trust-picker-help")

    def on_mount(self) -> None:
        """Focus the trust list."""
        trust_list = self.query_one("#trust-picker-list", ListView)
        trust_list.index = _project_trust_saved_option_index(self.trust_state)
        trust_list.focus()

    def on_key(self, event: Key) -> None:
        """Route trust picker keys to the list."""
        if (
            _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up")
            or event.key == "k"
        ):
            event.stop()
            self.action_cursor_up()
        elif (
            _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down")
            or event.key == "j"
        ):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected trust option."""
        if event.index >= len(self.trust_state.options):
            return
        self.dismiss(self.trust_state.options[event.index])

    def action_cursor_up(self) -> None:
        """Move to the previous trust option."""
        self.query_one("#trust-picker-list", ListView).action_cursor_up()

    def action_cursor_down(self) -> None:
        """Move to the next trust option."""
        self.query_one("#trust-picker-list", ListView).action_cursor_down()

    def action_select_cursor(self) -> None:
        """Choose the highlighted trust option."""
        trust_list = self.query_one("#trust-picker-list", ListView)
        if trust_list.index is None:
            return
        if trust_list.index >= len(self.trust_state.options):
            return
        self.dismiss(self.trust_state.options[trust_list.index])

    def action_cancel(self) -> None:
        """Cancel the trust picker."""
        self.dismiss(None)

    def _list_items(self) -> list[ListItem]:
        return [
            ListItem(
                Label(
                    _project_trust_option_label(item, self.trust_state.saved_decision),
                    markup=False,
                )
            )
            for item in self.trust_state.options
        ]


class UserMessagePickerScreen(ModalScreen[str | None]):
    """Modal picker for forking from a previous user message."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("k", "cursor_up", "Up", priority=True),
        Binding("j", "cursor_down", "Down", priority=True),
    ]

    def __init__(
        self,
        choices: Sequence[SessionTreeChoice],
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.choices = tuple(choices)
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the user-message picker."""
        with Vertical(id="user-message-picker"):
            yield Static("Fork from Message", id="user-message-picker-title")
            yield Static(
                "Select a user message to copy the active path up to that point "
                "into a new session.",
                id="user-message-picker-description",
            )
            yield ListView(
                *self._list_items(),
                id="user-message-picker-list",
            )
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            yield Static(
                f"{select_key} forks - {cancel_key} cancels",
                id="user-message-picker-help",
            )

    def on_mount(self) -> None:
        """Focus the user-message list for keyboard navigation."""
        message_list = self.query_one("#user-message-picker-list", ListView)
        message_list.index = len(self.choices) - 1 if self.choices else None
        message_list.focus()

    def on_key(self, event: Key) -> None:
        """Route picker keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected entry id."""
        if event.index >= len(self.choices):
            return
        self.dismiss(self.choices[event.index].entry_id)

    def action_cursor_up(self) -> None:
        """Move to the previous user message."""
        self._move(-1)

    def action_cursor_down(self) -> None:
        """Move to the next user message."""
        self._move(1)

    def action_page_up(self) -> None:
        """Move up by a page of user messages."""
        self._move_page(-1)

    def action_page_down(self) -> None:
        """Move down by a page of user messages."""
        self._move_page(1)

    def _move(self, direction: Literal[-1, 1]) -> None:
        if not self.choices:
            return
        message_list = self.query_one("#user-message-picker-list", ListView)
        current_index = message_list.index if message_list.index is not None else 0
        message_list.index = (current_index + direction) % len(self.choices)

    def _move_page(self, direction: Literal[-1, 1]) -> None:
        if not self.choices:
            return
        message_list = self.query_one("#user-message-picker-list", ListView)
        current_index = message_list.index if message_list.index is not None else 0
        page_size = max(1, message_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        next_index = current_index + (direction * page_size)
        message_list.index = max(0, min(len(self.choices) - 1, next_index))

    def action_select_cursor(self) -> None:
        """Fork from the highlighted user message."""
        self.query_one("#user-message-picker-list", ListView).action_select_cursor()

    def action_cancel(self) -> None:
        """Close the picker without forking."""
        self.dismiss(None)

    def _list_items(self) -> list[ListItem]:
        total = len(self.choices)
        return [
            ListItem(Label(_user_message_picker_label(choice, index, total), markup=False))
            for index, choice in enumerate(self.choices)
        ]


type WorkflowPickerAction = Literal["details", "insert_run"]


@dataclass(frozen=True, slots=True)
class WorkflowPickerResult:
    workflow_id: str
    action: WorkflowPickerAction


class WorkflowPickerScreen(ModalScreen[WorkflowPickerResult | None]):
    """Modal picker for packaged canonical Tau workflows."""

    def __init__(
        self,
        workflows: Sequence[WorkflowDefinition],
        *,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.workflows = tuple(workflows)
        self.filtered_workflows = self.workflows
        self.search_value = ""
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the workflow picker."""
        with Vertical(id="workflow-picker"):
            yield Static("Canonical Workflows", id="workflow-picker-title")
            yield Static(
                "Select a packaged Tau DAG; Ctrl+R inserts a bounded viewer run command.",
                id="workflow-picker-description",
            )
            yield Input(placeholder="Search workflows", id="workflow-picker-search")
            yield ListView(
                *self._list_items(),
                id="workflow-picker-list",
            )
            yield Static(self._help_text(), id="workflow-picker-help")

    def on_mount(self) -> None:
        """Focus the workflow search input."""
        self._refresh_workflow_list(0)
        self.query_one("#workflow-picker-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter workflows as the search value changes."""
        if event.input.id != "workflow-picker-search":
            return
        self.search_value = event.value
        self._refresh_workflow_list(0)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Open details for the highlighted filtered workflow."""
        if event.input.id != "workflow-picker-search":
            return
        event.stop()
        self.action_select_cursor()

    def on_key(self, event: Key) -> None:
        """Route configured Pi select keys to the workflow list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif event.key == "ctrl+r":
            event.stop()
            self.action_insert_run_command()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected workflow id."""
        if event.index >= len(self.filtered_workflows):
            return
        self.dismiss(
            WorkflowPickerResult(self.filtered_workflows[event.index].workflow_id, "details")
        )

    def action_cursor_up(self) -> None:
        """Move to the previous workflow."""
        self.query_one("#workflow-picker-list", ListView).action_cursor_up()

    def action_cursor_down(self) -> None:
        """Move to the next workflow."""
        self.query_one("#workflow-picker-list", ListView).action_cursor_down()

    def action_page_up(self) -> None:
        """Move up by a page of workflows."""
        self._move_page(-1)

    def action_page_down(self) -> None:
        """Move down by a page of workflows."""
        self._move_page(1)

    def _move_page(self, direction: Literal[-1, 1]) -> None:
        if not self.filtered_workflows:
            return
        workflow_list = self.query_one("#workflow-picker-list", ListView)
        current_index = workflow_list.index if workflow_list.index is not None else 0
        page_size = max(1, workflow_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        next_index = current_index + (direction * page_size)
        workflow_list.index = max(0, min(len(self.filtered_workflows) - 1, next_index))

    def action_select_cursor(self) -> None:
        """Open details for the highlighted workflow."""
        self.query_one("#workflow-picker-list", ListView).action_select_cursor()

    def action_insert_run_command(self) -> None:
        """Insert a runnable shell command for the highlighted workflow."""
        workflow_list = self.query_one("#workflow-picker-list", ListView)
        if workflow_list.index is None or workflow_list.index >= len(self.filtered_workflows):
            return
        self.dismiss(
            WorkflowPickerResult(
                self.filtered_workflows[workflow_list.index].workflow_id,
                "insert_run",
            )
        )

    def action_cancel(self) -> None:
        """Close the picker without selecting a workflow."""
        self.dismiss(None)

    def _list_items(self) -> list[ListItem]:
        return [
            ListItem(Label(_workflow_picker_label(workflow), markup=False))
            for workflow in self.filtered_workflows
        ]

    def _refresh_workflow_list(self, index: int) -> None:
        self.filtered_workflows = _filter_workflow_picker_records(
            self.workflows,
            self.search_value,
        )
        workflow_list = self.query_one("#workflow-picker-list", ListView)
        workflow_list.clear()
        workflow_list.extend(self._list_items())
        workflow_list.index = (
            min(index, len(workflow_list.children) - 1) if self.filtered_workflows else None
        )
        self.query_one("#workflow-picker-help", Static).update(self._help_text())

    def _help_text(self) -> str:
        details_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        if self.filtered_workflows:
            return (
                f"Type to search - {details_key} opens details - "
                f"Ctrl+R inserts run command - {cancel_key} cancels"
            )
        return f"No matching workflows - {cancel_key} cancels"


TreeFilterMode = Literal["default", "no-tools", "user-only", "labeled-only", "all"]
TREE_FILTER_MODES: tuple[TreeFilterMode, ...] = (
    "default",
    "no-tools",
    "user-only",
    "labeled-only",
    "all",
)


class TreePickerScreen(ModalScreen[TreePickerResult | None]):
    """Modal picker for branching from a previous session entry."""

    def __init__(
        self,
        choices: Sequence[SessionTreeChoice],
        *,
        theme: TuiTheme,
        initial_filter_mode: TreeFilterMode = "default",
        keybindings: TuiKeybindings | None = None,
        set_entry_label: Callable[[str, str | None], object] | None = None,
    ) -> None:
        super().__init__()
        self.choices = tuple(choices)
        self.theme = theme
        self.set_entry_label = set_entry_label
        self.keybindings = keybindings or TuiKeybindings()
        self.show_tool_calls = True
        self.show_label_timestamps = False
        self.filter_mode = initial_filter_mode
        self.show_tool_calls = self.filter_mode != "no-tools"
        self.folded_entry_ids: set[str] = set()
        self.search_value = ""

    def compose(self) -> ComposeResult:
        """Compose the tree picker."""
        with Vertical(id="tree-picker"):
            yield Static("Session Tree", id="tree-picker-title")
            yield Static(self._search_text(), id="tree-picker-search")
            yield ListView(
                *self._list_items(),
                id="tree-picker-list",
            )
            yield Static(
                self._help_text(),
                id="tree-picker-help",
            )

    def on_mount(self) -> None:
        """Focus the tree list for keyboard navigation."""
        tree_list = self.query_one("#tree-picker-list", ListView)
        tree_list.index = _nearest_visible_tree_choice_index(
            self._visible_choices(),
            self.choices,
            _active_tree_choice_id(self.choices),
        )
        self._refresh_tree_item_labels()
        self.call_after_refresh(self._refresh_tree_item_labels)
        tree_list.focus()

    def on_key(self, event: Key) -> None:
        """Route tree picker keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif event.key == "s":
            event.stop()
            self.action_select_with_summary()
        elif event.key == "c":
            event.stop()
            self.action_select_with_custom_summary()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_no_tools,
            "ctrl+t",
        ):
            event.stop()
            self.action_toggle_tool_calls()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_default,
            "ctrl+d",
        ):
            event.stop()
            self.action_set_default_tree_filter()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_user_only,
            "ctrl+u",
        ):
            event.stop()
            self.action_toggle_user_tree_filter()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_labeled_only,
            "ctrl+l",
        ):
            event.stop()
            self.action_toggle_labeled_tree_filter()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_all,
            "ctrl+a",
        ):
            event.stop()
            self.action_toggle_all_tree_filter()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_cycle,
            "ctrl+o",
        ):
            event.stop()
            self.action_cycle_tree_filter()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_filter_cycle_previous,
            "shift+ctrl+o,ctrl+shift+o",
        ):
            event.stop()
            self.action_cycle_tree_filter_backward()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.editor_cursor_left,
            "left",
        ):
            event.stop()
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.editor_cursor_right,
            "right",
        ):
            event.stop()
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.copy_last_message,
            "ctrl+x",
        ):
            event.stop()
            self.action_copy_selected_tree_entry()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_fold_or_up,
            "ctrl+left,alt+left",
        ):
            event.stop()
            self.action_fold_tree_branch()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_unfold_or_down,
            "ctrl+right,alt+right",
        ):
            event.stop()
            self.action_unfold_tree_branch()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_edit_label,
            "shift+l,L",
        ):
            event.stop()
            self.action_edit_tree_label()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.tree_toggle_label_timestamp,
            "shift+t,T",
        ):
            event.stop()
            self.action_toggle_tree_label_timestamps()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.editor_delete_char_backward,
            "backspace",
        ):
            if self.search_value:
                event.stop()
                self.run_worker(self._set_tree_search(self.search_value[:-1]))
        elif search_character := _tree_search_character(event):
            event.stop()
            self.run_worker(self._set_tree_search(self.search_value + search_character))

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected entry id."""
        self.dismiss(TreePickerResult(entry_id=self._visible_choices()[event.index].entry_id))

    def action_cursor_up(self) -> None:
        """Move to the previous tree entry."""
        self._move_tree_cursor(-1)

    def action_cursor_down(self) -> None:
        """Move to the next tree entry."""
        self._move_tree_cursor(1)

    def _move_tree_cursor(self, direction: Literal[-1, 1]) -> None:
        """Move selected tree row, wrapping at list boundaries like Pi."""
        visible_choices = self._visible_choices()
        if not visible_choices:
            return
        tree_list = self.query_one("#tree-picker-list", ListView)
        current_index = tree_list.index if tree_list.index is not None else 0
        tree_list.index = (current_index + direction) % len(visible_choices)
        self._refresh_tree_item_labels()

    def action_page_up(self) -> None:
        """Move up by a page of tree entries."""
        self._move_tree_page(-1)

    def action_page_down(self) -> None:
        """Move down by a page of tree entries."""
        self._move_tree_page(1)

    def _move_tree_page(self, direction: Literal[-1, 1]) -> None:
        """Move the selected tree entry by a viewport-sized page."""
        visible_choices = self._visible_choices()
        if not visible_choices:
            return
        tree_list = self.query_one("#tree-picker-list", ListView)
        current_index = tree_list.index if tree_list.index is not None else 0
        page_size = max(1, tree_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        next_index = current_index + (direction * page_size)
        tree_list.index = max(0, min(len(visible_choices) - 1, next_index))
        self._refresh_tree_item_labels()

    def action_select_cursor(self) -> None:
        """Branch from the highlighted entry without a summary."""
        self.query_one("#tree-picker-list", ListView).action_select_cursor()

    def action_select_with_summary(self) -> None:
        """Branch from the highlighted entry with a branch summary."""
        tree_list = self.query_one("#tree-picker-list", ListView)
        index = tree_list.index
        if index is None:
            return
        self.dismiss(
            TreePickerResult(entry_id=self._visible_choices()[index].entry_id, summarize=True)
        )

    def action_select_with_custom_summary(self) -> None:
        """Branch from the highlighted entry with custom summary instructions."""
        tree_list = self.query_one("#tree-picker-list", ListView)
        index = tree_list.index
        if index is None:
            return
        self.app.push_screen(
            BranchSummaryInstructionsScreen(theme=self.theme, keybindings=self.keybindings),
            callback=lambda instructions: self._dismiss_with_custom_summary(index, instructions),
        )

    def _dismiss_with_custom_summary(self, index: int, instructions: str | None) -> None:
        if instructions is None:
            return
        visible_choices = self._visible_choices()
        if index >= len(visible_choices):
            return
        self.dismiss(
            TreePickerResult(
                entry_id=visible_choices[index].entry_id,
                summarize=True,
                custom_instructions=instructions,
            )
        )

    def action_copy_selected_tree_entry(self) -> None:
        """Copy the selected tree entry's full text when available."""
        choice = self._selected_choice()
        app = cast(Any, self.app)
        if choice is None or not choice.copy_text:
            app._notify("Selected tree entry has no text to copy.", severity="warning")
            return
        app.copy_to_clipboard(choice.copy_text)
        app._notify("Copied selected tree entry to clipboard.")

    def action_fold_tree_branch(self) -> None:
        """Fold the selected tree branch when it has visible children."""
        self.run_worker(self._fold_tree_branch())

    async def _fold_tree_branch(self) -> None:
        choice = self._selected_choice()
        filtered_choices = self._filtered_choices()
        if choice is None:
            return
        if not _tree_choice_is_branch_foldable(
            choice,
            filtered_choices,
            source_choices=self.choices,
        ):
            self._move_tree_branch_segment("up")
            return
        if choice.entry_id in self.folded_entry_ids:
            self._move_tree_branch_segment("up")
            return
        self.folded_entry_ids.add(choice.entry_id)
        await self._refresh_tree_choices(selected_entry_id=choice.entry_id)

    def action_unfold_tree_branch(self) -> None:
        """Unfold the selected tree branch."""
        self.run_worker(self._unfold_tree_branch())

    async def _unfold_tree_branch(self) -> None:
        choice = self._selected_choice()
        if choice is None:
            return
        if choice.entry_id in self.folded_entry_ids:
            self.folded_entry_ids.remove(choice.entry_id)
            await self._refresh_tree_choices(selected_entry_id=choice.entry_id)
            return
        self._move_tree_branch_segment("down")

    def _move_tree_branch_segment(self, direction: Literal["up", "down"]) -> None:
        visible_choices = self._visible_choices()
        if not visible_choices:
            return
        tree_list = self.query_one("#tree-picker-list", ListView)
        selected_index = tree_list.index
        if selected_index is None or selected_index >= len(visible_choices):
            return
        tree_list.index = _tree_branch_segment_index(
            visible_choices,
            selected_index,
            direction=direction,
            source_choices=self.choices,
        )
        self._refresh_tree_item_labels()

    def action_edit_tree_label(self) -> None:
        """Edit the selected tree entry label."""
        choice = self._selected_choice()
        app = cast(Any, self.app)
        if choice is None:
            return
        if self.set_entry_label is None:
            app._notify("Tree labels are not available.", severity="warning")
            return
        app.push_screen(
            TreeLabelInputScreen(
                entry_id=choice.entry_id,
                current_label=choice.tree_label,
                theme=self.theme,
                keybindings=self.keybindings,
            ),
            callback=self._handle_tree_label_input,
        )

    def _handle_tree_label_input(self, result: tuple[str, str | None] | None) -> None:
        if result is None:
            return
        entry_id, label = result
        self.run_worker(self._apply_tree_label(entry_id, label))

    async def _apply_tree_label(self, entry_id: str, label: str | None) -> None:
        if self.set_entry_label is None:
            return
        app = cast(Any, self.app)
        try:
            result = self.set_entry_label(entry_id, label)
            if isawaitable(result):
                result = await result
            if result is not None:
                self.choices = tuple(cast(Sequence[SessionTreeChoice], result))
            await self._refresh_tree_choices(selected_entry_id=entry_id)
        except Exception as exc:  # noqa: BLE001 - surface label failures in the TUI
            app._notify(f"Error: {exc}", severity="error")

    def action_toggle_tree_label_timestamps(self) -> None:
        """Toggle Pi-style label timestamp display."""
        self.show_label_timestamps = not self.show_label_timestamps
        self.run_worker(self._refresh_tree_choices(selected_entry_id=self._selected_entry_id()))

    def action_toggle_tool_calls(self) -> None:
        """Toggle Pi's no-tools tree filter."""
        self.run_worker(self._set_tree_filter("no-tools", toggle=True))

    def action_set_default_tree_filter(self) -> None:
        """Set the tree picker to its default filter mode."""
        self.run_worker(self._set_tree_filter("default"))

    def action_toggle_user_tree_filter(self) -> None:
        """Toggle Pi's user-only tree filter."""
        self.run_worker(self._set_tree_filter("user-only", toggle=True))

    def action_toggle_labeled_tree_filter(self) -> None:
        """Toggle Pi's labeled-only tree filter."""
        self.run_worker(self._set_tree_filter("labeled-only", toggle=True))

    def action_toggle_all_tree_filter(self) -> None:
        """Toggle Pi's all-entries tree filter."""
        self.run_worker(self._set_tree_filter("all", toggle=True))

    def action_cycle_tree_filter(self) -> None:
        """Cycle Pi-style tree filter modes supported by Tau's tree choice model."""
        self.run_worker(self._cycle_tree_filter())

    def action_cycle_tree_filter_backward(self) -> None:
        """Cycle Pi-style tree filter modes backward."""
        self.run_worker(self._cycle_tree_filter(direction=-1))

    async def _cycle_tree_filter(self, *, direction: Literal[-1, 1] = 1) -> None:
        selected_entry_id = self._selected_entry_id()
        current_index = TREE_FILTER_MODES.index(self.filter_mode)
        self.filter_mode = TREE_FILTER_MODES[(current_index + direction) % len(TREE_FILTER_MODES)]
        if self.filter_mode == "no-tools":
            self.show_tool_calls = False
        elif self.filter_mode == "all":
            self.show_tool_calls = True
        await self._refresh_tree_choices(selected_entry_id=selected_entry_id)

    async def _set_tree_filter(
        self,
        filter_mode: TreeFilterMode,
        *,
        toggle: bool = False,
    ) -> None:
        selected_entry_id = self._selected_entry_id()
        self.filter_mode = "default" if toggle and self.filter_mode == filter_mode else filter_mode
        self.show_tool_calls = self.filter_mode != "no-tools"
        self.folded_entry_ids.clear()
        await self._refresh_tree_choices(selected_entry_id=selected_entry_id)

    async def _refresh_tree_choices(self, *, selected_entry_id: str | None = None) -> None:
        tree_list = self.query_one("#tree-picker-list", ListView)
        await tree_list.clear()
        await tree_list.extend(self._list_items())
        visible_choices = self._visible_choices()
        tree_list.index = _nearest_visible_tree_choice_index(
            visible_choices,
            self.choices,
            selected_entry_id,
        )
        self._refresh_tree_item_labels()
        self.query_one("#tree-picker-search", Static).update(self._search_text())
        self.query_one("#tree-picker-help", Static).update(self._help_text())

    async def _set_tree_search(self, value: str) -> None:
        selected_entry_id = self._selected_entry_id()
        self.search_value = value
        self.folded_entry_ids.clear()
        await self._refresh_tree_choices(selected_entry_id=selected_entry_id)

    def _selected_entry_id(self) -> str | None:
        choice = self._selected_choice()
        return choice.entry_id if choice is not None else None

    def _selected_choice(self) -> SessionTreeChoice | None:
        tree_list = self.query_one("#tree-picker-list", ListView)
        index = tree_list.index
        visible_choices = self._visible_choices()
        if index is None or index >= len(visible_choices):
            return None
        return visible_choices[index]

    def _visible_choices(self) -> tuple[SessionTreeChoice, ...]:
        filtered = self._filtered_choices()
        if not self.folded_entry_ids:
            return filtered
        choices_by_id = {choice.entry_id: choice for choice in filtered}
        return tuple(
            choice
            for choice in filtered
            if not _tree_choice_has_folded_ancestor(
                choice,
                choices_by_id=choices_by_id,
                folded_entry_ids=self.folded_entry_ids,
            )
        )

    def _filtered_choices(self) -> tuple[SessionTreeChoice, ...]:
        return tuple(
            choice
            for choice in self.choices
            if _tree_choice_matches_filter(
                choice,
                filter_mode=self.filter_mode,
                show_tool_calls=self.show_tool_calls,
            )
            and _tree_choice_matches_search(choice, self.search_value)
        )

    def _list_items(self) -> list[ListItem]:
        tree_width = self._tree_viewport_width()
        selected_index = (
            self.query_one("#tree-picker-list", ListView).index if self.is_mounted else None
        )
        return [
            ListItem(
                Label(
                    _tree_picker_viewport_label(
                        choice,
                        theme=self.theme,
                        show_label_timestamps=self.show_label_timestamps,
                        selected=index == selected_index,
                        viewport_width=tree_width,
                    ),
                    markup=False,
                )
            )
            for index, choice in enumerate(self._visible_choices())
        ]

    def _refresh_tree_item_labels(self) -> None:
        """Refresh visible tree row labels after selection changes for horizontal panning."""
        if not self.is_mounted:
            return
        tree_list = self.query_one("#tree-picker-list", ListView)
        selected_index = tree_list.index
        tree_width = self._tree_viewport_width()
        for index, choice in enumerate(self._visible_choices()):
            if index >= len(tree_list.children):
                break
            label = tree_list.children[index].query_one(Label)
            label.update(
                _tree_picker_viewport_label(
                    choice,
                    theme=self.theme,
                    show_label_timestamps=self.show_label_timestamps,
                    selected=index == selected_index,
                    viewport_width=tree_width,
                )
            )

    def _tree_viewport_width(self) -> int:
        if not self.is_mounted:
            return 0
        tree_list = self.query_one("#tree-picker-list", ListView)
        return max(0, tree_list.size.width - 4)

    def _help_text(self) -> str:
        tool_call_state = "shown" if self.show_tool_calls else "hidden"
        filter_label = "default" if self.filter_mode == "default" else self.filter_mode
        label_time_state = "on" if self.show_label_timestamps else "off"
        branch_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        copy_key = _key_hint_with_default(self.keybindings.copy_last_message, "ctrl+x")
        page_left_key = _key_hint_with_default(self.keybindings.editor_cursor_left, "left")
        page_right_key = _key_hint_with_default(self.keybindings.editor_cursor_right, "right")
        label_key = _key_hint_with_default(self.keybindings.tree_edit_label, "shift+l")
        label_time_key = _key_hint_with_default(
            self.keybindings.tree_toggle_label_timestamp,
            "shift+t",
        )
        fold_key = _key_hint_with_default(self.keybindings.tree_fold_or_up, "ctrl+left")
        unfold_key = _key_hint_with_default(
            self.keybindings.tree_unfold_or_down,
            "ctrl+right",
        )
        no_tools_key = _key_hint_with_default(self.keybindings.tree_filter_no_tools, "ctrl+t")
        filter_next_key = _key_hint_with_default(
            self.keybindings.tree_filter_cycle,
            "ctrl+o",
        )
        filter_previous_key = _key_hint_with_default(
            self.keybindings.tree_filter_cycle_previous,
            "shift+ctrl+o",
        )
        return (
            f"Type to filter | {branch_key} branch | S summarize | C custom | "
            f"{copy_key} copy | {label_key} label | "
            f"{label_time_key} label time ({label_time_state}) | "
            f"{page_left_key}/{page_right_key} page | {fold_key}/{unfold_key} branch | "
            f"{no_tools_key} no-tools ({tool_call_state}) | "
            f"{filter_next_key}/{filter_previous_key} filter {filter_label} | "
            f"{cancel_key} clear/close"
        )

    def _search_text(self) -> str:
        if self.search_value:
            return f"Search: {self.search_value}"
        return "Search: type to filter"

    def action_cancel(self) -> None:
        """Close the picker without selecting an entry."""
        if self.search_value:
            self.run_worker(self._set_tree_search(""))
            return
        self.dismiss(None)


class BranchSummaryInstructionsScreen(ModalScreen[str | None]):
    """Prompt for custom branch-summary instructions."""

    def __init__(
        self,
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the custom-instructions prompt."""
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="branch-summary-instructions"):
            yield Static(
                "Custom summarization instructions",
                id="branch-summary-instructions-title",
            )
            yield TextArea(id="branch-summary-instructions-input")
            yield Static(
                f"Ctrl+Enter submits - {cancel_key} returns to tree",
                id="branch-summary-instructions-help",
            )

    def on_mount(self) -> None:
        """Focus the instruction editor."""
        self.query_one("#branch-summary-instructions-input", TextArea).focus()

    def on_key(self, event: Key) -> None:
        """Submit on Ctrl+Enter and cancel on Escape."""
        if event.key == "ctrl+enter":
            event.stop()
            self.action_submit()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def action_submit(self) -> None:
        """Submit custom instructions."""
        value = self.query_one("#branch-summary-instructions-input", TextArea).text.strip()
        self.dismiss(value or None)

    def action_cancel(self) -> None:
        """Cancel custom instructions."""
        self.dismiss(None)


class TreeLabelInputScreen(ModalScreen[tuple[str, str | None] | None]):
    """Prompt for a tree entry label."""

    def __init__(
        self,
        *,
        entry_id: str,
        current_label: str | None,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.entry_id = entry_id
        self.current_label = current_label or ""
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the tree-label editor."""
        save_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="tree-label-input"):
            yield Static("Tree entry label", id="tree-label-title")
            yield Input(value=self.current_label, id="tree-label-value")
            yield Static(
                f"{save_key} saves - empty clears - {cancel_key} returns to tree",
                id="tree-label-help",
            )

    def on_mount(self) -> None:
        """Focus the label input."""
        label_input = self.query_one("#tree-label-value", Input)
        label_input.cursor_position = len(self.current_label)
        label_input.focus()

    def on_key(self, event: Key) -> None:
        """Submit or cancel the label edit."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_submit()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def action_submit(self) -> None:
        """Submit the label edit."""
        value = self.query_one("#tree-label-value", Input).value.strip()
        self.dismiss((self.entry_id, value or None))

    def action_cancel(self) -> None:
        """Cancel the label edit."""
        self.dismiss(None)


class CommandOutputScroll(VerticalScroll):
    """Scrollable command output area with deterministic arrow-key scrolling."""

    def action_scroll_up(self) -> None:
        """Scroll command output up."""
        self.scroll_y = max(0, self.scroll_y - 1)

    def action_scroll_down(self) -> None:
        """Scroll command output down."""
        self.scroll_y = min(self.max_scroll_y, self.scroll_y + 1)


class CommandOutputScreen(ModalScreen[None]):
    """Dismissible modal for slash-command output."""

    def __init__(
        self,
        title: str,
        message: str,
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
        render_markdown: bool = False,
    ) -> None:
        super().__init__()
        self.title_text = title
        self.message = message
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()
        self.render_markdown = render_markdown

    def compose(self) -> ComposeResult:
        """Compose command output."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="command-output"):
            yield Static(self.title_text, id="command-output-title")
            with CommandOutputScroll(id="command-output-scroll"):
                if self.render_markdown:
                    yield ThemedMarkdownWidget(
                        self.message,
                        theme=self.theme,
                        classes="command-output-markdown",
                    )
                else:
                    yield Static(self.message, id="command-output-body", markup=False)
            yield Static(f"{confirm_key} or {cancel_key} closes", id="command-output-help")

    def on_mount(self) -> None:
        """Focus the scroll area so arrow keys navigate long output."""
        self.query_one("#command-output-scroll", VerticalScroll).focus()

    def on_key(self, event: Key) -> None:
        """Route configured keys to the command output scroll area."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_scroll_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_scroll_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_scroll_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_scroll_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ) or _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_close()

    def action_close(self) -> None:
        """Close the command output modal."""
        self.dismiss(None)

    def action_scroll_up(self) -> None:
        """Scroll command output up."""
        self.query_one("#command-output-scroll", CommandOutputScroll).action_scroll_up()

    def action_scroll_down(self) -> None:
        """Scroll command output down."""
        self.query_one("#command-output-scroll", CommandOutputScroll).action_scroll_down()

    def action_scroll_page_up(self) -> None:
        """Scroll command output up by one viewport."""
        scroll = self.query_one("#command-output-scroll", CommandOutputScroll)
        scroll.scroll_y = max(0, scroll.scroll_y - max(1, scroll.size.height - 1))

    def action_scroll_page_down(self) -> None:
        """Scroll command output down by one viewport."""
        scroll = self.query_one("#command-output-scroll", CommandOutputScroll)
        scroll.scroll_y = min(scroll.max_scroll_y, scroll.scroll_y + max(1, scroll.size.height - 1))


type ConfigMapAction = Literal["insert_command", "copy_path", "toggle_resource"]
type ConfigMapScope = Literal["all", "project", "user"]
type ArtifactBrowserAction = Literal["open", "copy"]
type ArtifactPreviewKind = Literal["image", "markdown", "json", "html"]
type ArtifactBrowserKind = Literal["all", "image", "markdown", "json", "html"]
ARTIFACT_BROWSER_KINDS: tuple[ArtifactBrowserKind, ...] = (
    "all",
    "image",
    "markdown",
    "json",
    "html",
)
MARKDOWN_ARTIFACT_LINK_PATTERN = re.compile(
    r"(?<!!)\[[^\]\n]+\]\((?P<target><[^>\n]+>|[^)\s]+)(?:\s+\"[^\"]*\")?\)"
)
MARKDOWN_ARTIFACT_MIME_TYPES = {
    ".md": "text/markdown",
    ".markdown": "text/markdown",
}
JSON_ARTIFACT_MIME_TYPES = {
    ".json": "application/json",
}
HTML_ARTIFACT_MIME_TYPES = {
    ".html": "text/html",
    ".htm": "text/html",
}
HTML_ARTIFACT_IMAGE_MIME_TYPES = {
    ".gif": "image/gif",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
}
MAX_MARKDOWN_ARTIFACT_BYTES = 512 * 1024
MAX_JSON_ARTIFACT_BYTES = 512 * 1024
MAX_HTML_ARTIFACT_BYTES = 512 * 1024
MAX_HTML_ARTIFACT_IMAGE_BYTES = 10 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class VisualArtifact:
    """One inspectable artifact discovered from the visible transcript."""

    title: str
    path: Path
    mime_type: str
    bytes: int
    source: str
    preview_kind: ArtifactPreviewKind = "image"


@dataclass(frozen=True, slots=True)
class ArtifactBrowserResult:
    """Action selected from the visual artifact browser."""

    action: ArtifactBrowserAction
    artifact: VisualArtifact


class ArtifactBrowserSearchInput(Input):
    """Search input that keeps artifact-browser control keys local to the screen."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("tab", "cycle_kind", "Kind", priority=True),
        Binding("ctrl+i", "cycle_kind", "Kind", priority=True),
    ]

    def _screen(self) -> ArtifactBrowserScreen:
        return cast(ArtifactBrowserScreen, self.screen)

    def action_cycle_kind(self) -> None:
        """Cycle artifact kinds while search has focus."""
        self._screen().action_cycle_kind()

    def action_focus_next(self) -> None:
        """Treat Tab as Pi-style kind switching instead of focus traversal."""
        self._screen().action_cycle_kind()

    def on_key(self, event: Key) -> None:
        """Route configured keys before the input edits its text."""
        screen = self._screen()
        keybindings = screen.keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            screen.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            screen.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            event.prevent_default()
            screen.action_page(-1)
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            event.prevent_default()
            screen.action_page(1)
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            event.prevent_default()
            screen.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            event.prevent_default()
            screen.action_cancel()
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            event.prevent_default()
            screen.action_cycle_kind()


class ArtifactBrowserScreen(ModalScreen[ArtifactBrowserResult | None]):
    """Open, copy, or preview artifacts found in the current transcript."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("c", "copy_selected", "Copy"),
        Binding("tab", "cycle_kind", "Kind", priority=True),
        Binding("ctrl+i", "cycle_kind", "Kind", priority=True),
    ]

    def __init__(
        self,
        artifacts: Sequence[VisualArtifact],
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
        show_images: bool = True,
        image_width_cells: int | None = None,
    ) -> None:
        super().__init__()
        self.artifacts = tuple(artifacts)
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()
        self.show_images = show_images
        self.image_width_cells = image_width_cells
        self.search_value = ""
        self.kind: ArtifactBrowserKind = "all"
        self.filtered_artifacts = self.artifacts

    def compose(self) -> ComposeResult:
        """Compose the artifact browser."""
        with Vertical(id="config-map"):
            yield Static("Artifacts", id="config-map-title")
            yield Static(_artifact_browser_summary(self.artifacts), id="artifact-browser-summary")
            yield Static("", id="config-map-tabs")
            yield ArtifactBrowserSearchInput(
                placeholder="Search artifacts",
                id="artifact-browser-search",
            )
            yield ListView(*self._list_items(), id="config-map-list")
            with VerticalScroll(id="artifact-browser-preview-scroll"):
                yield Static(
                    self._preview_renderable(0),
                    id="artifact-browser-preview",
                    markup=False,
                )
            yield Static(self._help_text(), id="config-map-help")

    def on_mount(self) -> None:
        """Focus the artifact search input."""
        self._refresh_list(0)
        self.query_one("#artifact-browser-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter artifacts as the search value changes."""
        if event.input.id != "artifact-browser-search":
            return
        self.search_value = event.value
        self._refresh_list(0)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Open the selected artifact from the search input."""
        if event.input.id != "artifact-browser-search":
            return
        event.stop()
        self.action_select_cursor()

    def on_key(self, event: Key) -> None:
        """Route configured artifact-browser keys."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_page(-1)
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_page(1)
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()
        elif event.key == "c":
            event.stop()
            self._select("copy")
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            self.action_cycle_kind()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Open the selected artifact."""
        if event.index < len(self.filtered_artifacts):
            self.dismiss(ArtifactBrowserResult("open", self.filtered_artifacts[event.index]))

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Update the selected artifact preview."""
        if event.list_view.id == "config-map-list":
            self._refresh_preview()

    def action_copy_selected(self) -> None:
        """Copy the selected artifact path."""
        self._select("copy")

    def action_cursor_up(self) -> None:
        """Move to the previous artifact row."""
        self.query_one("#config-map-list", ListView).action_cursor_up()
        self._refresh_preview()

    def action_cursor_down(self) -> None:
        """Move to the next artifact row."""
        self.query_one("#config-map-list", ListView).action_cursor_down()
        self._refresh_preview()

    def action_cycle_kind(self) -> None:
        """Cycle Pi-style artifact type tabs."""
        self.kind = ARTIFACT_BROWSER_KINDS[
            (ARTIFACT_BROWSER_KINDS.index(self.kind) + 1) % len(ARTIFACT_BROWSER_KINDS)
        ]
        self._refresh_list(0)

    def action_focus_next(self) -> None:
        """Treat Tab as Pi-style kind switching inside the artifact modal."""
        self.action_cycle_kind()

    def action_focus_previous(self) -> None:
        """Treat Shift+Tab as reverse Pi-style kind switching."""
        index = (ARTIFACT_BROWSER_KINDS.index(self.kind) - 1) % len(ARTIFACT_BROWSER_KINDS)
        self.kind = ARTIFACT_BROWSER_KINDS[index]
        self._refresh_list(0)

    def action_select_cursor(self) -> None:
        """Open the highlighted artifact."""
        self._select("open")

    def action_cancel(self) -> None:
        """Close the artifact browser."""
        self.dismiss(None)

    def action_page(self, direction: Literal[-1, 1]) -> None:
        """Move by one visible artifact page."""
        if not self.filtered_artifacts:
            return
        artifact_list = self.query_one("#config-map-list", ListView)
        current_index = artifact_list.index if artifact_list.index is not None else 0
        page_size = max(1, artifact_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        artifact_list.index = max(
            0,
            min(len(self.filtered_artifacts) - 1, current_index + (direction * page_size)),
        )
        self._refresh_preview()

    def _select(self, action: ArtifactBrowserAction) -> None:
        artifact_list = self.query_one("#config-map-list", ListView)
        index = artifact_list.index
        if index is None or index >= len(self.filtered_artifacts):
            return
        self.dismiss(ArtifactBrowserResult(action, self.filtered_artifacts[index]))

    def _refresh_list(self, index: int) -> None:
        self.filtered_artifacts = _filter_artifacts(
            self.artifacts,
            self.search_value,
            kind=self.kind,
        )
        artifact_list = self.query_one("#config-map-list", ListView)
        artifact_list.clear()
        artifact_list.extend(self._list_items())
        artifact_list.index = (
            min(index, len(artifact_list.children) - 1) if self.filtered_artifacts else None
        )
        self._refresh_preview()

    def _list_items(self) -> list[ListItem]:
        if not self.filtered_artifacts:
            return [
                ListItem(
                    Label(
                        _artifact_browser_empty_label(self),
                        markup=False,
                    )
                )
            ]
        return [
            ListItem(Label(_artifact_browser_label(index, artifact), markup=False))
            for index, artifact in enumerate(self.filtered_artifacts, 1)
        ]

    def _refresh_preview(self) -> None:
        try:
            preview = self.query_one("#artifact-browser-preview", Static)
            artifact_list = self.query_one("#config-map-list", ListView)
        except NoMatches:
            return
        index = artifact_list.index if artifact_list.index is not None else 0
        preview.update(self._preview_renderable(index))
        self._refresh_help_text()

    def _preview_renderable(self, index: int) -> RenderableType:
        if not self.filtered_artifacts:
            return "No preview available"
        artifact = self.filtered_artifacts[
            max(0, min(len(self.filtered_artifacts) - 1, index))
        ]
        try:
            data = artifact.path.read_bytes()
        except OSError:
            return f"Preview unavailable: {artifact.path}"
        if not data:
            return f"Preview unavailable: empty file {artifact.path}"
        if artifact.preview_kind == "markdown":
            return self._markdown_preview_renderable(artifact, data)
        if artifact.preview_kind == "json":
            return self._json_preview_renderable(artifact, data)
        if artifact.preview_kind == "html":
            return self._html_preview_renderable(artifact, data)
        return TerminalImage(
            base64.b64encode(data).decode("ascii"),
            artifact.mime_type,
            TerminalImageOptions(
                filename=artifact.path.name,
                max_width_cells=self.image_width_cells,
                max_height_cells=8,
                show=self.show_images,
            ),
        )

    def _markdown_preview_renderable(self, artifact: VisualArtifact, data: bytes) -> RenderableType:
        if len(data) > MAX_MARKDOWN_ARTIFACT_BYTES:
            return (
                f"Preview unavailable: {artifact.path} is larger than "
                f"{_format_artifact_size(MAX_MARKDOWN_ARTIFACT_BYTES)}"
            )
        try:
            markdown = data.decode("utf-8")
        except UnicodeDecodeError:
            return f"Preview unavailable: {artifact.path} is not UTF-8 text"
        visual_payloads = markdown_visual_payloads(markdown, base_path=artifact.path.parent)
        if not visual_payloads:
            return Markdown(markdown)
        image_renderables = [
            Padding(
                TerminalImage(
                    payload.image_base64,
                    payload.mime_type,
                    TerminalImageOptions(
                        filename=Path(payload.path).name,
                        max_width_cells=self.image_width_cells,
                        max_height_cells=8,
                        show=self.show_images,
                    ),
                ),
                (1, 0, 0, 0),
            )
            for payload in visual_payloads
        ]
        return Group(Markdown(markdown), *image_renderables)

    def _json_preview_renderable(self, artifact: VisualArtifact, data: bytes) -> RenderableType:
        if len(data) > MAX_JSON_ARTIFACT_BYTES:
            return (
                f"Preview unavailable: {artifact.path} is larger than "
                f"{_format_artifact_size(MAX_JSON_ARTIFACT_BYTES)}"
            )
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return f"Preview unavailable: {artifact.path} is not UTF-8 text"
        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            return f"Preview unavailable: {artifact.path} is not valid JSON ({exc.msg})"
        pretty = json.dumps(payload, indent=2, sort_keys=True)
        summary = _json_artifact_summary_table(artifact, payload)
        syntax = Syntax(pretty, "json", word_wrap=True)
        return Group(summary, Text(""), syntax)

    def _html_preview_renderable(self, artifact: VisualArtifact, data: bytes) -> RenderableType:
        if len(data) > MAX_HTML_ARTIFACT_BYTES:
            return (
                f"Preview unavailable: {artifact.path} is larger than "
                f"{_format_artifact_size(MAX_HTML_ARTIFACT_BYTES)}"
            )
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return f"Preview unavailable: {artifact.path} is not UTF-8 text"
        preview = _html_artifact_preview_markdown(text, fallback_title=artifact.path.name)
        image_renderables = [
            Padding(
                TerminalImage(
                    payload.image_base64,
                    payload.mime_type,
                    TerminalImageOptions(
                        filename=Path(payload.path).name,
                        max_width_cells=self.image_width_cells,
                        max_height_cells=8,
                        show=self.show_images,
                    ),
                ),
                (1, 0, 0, 0),
            )
            for payload in _html_image_payloads(
                preview.image_targets,
                base_path=artifact.path.parent,
            )
        ]
        return Group(
            _html_artifact_summary_table(artifact, preview.title),
            Text(""),
            Markdown(preview.markdown),
            *image_renderables,
        )

    def _help_text(self) -> str:
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        if not self.filtered_artifacts:
            return f"No matching artifacts - Tab/Ctrl+I switches kind - {cancel_key} closes"
        return (
            f"Type to search - Up/Down navigates - {confirm_key} opens - "
            f"c copies path - Tab/Ctrl+I switches kind - "
            f"{cancel_key} closes"
        )

    def _refresh_help_text(self) -> None:
        self.query_one("#config-map-tabs", Static).update(
            _artifact_browser_kind_tabs(self.artifacts, self.kind)
        )
        self.query_one("#config-map-help", Static).update(self._help_text())


@dataclass(frozen=True, slots=True)
class ConfigMapItem:
    """One actionable row in the TUI config map."""

    section: str
    label: str
    value: str
    description: str
    action: ConfigMapAction | None = None
    action_value: str | None = None
    scope: ConfigMapScope = "all"


@dataclass(frozen=True, slots=True)
class ConfigMapResult:
    """Action selected from the config map."""

    action: ConfigMapAction
    value: str


class ConfigMapSearchInput(Input):
    """Search input that keeps config-map control keys local to the screen."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("tab", "cycle_scope", "Scope", priority=True),
        Binding("ctrl+i", "cycle_scope", "Scope", priority=True),
    ]

    def _screen(self) -> ConfigMapScreen:
        return cast(ConfigMapScreen, self.screen)

    def action_cycle_scope(self) -> None:
        """Cycle the config map scope while search has focus."""
        self._screen().action_cycle_scope()

    def action_focus_next(self) -> None:
        """Treat Tab as Pi-style config scope switching instead of focus traversal."""
        self._screen().action_cycle_scope()

    def on_key(self, event: Key) -> None:
        """Route configured keys before the input edits its text."""
        screen = self._screen()
        keybindings = screen.keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            screen.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            screen.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            event.prevent_default()
            screen.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            event.prevent_default()
            screen.action_page_down()
        elif (
            _matches_configured_or_default_key(
                event.key,
                keybindings.select_confirm,
                "enter",
            )
            or event.key == "space"
        ):
            event.stop()
            event.prevent_default()
            screen.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            event.prevent_default()
            screen.action_cancel()
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            event.prevent_default()
            screen.action_cycle_scope()


class ConfigMapScreen(ModalScreen[ConfigMapResult | None]):
    """Searchable TUI map of Tau config files, resources, and related commands."""

    BINDINGS: ClassVar[list[Binding]] = [
        Binding("tab", "cycle_scope", "Scope", priority=True),
        Binding("ctrl+i", "cycle_scope", "Scope", priority=True),
    ]

    def __init__(
        self,
        items: Sequence[ConfigMapItem],
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
        on_toggle_resource: Callable[[str], Sequence[ConfigMapItem]] | None = None,
        write_target_label: str = "Write target: User TUI settings",
    ) -> None:
        super().__init__()
        self.items = tuple(items)
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()
        self.on_toggle_resource = on_toggle_resource
        self.write_target_label = write_target_label
        self.search_value = ""
        self.filtered_items = self.items
        self.scope: ConfigMapScope = "all"

    def compose(self) -> ComposeResult:
        """Compose the config map screen."""
        with Vertical(id="config-map"):
            yield Static("Config Map", id="config-map-title")
            yield Static("", id="config-map-tabs")
            yield Static(self.write_target_label, id="config-map-write-target", markup=False)
            yield ConfigMapSearchInput(
                placeholder="Search config, resources, commands",
                id="config-map-search",
            )
            yield ListView(*self._list_items(), id="config-map-list")
            yield Static(self._help_text(), id="config-map-help")

    def on_mount(self) -> None:
        """Focus the search input."""
        self._refresh_list(0)
        self.query_one("#config-map-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter config rows as the search value changes."""
        if event.input.id != "config-map-search":
            return
        self.search_value = event.value
        self._refresh_list(0)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Run the selected row action from the search input."""
        if event.input.id != "config-map-search":
            return
        event.stop()
        self.action_select_cursor()

    def on_key(self, event: Key) -> None:
        """Route configured selection keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            self.action_cycle_scope()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Run the selected row action."""
        if event.index < len(self.filtered_items):
            self._select_item(self.filtered_items[event.index])

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Refresh help for the highlighted config row."""
        if event.list_view.id == "config-map-list":
            self._refresh_help_text()

    def action_cursor_up(self) -> None:
        """Move to the previous config row."""
        self.query_one("#config-map-list", ListView).action_cursor_up()
        self._refresh_help_text()

    def action_cursor_down(self) -> None:
        """Move to the next config row."""
        self.query_one("#config-map-list", ListView).action_cursor_down()
        self._refresh_help_text()

    def action_page_up(self) -> None:
        """Move up by one page of config rows."""
        self._move_page(-1)

    def action_page_down(self) -> None:
        """Move down by one page of config rows."""
        self._move_page(1)

    def action_cycle_scope(self) -> None:
        """Cycle Pi-style config scope tabs."""
        order: tuple[ConfigMapScope, ...] = ("all", "project", "user")
        self.scope = order[(order.index(self.scope) + 1) % len(order)]
        self._refresh_list(0)

    def action_focus_next(self) -> None:
        """Treat Tab as Pi-style scope switching inside the config modal."""
        self.action_cycle_scope()

    def action_select_cursor(self) -> None:
        """Run the highlighted row action."""
        config_list = self.query_one("#config-map-list", ListView)
        index = config_list.index
        if index is None or index >= len(self.filtered_items):
            return
        self._select_item(self.filtered_items[index])

    def action_cancel(self) -> None:
        """Close the config map."""
        self.dismiss(None)

    def _select_item(self, item: ConfigMapItem) -> None:
        if item.action is None or item.action_value is None:
            return
        if item.action == "toggle_resource" and self.on_toggle_resource is not None:
            config_list = self.query_one("#config-map-list", ListView)
            selected_index = config_list.index if config_list.index is not None else 0
            self.items = tuple(self.on_toggle_resource(item.action_value))
            self._refresh_list(selected_index)
            return
        self.dismiss(ConfigMapResult(item.action, item.action_value))

    def _move_page(self, direction: Literal[-1, 1]) -> None:
        if not self.filtered_items:
            return
        config_list = self.query_one("#config-map-list", ListView)
        current_index = config_list.index if config_list.index is not None else 0
        page_size = max(1, config_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        next_index = current_index + (direction * page_size)
        config_list.index = max(0, min(len(self.filtered_items) - 1, next_index))
        self._refresh_help_text()

    def _refresh_list(self, index: int) -> None:
        self.filtered_items = _filter_config_map_items(
            self.items,
            self.search_value,
            scope=self.scope,
        )
        config_list = self.query_one("#config-map-list", ListView)
        config_list.clear()
        config_list.extend(self._list_items())
        config_list.index = (
            min(index, len(config_list.children) - 1) if self.filtered_items else None
        )
        self._refresh_help_text()

    def _list_items(self) -> list[ListItem]:
        if not self.filtered_items:
            return [ListItem(Label(_config_map_empty_label(self), markup=False))]
        return [
            ListItem(Label(_config_map_item_label(item), markup=False))
            for item in self.filtered_items
        ]

    def _help_text(self) -> str:
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        scope_hint = "Tab switches scope"
        if not self.filtered_items:
            return f"No matching config rows - {scope_hint} - {cancel_key} closes"
        try:
            config_list = self.query_one("#config-map-list", ListView)
        except NoMatches:
            return f"Type to search - {confirm_key}/Space acts - {scope_hint} - {cancel_key} closes"
        index = config_list.index
        if index is None or index >= len(self.filtered_items):
            return f"Type to search - {confirm_key}/Space acts - {scope_hint} - {cancel_key} closes"
        item = self.filtered_items[index]
        if item.action == "insert_command":
            return (
                f"{item.description} - {confirm_key}/Space inserts command - "
                f"{scope_hint} - {cancel_key} closes"
            )
        if item.action == "copy_path":
            return (
                f"{item.description} - {confirm_key}/Space copies path - "
                f"{scope_hint} - {cancel_key} closes"
            )
        if item.action == "toggle_resource":
            scope, state, next_action = _config_map_resource_state(item)
            write_scope = scope if scope in {"project", "user"} else "user"
            return (
                f"{item.description} - {scope} resource is {state} - "
                f"{confirm_key}/Space {next_action}s resource in "
                f"{write_scope} TUI settings - "
                f"{scope_hint} - {cancel_key} closes"
            )
        return f"{item.description} - {scope_hint} - {cancel_key} closes"

    def _refresh_help_text(self) -> None:
        self.query_one("#config-map-tabs", Static).update(_config_map_scope_tabs(self.scope))
        self.query_one("#config-map-help", Static).update(self._help_text())


class ConfirmationScreen(ModalScreen[bool]):
    """Small yes/no confirmation modal for commands with session impact."""

    def __init__(
        self,
        title: str,
        message: str,
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.title_text = title
        self.message = message
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose confirmation prompt."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="confirmation"):
            yield Static(self.title_text, id="confirmation-title")
            yield Static(self.message, id="confirmation-body", markup=False)
            yield Static(f"{confirm_key} confirms - {cancel_key} cancels", id="confirmation-help")

    def on_key(self, event: Key) -> None:
        """Route configured confirmation keys."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.dismiss(True)
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.dismiss(False)


class ExtensionSelectScreen(ModalScreen[str | None]):
    """Pi-style extension select dialog."""

    def __init__(
        self,
        title: str,
        options: Sequence[str],
        *,
        timeout_seconds: float | None = None,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.title_text = title
        self.options = tuple(options)
        self.timeout_seconds = timeout_seconds
        self.remaining_seconds = (
            max(1, int(timeout_seconds + 0.999)) if timeout_seconds is not None else None
        )
        self._countdown_timer: Timer | None = None
        self._expiration_timer: Timer | None = None
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the extension select dialog."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        tools_key = _key_hint_with_default(self.keybindings.toggle_tool_results, "ctrl+o")
        with Vertical(id="confirmation"):
            yield Static(self._title_label(), id="confirmation-title")
            yield ListView(
                *(ListItem(Label(option, markup=False)) for option in self.options),
                id="extension-select-list",
            )
            yield Static(
                f"Up/Down/J/K navigate - {confirm_key} selects - "
                f"{tools_key} toggles tool output - {cancel_key} cancels",
                id="confirmation-help",
            )

    def on_mount(self) -> None:
        """Focus the list."""
        with suppress(NoMatches):
            self.query_one("#extension-select-list", ListView).focus()
        if self.remaining_seconds is not None:
            self._expiration_timer = self.set_timer(self.timeout_seconds or 0, self._expire_timeout)
            self._countdown_timer = self.set_interval(1.0, self._tick_timeout)

    def on_unmount(self) -> None:
        """Stop the timeout timer when the dialog closes."""
        if self._countdown_timer is not None:
            self._countdown_timer.stop()
            self._countdown_timer = None
        if self._expiration_timer is not None:
            self._expiration_timer.stop()
            self._expiration_timer = None

    def on_key(self, event: Key) -> None:
        """Route configured select keys."""
        if (
            _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up")
            or event.key == "k"
        ):
            event.stop()
            self.action_cursor_up()
        elif (
            _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down")
            or event.key == "j"
        ):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.dismiss(None)
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.toggle_tool_results,
            "ctrl+o",
        ):
            event.stop()
            app = self.app
            if isinstance(app, TauTuiApp):
                app.action_toggle_tool_results()

    def action_select_cursor(self) -> None:
        """Dismiss with the highlighted option."""
        selected = self.query_one("#extension-select-list", ListView).index
        if selected is None or selected < 0 or selected >= len(self.options):
            self.dismiss(None)
            return
        self.dismiss(self.options[selected])

    def action_cursor_up(self) -> None:
        """Move to the previous extension option."""
        self._move(-1)

    def action_cursor_down(self) -> None:
        """Move to the next extension option."""
        self._move(1)

    def _move(self, direction: Literal[-1, 1]) -> None:
        if not self.options:
            return
        option_list = self.query_one("#extension-select-list", ListView)
        current_index = option_list.index if option_list.index is not None else 0
        option_list.index = max(0, min(len(self.options) - 1, current_index + direction))

    def _tick_timeout(self) -> None:
        if self.remaining_seconds is None:
            return
        self.remaining_seconds -= 1
        if self.remaining_seconds <= 0:
            self._expire_timeout()
            return
        self.query_one("#confirmation-title", Static).update(self._title_label())

    def _expire_timeout(self) -> None:
        self.dismiss(None)

    def _title_label(self) -> str:
        if self.remaining_seconds is None:
            return self.title_text
        return f"{self.title_text} ({self.remaining_seconds}s)"


class ExtensionInputScreen(ModalScreen[str | None]):
    """Pi-style extension one-line input dialog."""

    def __init__(
        self,
        title: str,
        *,
        placeholder: str = "",
        prefill: str = "",
        timeout_seconds: float | None = None,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.title_text = title
        self.placeholder = placeholder
        self.prefill = prefill
        self.timeout_seconds = timeout_seconds
        self.remaining_seconds = (
            max(1, int(timeout_seconds + 0.999)) if timeout_seconds is not None else None
        )
        self._countdown_timer: Timer | None = None
        self._expiration_timer: Timer | None = None
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the extension input dialog."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="confirmation"):
            yield Static(self._title_label(), id="confirmation-title")
            yield Input(
                value=self.prefill,
                placeholder=self.placeholder,
                id="extension-input-value",
            )
            yield Static(f"{confirm_key} submits - {cancel_key} cancels", id="confirmation-help")

    def on_mount(self) -> None:
        """Focus the input."""
        input_widget = self.query_one("#extension-input-value", Input)
        input_widget.cursor_position = len(self.prefill)
        input_widget.focus()
        if self.remaining_seconds is not None:
            self._expiration_timer = self.set_timer(self.timeout_seconds or 0, self._expire_timeout)
            self._countdown_timer = self.set_interval(1.0, self._tick_timeout)

    def on_unmount(self) -> None:
        """Stop the timeout timer when the dialog closes."""
        if self._countdown_timer is not None:
            self._countdown_timer.stop()
            self._countdown_timer = None
        if self._expiration_timer is not None:
            self._expiration_timer.stop()
            self._expiration_timer = None

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Submit typed text."""
        if event.input.id != "extension-input-value":
            return
        event.stop()
        self.dismiss(event.value)

    def on_key(self, event: Key) -> None:
        """Route configured input keys."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.dismiss(None)

    def _tick_timeout(self) -> None:
        if self.remaining_seconds is None:
            return
        self.remaining_seconds -= 1
        if self.remaining_seconds <= 0:
            self._expire_timeout()
            return
        self.query_one("#confirmation-title", Static).update(self._title_label())

    def _expire_timeout(self) -> None:
        self.dismiss(None)

    def _title_label(self) -> str:
        if self.remaining_seconds is None:
            return self.title_text
        return f"{self.title_text} ({self.remaining_seconds}s)"


class ExtensionEditorTextArea(TextArea):
    """TextArea that keeps Pi-style extension editor keys local to the editor."""

    def _screen(self) -> ExtensionEditorScreen:
        return cast(ExtensionEditorScreen, self.screen)

    def on_key(self, event: Key) -> None:
        """Route submit and newline keys before TextArea edits the buffer."""
        screen = self._screen()
        keybindings = screen.keybindings
        if _matches_configured_or_default_key(
            event.key,
            keybindings.insert_newline,
            "shift+enter",
        ):
            event.stop()
            event.prevent_default()
            self.insert("\n")
        elif event.key == "ctrl+enter" or _matches_configured_or_default_key(
            event.key,
            keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            event.prevent_default()
            screen.action_submit()


class ExtensionEditorScreen(ModalScreen[str | None]):
    """Pi-style extension multi-line editor dialog."""

    def __init__(
        self,
        title: str,
        *,
        prefill: str = "",
        external_editor_command: str | None = None,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.title_text = title
        self.prefill = prefill
        self.external_editor_command = external_editor_command
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the extension editor dialog."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        newline_key = _key_hint_with_default(self.keybindings.insert_newline, "shift+enter")
        external_key = _key_hint_with_default(self.keybindings.external_editor, "ctrl+g")
        with Vertical(id="confirmation"):
            yield Static(self.title_text, id="confirmation-title")
            yield ExtensionEditorTextArea(id="extension-editor-value")
            yield Static(
                f"{confirm_key} submits - {newline_key} newline - "
                f"{cancel_key} cancels - {external_key} external editor",
                id="confirmation-help",
            )

    def on_mount(self) -> None:
        """Focus the editor."""
        editor = self.query_one("#extension-editor-value", TextArea)
        editor.text = self.prefill
        editor.focus()

    def on_key(self, event: Key) -> None:
        """Submit or cancel the editor."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.insert_newline,
            "shift+enter",
        ):
            event.stop()
            event.prevent_default()
            self.query_one("#extension-editor-value", TextArea).insert("\n")
        elif event.key == "ctrl+enter" or _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            event.prevent_default()
            self.action_submit()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.external_editor,
            "ctrl+g",
        ):
            event.stop()
            self.run_worker(self._open_external_editor(), exclusive=False)
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.dismiss(None)

    def action_submit(self) -> None:
        """Submit edited text."""
        self.dismiss(self.query_one("#extension-editor-value", TextArea).text)

    async def _open_external_editor(self) -> None:
        editor = self.query_one("#extension-editor-value", TextArea)
        original_text = editor.text
        editor_command = _external_editor_command(self.external_editor_command)
        app = cast(Any, self.app)
        notify = getattr(app, "_notify", None)
        if editor_command is None:
            if callable(notify):
                notify(
                    "Set TUI external_editor, VISUAL, or EDITOR to use the external editor.",
                    severity="warning",
                )
            return
        try:
            with app.suspend():
                result = await _edit_text_with_external_editor(editor_command, original_text)
        except Exception as exc:  # noqa: BLE001 - surface editor launch failures in the TUI
            if callable(notify):
                notify(f"External editor failed: {exc}", severity="error")
            return
        if result is None:
            if callable(notify):
                notify("External editor exited without changes.", severity="warning")
            return
        editor.text = result
        editor.move_cursor(_text_end_location(result))
        editor.focus()


class ExtensionCustomScreen(ModalScreen[object]):
    """Pi-style extension custom modal backed by Textual widgets."""

    def __init__(
        self,
        extension_name: str,
        factory: Callable[..., object],
        *,
        options: Mapping[str, object] | None = None,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.extension_name = extension_name
        self.factory = factory
        self.options = options or {}
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()
        self._done_called = False

    def compose(self) -> ComposeResult:
        """Compose the extension custom screen."""
        title = str(self.options.get("title", f"{self.extension_name} custom UI"))
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="confirmation"):
            yield Static(title, id="confirmation-title")
            with Vertical(id="extension-custom-content"):
                yield Static("Loading...", id="confirmation-message")
            yield Static(f"{cancel_key} closes", id="confirmation-help")

    def on_mount(self) -> None:
        """Build and mount extension content after the screen is active."""
        self._notify_handle()
        content = self._build_content()
        if isawaitable(content):
            self.run_worker(self._mount_awaited_content(content), exclusive=False)
            return
        self._mount_content(content)

    def _notify_handle(self) -> None:
        callback = self.options.get("onHandle", self.options.get("on_handle"))
        if callable(callback):
            callback(_ExtensionCustomOverlayHandle(self))

    def _build_content(self) -> object:
        try:
            return self.factory(
                self.app,
                self.theme,
                self.keybindings,
                self._done,
            )
        except TypeError:
            return self.factory(self._done)

    async def _mount_awaited_content(self, content: object) -> None:
        try:
            resolved = await content
        except Exception as exc:  # noqa: BLE001 - extension UI failures should be visible
            self._mount_content(f"Extension custom UI error: {exc}")
            return
        self._mount_content(resolved)

    def _mount_content(self, content: object) -> None:
        container = self.query_one("#extension-custom-content", Vertical)
        container.remove_children()
        if isinstance(content, Widget):
            container.mount(content)
            return
        container.mount(
            Static(_extension_custom_content_text(content), id="confirmation-message")
        )

    def _done(self, result: object = None) -> None:
        self._done_called = True
        self.dismiss(result)

    def on_key(self, event: Key) -> None:
        """Route the configured cancel key."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.dismiss(None)


class _ExtensionCustomOverlayHandle:
    """Small runtime handle for extension custom modal control."""

    def __init__(self, screen: ExtensionCustomScreen) -> None:
        self._screen = screen

    def close(self, result: object = None) -> None:
        """Dismiss the custom UI with an optional result."""
        self._screen.dismiss(result)

    def dismiss(self, result: object = None) -> None:
        """Alias for close."""
        self.close(result)

    def hide(self) -> None:
        """Hide the custom UI without dismissing it."""
        self._screen.display = False

    def show(self) -> None:
        """Show a previously hidden custom UI."""
        self._screen.display = True


class LoginProviderPickerScreen(ModalScreen[str | None]):
    """Provider picker for the TUI login flow."""

    def __init__(
        self,
        providers: Sequence[ProviderCatalogEntry],
        *,
        theme: TuiTheme,
        title: str = "Login",
        initial_search: str = "",
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.providers = tuple(providers)
        self.visible_providers = _filter_login_providers(self.providers, initial_search)
        self.theme = theme
        self.title_text = title
        self.initial_search = initial_search
        self.search_value = initial_search
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the provider picker."""
        with Vertical(id="login-provider-picker"):
            yield Static(self.title_text, id="login-provider-title")
            yield Input(
                value=self.search_value,
                placeholder="Search providers",
                id="login-provider-search",
            )
            yield ListView(
                *[
                    ListItem(Label(_login_provider_label(provider), markup=False))
                    for provider in self.visible_providers
                ],
                id="login-provider-list",
            )
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            prefix = f'filter "{self.initial_search}" - ' if self.initial_search else ""
            yield Static(
                f"{prefix}{select_key} selects - {cancel_key} closes",
                id="login-provider-help",
            )

    def on_mount(self) -> None:
        """Focus the provider list."""
        self._refresh_provider_list()
        self.query_one("#login-provider-search", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter login providers as the search changes."""
        if event.input.id != "login-provider-search":
            return
        event.stop()
        self.search_value = event.value
        self._refresh_provider_list()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Select the highlighted provider from the search input."""
        if event.input.id != "login-provider-search":
            return
        event.stop()
        self.action_select_cursor()

    def _refresh_provider_list(self) -> None:
        self.visible_providers = _filter_login_providers(self.providers, self.search_value)
        provider_list = self.query_one("#login-provider-list", ListView)
        provider_list.clear()
        if self.visible_providers:
            provider_list.extend(
                ListItem(Label(_login_provider_label(provider), markup=False))
                for provider in self.visible_providers
            )
        else:
            provider_list.append(ListItem(Label(_login_provider_empty_label(self), markup=False)))
        provider_list.index = 0 if self.visible_providers else None
        select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        nav_hint = "Up/Down navigate"
        if self.search_value:
            help_text = (
                f'filter "{self.search_value}" - {nav_hint} - '
                f"{select_key} selects - {cancel_key} closes"
            )
        elif self.visible_providers:
            help_text = f"{nav_hint} - {select_key} selects - {cancel_key} closes"
        else:
            help_text = f"No matching providers - {cancel_key} closes"
        self.query_one("#login-provider-help", Static).update(help_text)

    def on_key(self, event: Key) -> None:
        """Route provider picker keys to the list."""
        search_focused = (
            isinstance(self.focused, Input)
            and getattr(self.focused, "id", None) == "login-provider-search"
        )
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up") or (
            event.key == "k" and not search_focused
        ):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(
            event.key, self.keybindings.select_down, "down"
        ) or (event.key == "j" and not search_focused):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected provider name."""
        if event.index < 0 or event.index >= len(self.visible_providers):
            return
        self.dismiss(self.visible_providers[event.index].name)

    def action_cursor_up(self) -> None:
        """Move to the previous provider."""
        self.query_one("#login-provider-list", ListView).action_cursor_up()

    def action_cursor_down(self) -> None:
        """Move to the next provider."""
        self.query_one("#login-provider-list", ListView).action_cursor_down()

    def action_select_cursor(self) -> None:
        """Select the highlighted provider."""
        if not self.visible_providers:
            return
        self.query_one("#login-provider-list", ListView).action_select_cursor()

    def action_cancel(self) -> None:
        """Close without selecting a provider."""
        self.dismiss(None)


class LoginMethodPickerScreen(ModalScreen[str | None]):
    """Login method picker for the TUI login flow."""

    def __init__(
        self,
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the login method picker."""
        with Vertical(id="login-method-picker"):
            yield Static("Login", id="login-method-title")
            yield Static("Choose how to authenticate.", id="login-method-intro")
            yield LoginMethodListView(
                ListItem(
                    Label("Subscription\n  Sign in with an OAuth account.", markup=False),
                    id="login-method-subscription",
                ),
                ListItem(
                    Label("API key\n  Save a provider API key.", markup=False),
                    id="login-method-api-key",
                ),
                id="login-method-list",
            )
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            yield Static(f"{select_key} selects - {cancel_key} closes", id="login-method-help")

    def on_mount(self) -> None:
        """Focus the default subscription method."""
        method_list = self.query_one("#login-method-list", ListView)
        method_list.index = 0
        method_list.focus()

    def on_key(self, event: Key) -> None:
        """Route arrow keys between login method buttons."""
        if (
            _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up")
            or event.key == "k"
        ):
            event.stop()
            self.action_cursor_up()
        elif (
            _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down")
            or event.key == "j"
        ):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Dismiss with the selected login method."""
        if event.button.id == "login-method-subscription":
            self.dismiss("subscription")
        elif event.button.id == "login-method-api-key":
            self.dismiss("api-key")

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected login method."""
        if event.item.id == "login-method-subscription":
            self.dismiss("subscription")
        elif event.item.id == "login-method-api-key":
            self.dismiss("api-key")

    def action_cancel(self) -> None:
        """Close without selecting a login method."""
        self.dismiss(None)

    def action_cursor_up(self) -> None:
        """Focus the previous login method."""
        self._move_method_cursor(offset=-1)

    def action_cursor_down(self) -> None:
        """Focus the next login method."""
        self._move_method_cursor(offset=1)

    def action_select_cursor(self) -> None:
        """Select the currently focused login method."""
        self.query_one("#login-method-list", ListView).action_select_cursor()

    def _move_method_cursor(self, *, offset: int) -> None:
        method_list = self.query_one("#login-method-list", ListView)
        item_count = len(method_list.children)
        if item_count == 0:
            method_list.index = None
            return
        current_index = method_list.index if method_list.index is not None else 0
        method_list.index = (current_index + offset) % item_count


class LoginMethodListView(ListView):
    """List view with wrapping arrow navigation for the login method picker."""

    def action_cursor_up(self) -> None:
        """Move to the previous login method."""
        self._move_cursor(offset=-1)

    def action_cursor_down(self) -> None:
        """Move to the next login method."""
        self._move_cursor(offset=1)

    def _move_cursor(self, *, offset: int) -> None:
        item_count = len(self.children)
        if item_count == 0:
            self.index = None
            return
        current_index = self.index if self.index is not None else 0
        self.index = (current_index + offset) % item_count


class ThemePickerScreen(ModalScreen[str | None]):
    """Theme picker for the built-in TUI themes."""

    def __init__(
        self,
        *,
        current_theme: str,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
        on_preview: Callable[[str], None] | None = None,
    ) -> None:
        super().__init__()
        self.current_theme = current_theme
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()
        self.on_preview = on_preview

    def compose(self) -> ComposeResult:
        """Compose the theme picker."""
        with Vertical(id="theme-picker"):
            yield Static("Theme", id="theme-picker-title")
            yield ListView(
                *[
                    ListItem(
                        Label(
                            _theme_picker_label(
                                theme_setting,
                                current_theme=self.current_theme,
                            ),
                            markup=False,
                        )
                    )
                    for theme_setting in _theme_picker_choices()
                ],
                id="theme-picker-list",
            )
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
            yield Static(f"{select_key} selects - {cancel_key} closes", id="theme-picker-help")

    def on_mount(self) -> None:
        """Select the current theme."""
        theme_list = self.query_one("#theme-picker-list", ListView)
        try:
            theme_list.index = _theme_picker_choices().index(self.current_theme)
        except ValueError:
            theme_list.index = 0
        theme_list.focus()

    def on_key(self, event: Key) -> None:
        """Route theme picker keys to the list."""
        if (
            _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up")
            or event.key == "k"
        ):
            event.stop()
            self.action_cursor_up()
        elif (
            _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down")
            or event.key == "j"
        ):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_select_cursor()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Dismiss with the selected theme name."""
        self.dismiss(_theme_picker_choices()[event.index])

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Preview the highlighted theme without closing the picker."""
        if self.on_preview is None or event.list_view.id != "theme-picker-list":
            return
        index = event.list_view.index
        choices = _theme_picker_choices()
        if index is None or index < 0 or index >= len(choices):
            return
        self.on_preview(choices[index])

    def action_cursor_up(self) -> None:
        """Move to the previous theme."""
        self._move(-1)

    def action_cursor_down(self) -> None:
        """Move to the next theme."""
        self._move(1)

    def action_select_cursor(self) -> None:
        """Select the highlighted theme."""
        self.query_one("#theme-picker-list", ListView).action_select_cursor()

    def action_cancel(self) -> None:
        """Close without selecting a theme."""
        self.dismiss(None)

    def _move(self, direction: Literal[-1, 1]) -> None:
        theme_list = self.query_one("#theme-picker-list", ListView)
        choices = _theme_picker_choices()
        if not choices:
            theme_list.index = None
            return
        current_index = theme_list.index if theme_list.index is not None else 0
        theme_list.index = (current_index + direction) % len(choices)


class ModelPickerSearchInput(Input):
    """Search input that keeps model-picker control keys local to the picker."""

    def _picker(self) -> ModelPickerScreen:
        return cast(ModelPickerScreen, self.screen)

    def on_key(self, event: Key) -> None:
        """Route picker control keys before the input edits its text."""
        keybindings = self._picker().keybindings
        if _matches_configured_or_default_key(event.key, keybindings.select_up, "up"):
            event.stop()
            event.prevent_default()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, keybindings.select_down, "down"):
            event.stop()
            event.prevent_default()
            self.action_cursor_down()
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            event.prevent_default()
            self.action_toggle_mode()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.models_enable_all,
            "ctrl+a",
        ):
            event.stop()
            event.prevent_default()
            self.action_enable_all_scoped()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.models_clear_all,
            "ctrl+x",
        ):
            event.stop()
            event.prevent_default()
            self.action_clear_scoped()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.models_save,
            "ctrl+s",
        ):
            event.stop()
            event.prevent_default()
            self.action_save_scoped()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.models_toggle_provider,
            "ctrl+p",
        ):
            event.stop()
            event.prevent_default()
            self.action_toggle_scoped_provider()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.models_reorder_up,
            "alt+up",
        ):
            event.stop()
            event.prevent_default()
            self.action_reorder_scoped_up()
        elif _matches_configured_or_default_key(
            event.key,
            keybindings.models_reorder_down,
            "alt+down",
        ):
            event.stop()
            event.prevent_default()
            self.action_reorder_scoped_down()
        elif _matches_configured_or_default_key(event.key, keybindings.copy_message, "ctrl+c"):
            event.stop()
            event.prevent_default()
            self.action_clear_or_cancel()
        elif _matches_configured_or_default_key(event.key, keybindings.select_cancel, "escape"):
            event.stop()
            event.prevent_default()
            self.action_cancel()

    def action_cursor_up(self) -> None:
        """Move the model picker selection up."""
        self._picker().action_cursor_up()

    def action_cursor_down(self) -> None:
        """Move the model picker selection down."""
        self._picker().action_cursor_down()

    def action_toggle_mode(self) -> None:
        """Toggle between all and scoped picker modes."""
        self._picker().action_toggle_mode()

    def action_enable_all_scoped(self) -> None:
        """Enable all visible scoped model choices."""
        self._picker().action_enable_all_scoped()

    def action_clear_scoped(self) -> None:
        """Clear all visible scoped model choices."""
        self._picker().action_clear_scoped()

    def action_save_scoped(self) -> None:
        """Surface Tau's persisted scoped model state with Pi's save key."""
        self._picker().action_save_scoped()

    def action_toggle_scoped_provider(self) -> None:
        """Toggle scoped models for the highlighted provider."""
        self._picker().action_toggle_scoped_provider()

    def action_reorder_scoped_up(self) -> None:
        """Move the highlighted scoped model earlier in cycle order."""
        self._picker().action_reorder_scoped_up()

    def action_reorder_scoped_down(self) -> None:
        """Move the highlighted scoped model later in cycle order."""
        self._picker().action_reorder_scoped_down()

    def action_clear_or_cancel(self) -> None:
        """Clear the model search, or close the picker if search is already empty."""
        self._picker().action_clear_search_or_cancel()

    def action_cancel(self) -> None:
        """Close the model picker."""
        self._picker().action_cancel()


class ModelPickerScreen(ModalScreen[ModelChoice | None]):
    """Model picker for the active TUI provider."""

    def __init__(
        self,
        choices: Sequence[ModelChoice],
        *,
        scoped_choices: Sequence[ModelChoice],
        current_model: str,
        provider_name: str,
        theme: TuiTheme,
        initial_search: str = "",
        on_toggle_scoped: Callable[[ModelChoice], Sequence[ModelChoice]] | None = None,
        on_set_scoped: Callable[[Sequence[ModelChoice]], Sequence[ModelChoice]] | None = None,
        keybindings: TuiKeybindings | None = None,
        picker_kind: Literal["model", "scoped"] = "model",
    ) -> None:
        super().__init__()
        self.choices = tuple(dict.fromkeys(choices))
        self.scoped_choices = tuple(dict.fromkeys(scoped_choices))
        self._refresh_scoped_choice_sets()
        self.visible_choices = self.choices
        self.current_model = current_model
        self.provider_name = provider_name
        self.theme = theme
        self.on_toggle_scoped = on_toggle_scoped
        self.on_set_scoped = on_set_scoped
        self.keybindings = keybindings or TuiKeybindings()
        self.picker_kind = picker_kind
        self.mode: Literal["all", "scoped"] = (
            "scoped" if picker_kind == "model" and self.scoped_choices else "all"
        )
        self.search_value = initial_search

    def compose(self) -> ComposeResult:
        """Compose the model picker."""
        with Vertical(id="model-picker"):
            title = (
                f"Model: {self.provider_name}" if self.picker_kind == "model" else "Scoped models"
            )
            yield Static(title, id="model-picker-title")
            yield Static("", id="model-picker-tabs")
            yield ModelPickerSearchInput(
                value=self.search_value,
                placeholder="Search models",
                id="model-picker-search",
            )
            yield ListView(
                *[
                    ListItem(
                        Label(
                            _model_picker_label(
                                choice,
                                current_model=self.current_model,
                                current_provider=self.provider_name,
                                scoped=choice in self.scoped_choices,
                                unavailable=choice in self.unavailable_scoped_choices,
                            ),
                            markup=False,
                        )
                    )
                    for choice in self._available_base_choices()
                ],
                id="model-picker-list",
            )
            yield Static("", id="model-picker-help")

    def on_mount(self) -> None:
        """Focus the search field."""
        search = self.query_one("#model-picker-search", Input)
        search.focus()
        self._refresh_model_list()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter model choices as the search value changes."""
        if event.input.id != "model-picker-search":
            return
        event.stop()
        self.search_value = event.value
        self._refresh_model_list()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Select the highlighted model from the search field."""
        if event.input.id != "model-picker-search":
            return
        event.stop()
        self._select_visible_choice()

    def _reset_model_list_index(self) -> None:
        """Move selection to the current model or first visible row."""
        model_list = self.query_one("#model-picker-list", ListView)
        if not self.visible_choices:
            model_list.index = None
            return
        try:
            model_list.index = self.visible_choices.index(
                ModelChoice(provider_name=self.provider_name, model=self.current_model)
            )
        except ValueError:
            model_list.index = 0

    def on_key(self, event: Key) -> None:
        """Route model picker keys to the list."""
        if _matches_configured_or_default_key(event.key, self.keybindings.select_up, "up"):
            event.stop()
            self.action_cursor_up()
        elif _matches_configured_or_default_key(event.key, self.keybindings.select_down, "down"):
            event.stop()
            self.action_cursor_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_up,
            "pageup",
        ):
            event.stop()
            self.action_page_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_page_down,
            "pagedown",
        ):
            event.stop()
            self.action_page_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self.action_accept_model()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.models_enable_all,
            "ctrl+a",
        ):
            event.stop()
            self.action_enable_all_scoped()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.models_clear_all,
            "ctrl+x",
        ):
            event.stop()
            self.action_clear_scoped()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.models_save,
            "ctrl+s",
        ):
            event.stop()
            self.action_save_scoped()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.models_toggle_provider,
            "ctrl+p",
        ):
            event.stop()
            self.action_toggle_scoped_provider()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.models_reorder_up,
            "alt+up",
        ):
            event.stop()
            self.action_reorder_scoped_up()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.models_reorder_down,
            "alt+down",
        ):
            event.stop()
            self.action_reorder_scoped_down()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.copy_message,
            "ctrl+c",
        ):
            event.stop()
            self.action_clear_search_or_cancel()
        elif event.key in {"tab", "ctrl+i"}:
            event.stop()
            self.action_toggle_mode()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle the selected row."""
        event.stop()
        self._select_visible_choice()

    def action_cursor_up(self) -> None:
        """Move to the previous model."""
        self._move_model_cursor(-1)

    def action_cursor_down(self) -> None:
        """Move to the next model."""
        self._move_model_cursor(1)

    def _move_model_cursor(self, direction: Literal[-1, 1]) -> None:
        """Move selected model, wrapping at list boundaries like Pi."""
        if not self.visible_choices:
            return
        model_list = self.query_one("#model-picker-list", ListView)
        current_index = model_list.index if model_list.index is not None else 0
        model_list.index = (current_index + direction) % len(self.visible_choices)

    def action_page_up(self) -> None:
        """Move up by a page of models."""
        self._move_model_page(-1)

    def action_page_down(self) -> None:
        """Move down by a page of models."""
        self._move_model_page(1)

    def _move_model_page(self, direction: Literal[-1, 1]) -> None:
        """Move the selected model by a viewport-sized page."""
        if not self.visible_choices:
            return
        model_list = self.query_one("#model-picker-list", ListView)
        current_index = model_list.index if model_list.index is not None else 0
        page_size = max(1, model_list.size.height - 1)
        if page_size <= 1:
            page_size = 10
        next_index = current_index + (direction * page_size)
        model_list.index = max(0, min(len(self.visible_choices) - 1, next_index))

    def action_accept_model(self) -> None:
        """Select the highlighted model."""
        self._select_visible_choice()

    def action_toggle_mode(self) -> None:
        """Toggle between all models and scoped models."""
        if self.picker_kind != "model":
            return
        self.mode = "scoped" if self.mode == "all" else "all"
        self._refresh_model_list()

    def action_toggle_scoped(self) -> None:
        """Add or remove the highlighted model from scoped models."""
        if self.on_toggle_scoped is None or not self.visible_choices:
            return
        model_list = self.query_one("#model-picker-list", ListView)
        index = model_list.index
        if index is None:
            return
        choice = self.visible_choices[index]
        if choice in self.unavailable_scoped_choices:
            if self.picker_kind != "scoped" or self.on_set_scoped is None:
                return
            self._set_scoped_choices(
                self.on_set_scoped(
                    tuple(item for item in self.scoped_choices if item != choice)
                )
            )
            self._refresh_model_list()
            return
        self._set_scoped_choices(self.on_toggle_scoped(choice))
        self._refresh_model_list()

    def action_enable_all_scoped(self) -> None:
        """Add all visible target models to scoped models."""
        if self.picker_kind != "scoped" or self.on_set_scoped is None:
            return
        target_choices = (
            self.visible_choices if self.search_value else self._available_base_choices()
        )
        target_choices = tuple(
            choice for choice in target_choices if choice not in self.unavailable_scoped_choices
        )
        self._set_scoped_choices(self.on_set_scoped((*self.scoped_choices, *target_choices)))
        self._refresh_model_list()

    def action_clear_scoped(self) -> None:
        """Remove all visible target models from scoped models."""
        if self.picker_kind != "scoped" or self.on_set_scoped is None:
            return
        target_choices = set(
            self.visible_choices if self.search_value else self._available_base_choices()
        )
        self._set_scoped_choices(
            self.on_set_scoped(
                tuple(choice for choice in self.scoped_choices if choice not in target_choices)
            )
        )
        self._refresh_model_list()

    def action_save_scoped(self) -> None:
        """Report the scoped model list as saved for Pi-compatible Ctrl+S muscle memory."""
        if self.picker_kind != "scoped":
            return
        app = cast(Any, self.app)
        app._notify(f"Scoped models saved ({len(self.scoped_choices)} scoped).")
        self._refresh_model_list()

    def action_toggle_scoped_provider(self) -> None:
        """Toggle all scoped models for the highlighted provider."""
        if self.picker_kind != "scoped" or self.on_set_scoped is None or not self.visible_choices:
            return
        model_list = self.query_one("#model-picker-list", ListView)
        index = model_list.index
        if index is None:
            return
        if self.visible_choices[index] in self.unavailable_scoped_choices:
            return
        provider_name = self.visible_choices[index].provider_name
        provider_choices = tuple(
            choice for choice in self.choices if choice.provider_name == provider_name
        )
        scoped = list(self.scoped_choices)
        if provider_choices and all(choice in scoped for choice in provider_choices):
            scoped = [choice for choice in scoped if choice.provider_name != provider_name]
        else:
            scoped = list(dict.fromkeys((*scoped, *provider_choices)))
        self._set_scoped_choices(self.on_set_scoped(tuple(scoped)))
        self._refresh_model_list()

    def action_reorder_scoped_up(self) -> None:
        """Move the highlighted scoped model earlier in cycle order."""
        self._reorder_highlighted_scoped_choice(-1)

    def action_reorder_scoped_down(self) -> None:
        """Move the highlighted scoped model later in cycle order."""
        self._reorder_highlighted_scoped_choice(1)

    def _reorder_highlighted_scoped_choice(self, delta: Literal[-1, 1]) -> None:
        """Move the highlighted scoped model in the persisted scoped order."""
        if self.picker_kind != "scoped" or self.on_set_scoped is None or not self.visible_choices:
            return
        model_list = self.query_one("#model-picker-list", ListView)
        index = model_list.index
        if index is None:
            return
        choice = self.visible_choices[index]
        scoped = list(self.scoped_choices)
        try:
            scoped_index = scoped.index(choice)
        except ValueError:
            return
        next_index = scoped_index + delta
        if next_index < 0 or next_index >= len(scoped):
            return
        scoped[scoped_index], scoped[next_index] = scoped[next_index], scoped[scoped_index]
        self._set_scoped_choices(self.on_set_scoped(tuple(scoped)))
        self._refresh_model_list()
        if choice in self.visible_choices:
            model_list.index = self.visible_choices.index(choice)

    def action_cancel(self) -> None:
        """Close without selecting a model."""
        self.dismiss(None)

    def action_clear_search_or_cancel(self) -> None:
        """Clear search text, or cancel when the picker search is already empty."""
        if self.search_value:
            self.search_value = ""
            search = self.query_one("#model-picker-search", Input)
            search.value = ""
            self._refresh_model_list()
            return
        self.action_cancel()

    def _select_visible_choice(self) -> None:
        if not self.visible_choices:
            return
        model_list = self.query_one("#model-picker-list", ListView)
        index = model_list.index
        if index is None:
            return
        choice = self.visible_choices[index]
        if self.picker_kind == "scoped":
            self.action_toggle_scoped()
            return
        self.dismiss(choice)

    def _refresh_model_list(self) -> None:
        base_choices = self._available_base_choices()
        self.visible_choices = _filter_model_choices(base_choices, self.search_value)
        model_list = self.query_one("#model-picker-list", ListView)
        model_list.clear()
        model_list.extend(
            [
                ListItem(
                    Label(
                        _model_picker_label(
                            choice,
                            current_model=self.current_model,
                            current_provider=self.provider_name,
                            scoped=choice in self.scoped_choices,
                            unavailable=choice in self.unavailable_scoped_choices,
                        ),
                        markup=False,
                    )
                )
                for choice in self.visible_choices
            ]
        )
        self._reset_model_list_index()
        scope_count = len(self.scoped_choices)
        unavailable_count = len(self.unavailable_scoped_choices)
        tabs = self.query_one("#model-picker-tabs", Static)
        if self.picker_kind == "scoped":
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            enable_key = _key_hint_with_default(self.keybindings.models_enable_all, "ctrl+a")
            clear_key = _key_hint_with_default(self.keybindings.models_clear_all, "ctrl+x")
            provider_key = _key_hint_with_default(
                self.keybindings.models_toggle_provider,
                "ctrl+p",
            )
            reorder_up_key = _key_hint_with_default(self.keybindings.models_reorder_up, "alt+up")
            reorder_down_key = _key_hint_with_default(
                self.keybindings.models_reorder_down,
                "alt+down",
            )
            save_key = _key_hint_with_default(self.keybindings.models_save, "ctrl+s")
            tabs.update(
                f"Scoped models setup — {select_key} toggles membership; active model is unchanged"
            )
            help_text = (
                f"No matching models - {enable_key}/{clear_key} apply to matching models"
                if not self.visible_choices
                else (
                    f"{select_key} toggles - {enable_key} all - {clear_key} clear - "
                    f"{provider_key} provider - {reorder_up_key}/{reorder_down_key} reorder - "
                    f"{save_key} save - {scope_count} scoped"
                    + (f", {unavailable_count} unavailable" if unavailable_count else "")
                )
            )
        elif self.mode == "all":
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            tabs.update("Tabs: ● All models  ○ Scoped models")
            help_text = (
                "all models: no matching models - Tab switches to scoped models"
                if not self.visible_choices
                else (
                    f"All models - {select_key} selects active model - Tab switches tabs - "
                    f"{scope_count} scoped"
                )
            )
        else:
            select_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
            tabs.update("Tabs: ○ All models  ● Scoped models")
            help_text = (
                "scoped models: no matching models - Tab switches to all models"
                if not self.visible_choices
                else f"Scoped models - {select_key} selects active model - Tab switches tabs"
            )
        self.query_one("#model-picker-help", Static).update(help_text)

    def _available_base_choices(self) -> tuple[ModelChoice, ...]:
        if self.picker_kind == "scoped":
            return self.scoped_picker_choices
        return self.scoped_choices if self.mode == "scoped" else self.choices

    def _set_scoped_choices(self, choices: Sequence[ModelChoice]) -> None:
        self.scoped_choices = tuple(dict.fromkeys(choices))
        self._refresh_scoped_choice_sets()

    def _refresh_scoped_choice_sets(self) -> None:
        self.unavailable_scoped_choices = tuple(
            choice for choice in self.scoped_choices if choice not in self.choices
        )
        self.scoped_picker_choices = tuple(
            dict.fromkeys((*self.choices, *self.unavailable_scoped_choices))
        )


class LoginScreen(ModalScreen[str | None]):
    """Password prompt for saving a provider API key."""

    def __init__(
        self,
        provider: ProviderCatalogEntry,
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.provider = provider
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()

    def compose(self) -> ComposeResult:
        """Compose the provider login prompt."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="login-screen"):
            yield Static(f"Login: {self.provider.display_name}", id="login-title")
            yield Static("Paste this provider's API key.", id="login-help")
            yield Input(placeholder="Paste API key", password=True, id="login-api-key")
            yield Static(f"{confirm_key} saves - {cancel_key} closes", id="login-footer")

    def on_mount(self) -> None:
        """Focus the API key field."""
        self.query_one("#login-api-key", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Dismiss with the submitted API key."""
        if event.input.id != "login-api-key":
            return
        event.stop()
        self._submit_api_key()

    def on_key(self, event: Key) -> None:
        """Route configured login dialog keys."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self._submit_api_key()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def _submit_api_key(self) -> None:
        value = self.query_one("#login-api-key", Input).value.strip()
        self.dismiss(value or None)

    def action_cancel(self) -> None:
        """Close without saving."""
        self.dismiss(None)


class OAuthLoginScreen(ModalScreen[OAuthCredential | None]):
    """OAuth login flow for providers backed by subscription auth."""

    def __init__(
        self,
        provider: ProviderCatalogEntry,
        *,
        theme: TuiTheme,
        keybindings: TuiKeybindings | None = None,
    ) -> None:
        super().__init__()
        self.provider = provider
        self.theme = theme
        self.keybindings = keybindings or TuiKeybindings()
        self._manual_code_future: asyncio.Future[str] | None = None
        self._manual_code_value: str | None = None

    def compose(self) -> ComposeResult:
        """Compose the OAuth login prompt."""
        confirm_key = _key_hint_with_default(self.keybindings.select_confirm, "enter")
        cancel_key = _key_hint_with_default(self.keybindings.select_cancel, "escape")
        with Vertical(id="login-screen"):
            yield Static(f"Login: {self.provider.display_name}", id="login-title")
            yield Static("Complete the browser login, or paste the redirect URL.", id="login-help")
            yield Static("", id="login-oauth-url")
            yield Input(
                placeholder="Paste redirect URL or authorization code",
                id="login-oauth-code",
            )
            yield Static(f"{confirm_key} submits - {cancel_key} closes", id="login-footer")

    def on_mount(self) -> None:
        """Focus the manual-code field and start OAuth."""
        self.query_one("#login-oauth-code", Input).focus()
        self.run_worker(self._run_login(), exclusive=True)

    async def _run_login(self) -> None:
        try:
            credential = await login_openai_codex(
                on_auth=self._show_auth,
                on_prompt=self._prompt_for_code,
                on_manual_code_input=self._manual_code_input,
                on_progress=self._show_progress,
            )
        except Exception as exc:  # noqa: BLE001 - surface OAuth failures in the TUI
            self.query_one("#login-help", Static).update(f"OAuth failed: {exc}")
            return
        self.dismiss(credential)

    def _show_auth(self, info: OAuthAuthInfo) -> None:
        self.query_one("#login-oauth-url", Static).update(info.url)
        if info.instructions:
            self.query_one("#login-help", Static).update(info.instructions)

    def _show_progress(self, message: str) -> None:
        self.query_one("#login-help", Static).update(message)

    async def _prompt_for_code(self, prompt: OAuthPrompt) -> str:
        self.query_one("#login-help", Static).update(prompt.message)
        return await self._manual_code_input()

    async def _manual_code_input(self) -> str:
        if self._manual_code_value is not None:
            return self._manual_code_value
        loop = asyncio.get_running_loop()
        self._manual_code_future = loop.create_future()
        try:
            return await self._manual_code_future
        finally:
            self._manual_code_future = None

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Resolve the manual OAuth code fallback."""
        if event.input.id != "login-oauth-code":
            return
        event.stop()
        self._submit_manual_code()

    def on_key(self, event: Key) -> None:
        """Route configured OAuth dialog keys."""
        if _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_confirm,
            "enter",
        ):
            event.stop()
            self._submit_manual_code()
        elif _matches_configured_or_default_key(
            event.key,
            self.keybindings.select_cancel,
            "escape",
        ):
            event.stop()
            self.action_cancel()

    def _submit_manual_code(self) -> None:
        value = self.query_one("#login-oauth-code", Input).value.strip()
        if not value:
            return
        self._manual_code_value = value
        if self._manual_code_future is not None and not self._manual_code_future.done():
            self._manual_code_future.set_result(value)

    def action_cancel(self) -> None:
        """Close without saving OAuth credentials."""
        if self._manual_code_future is not None and not self._manual_code_future.done():
            self._manual_code_future.cancel()
        self.dismiss(None)


class TauTuiApp(App[None]):
    """Interactive Textual frontend for a ``CodingSession``."""

    TITLE = "Tau"
    CSS = """
    Screen {
        layout: vertical;
        background: $tau-screen-background;
        color: $tau-screen-text;
    }

    Header {
        background: $tau-chrome-background;
        color: $tau-muted-text;
        dock: top;
    }

    Footer {
        background: $tau-chrome-background;
        color: $tau-chrome-text;
    }

    Footer FooterKey {
        background: $tau-chrome-background;
        color: $tau-chrome-text;
    }

    Footer FooterKey .footer-key--key {
        background: $tau-chrome-background;
        color: $tau-accent;
    }

    Footer FooterKey .footer-key--description,
    Footer FooterLabel {
        background: $tau-chrome-background;
        color: $tau-chrome-text;
    }

    Toast {
        background: $tau-chrome-background;
        color: $tau-chrome-text;
    }

    Toast .toast--title {
        color: $tau-accent;
    }

    #workspace {
        height: 1fr;
    }

    #sidebar {
        width: 32;
        min-width: 28;
        height: 1fr;
        padding: 1 1 0 0;
        background: $tau-sidebar-background;
        border-right: tall $tau-border;
        overflow-y: auto;
        scrollbar-size-vertical: 1;
    }

    TauTuiApp.-hide-sidebar #sidebar {
        display: none;
    }

    TauTuiApp.-hide-sidebar #main-pane {
        padding-left: 1;
    }

    TauTuiApp.-sidebar-right #sidebar {
        dock: right;
    }

    #main-pane {
        width: 1fr;
        padding: 1 1 0 1;
    }

    #startup-resources {
        height: auto;
        max-height: 12;
        margin: 0 1 1 2;
        padding: 0 1;
        color: $tau-muted-text;
    }

    #transcript {
        height: 1fr;
        border: none;
        background: $tau-transcript-background;
        padding: 0 0 0 2;
        scrollbar-size-vertical: 0;
        scrollbar-size-horizontal: 0;
    }

    #queued-messages {
        height: auto;
        max-height: 8;
        margin: 0 1 1 1;
        padding: 0 1;
        background: $tau-screen-background;
        color: $tau-muted-text;
    }

    #extension-status {
        height: auto;
        margin: 0 1 1 1;
        padding: 0 1;
        background: $tau-screen-background;
        color: $tau-muted-text;
    }

    #extension-footer {
        height: auto;
        padding: 0 1;
        background: $tau-chrome-background;
        color: $tau-muted-text;
    }

    #extension-widgets-above,
    #extension-widgets-below,
    #extension-widget-components-above,
    #extension-widget-components-below {
        height: auto;
        margin: 0 1 1 1;
        padding: 0 1;
        background: $tau-screen-background;
        color: $tau-screen-text;
    }

    #prompt-row {
        height: auto;
        margin: 0 1 1 1;
    }

    #prompt-prefix {
        width: 2;
        height: 3;
        padding: 0 0 0 0;
        margin: 0;
        content-align: center middle;
        color: $tau-accent;
        text-style: bold;
    }

    #prompt-working-message {
        width: auto;
        max-width: 32;
        height: 1;
        margin: 1 1 0 0;
        color: $tau-muted-text;
    }

    #prompt {
        width: 1fr;
        height: auto;
        background: $tau-prompt-background;
        color: $tau-prompt-text;
        border: tall transparent;
        margin: 0;
        padding: 0 1;
        max-height: 8;
    }

    #prompt:focus {
        border: tall $tau-prompt-border;
    }

    #prompt.-shell-mode {
        border: tall $tau-tool-running;
    }

    #compact-session-info {
        height: auto;
        max-height: 3;
        margin: 0 1 1 1;
        padding: 0 1;
        color: $tau-muted-text;
    }

    #autocomplete {
        height: auto;
        max-height: 18;
        margin: 0 1 1 1;
        padding: 0 1;
        background: $tau-autocomplete-background;
        color: $tau-screen-text;
        border: tall $tau-border;
        overflow-y: auto;
    }

    SessionPickerScreen,
    SettingsPickerScreen,
    ThinkingPickerScreen,
    ImageVisibilityPickerScreen,
    TreePickerScreen,
    UserMessagePickerScreen,
    WorkflowPickerScreen,
    ToolsReferenceScreen,
    SkillPickerScreen,
    PromptTemplatePickerScreen,
    TreeLabelInputScreen,
    ConfigMapScreen,
    FirstTimeSetupScreen,
    CommandOutputScreen,
    ConfirmationScreen {
        align: center middle;
    }

    #session-picker,
    #settings-picker,
    #thinking-picker,
    #image-visibility-picker,
    #first-time-setup,
    #tree-picker,
    #user-message-picker,
    #workflow-picker,
    #tools-reference,
    #skill-picker,
    #prompt-template-picker,
    #tree-label-input,
    #config-map,
    #confirmation {
        width: 76;
        max-width: 90%;
        height: auto;
        max-height: 70%;
        padding: 1 2;
        background: $tau-chrome-background;
        border: tall $tau-border;
    }

    #session-picker-title,
    #settings-picker-title,
    #thinking-picker-title,
    #image-visibility-picker-title,
    #first-time-setup-title,
    #tree-picker-title,
    #user-message-picker-title,
    #workflow-picker-title,
    #tools-reference-title,
    #skill-picker-title,
    #prompt-template-picker-title,
    #config-map-title,
    #tree-label-title {
        height: 1;
        color: $tau-chrome-text;
        text-style: bold;
        margin-bottom: 1;
    }

    #config-map-tabs {
        height: 1;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #config-map-write-target {
        height: 1;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #first-time-setup-description,
    #user-message-picker-description,
    #workflow-picker-description {
        height: auto;
        max-height: 2;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #tree-picker-search {
        height: 1;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #tools-reference-header {
        height: 1;
        color: $tau-muted-text;
        text-style: bold;
    }

    #session-picker-list,
    #settings-picker-list,
    #thinking-picker-list,
    #image-visibility-picker-list,
    #first-time-setup-list,
    #tree-picker-list,
    #user-message-picker-list,
    #workflow-picker-list,
    #tools-reference-list,
    #skill-picker-list,
    #prompt-template-picker-list,
    #config-map-list {
        height: auto;
        max-height: 16;
        background: $tau-transcript-background;
        border: tall $tau-border;
    }

    #artifact-browser-preview-scroll {
        height: auto;
        max-height: 16;
        margin-top: 1;
        padding: 0 1;
        background: $tau-transcript-background;
        border: tall $tau-border;
        scrollbar-size-vertical: 1;
    }

    #artifact-browser-preview {
        height: auto;
        background: $tau-transcript-background;
    }

    #workflow-picker-list {
        max-height: 22;
    }

    ListView > ListItem.-highlight {
        background: $tau-highlight-background;
        color: $tau-highlight-text;
    }

    ListView > ListItem.-highlight Label {
        background: $tau-highlight-background;
        color: $tau-highlight-text;
    }

    #session-picker-help,
    #settings-picker-help,
    #thinking-picker-help,
    #image-visibility-picker-help,
    #first-time-setup-help,
    #tree-picker-help,
    #user-message-picker-help,
    #workflow-picker-help,
    #tools-reference-help,
    #skill-picker-help,
    #prompt-template-picker-help,
    #config-map-help,
    #tree-label-help {
        height: 1;
        margin-top: 1;
        color: $tau-muted-text;
    }

    #tree-picker-help {
        height: auto;
        max-height: 3;
    }

    #session-picker-search,
    #workflow-picker-search,
    #tools-reference-search,
    #skill-picker-search,
    #prompt-template-picker-search,
    #artifact-browser-search,
    #config-map-search,
    #tree-label-value {
        height: 3;
        margin-bottom: 1;
        background: $tau-prompt-background;
        color: $tau-prompt-text;
        border: tall $tau-prompt-border;
    }

    .skill-picker-row {
        height: 1;
    }

    .skill-picker-name {
        width: 24;
        color: $tau-screen-text;
    }

    .skill-picker-description {
        width: 1fr;
        color: $tau-muted-text;
    }

    #command-output {
        width: 76;
        max-width: 90%;
        height: auto;
        max-height: 70%;
        padding: 1 2;
        background: $tau-chrome-background;
        color: $tau-chrome-text;
        border: tall $tau-border;
    }

    #command-output-title {
        height: 1;
        color: $tau-chrome-text;
        text-style: bold;
        margin-bottom: 1;
    }

    #command-output-scroll {
        height: auto;
        max-height: 18;
        background: $tau-transcript-background;
        border: tall $tau-border;
    }

    #command-output-body {
        color: $tau-screen-text;
        padding: 1;
    }

    #command-output-help {
        height: 1;
        margin-top: 1;
        color: $tau-muted-text;
    }

    LoginMethodPickerScreen,
    LoginProviderPickerScreen,
    ThemePickerScreen,
    ModelPickerScreen {
        align: center middle;
    }

    #login-method-picker,
    #login-provider-picker,
    #theme-picker,
    #model-picker {
        width: 76;
        max-width: 90%;
        height: auto;
        max-height: 70%;
        padding: 1 2;
        background: $tau-chrome-background;
        color: $tau-chrome-text;
        border: tall $tau-border;
    }

    #login-method-title,
    #login-provider-title,
    #theme-picker-title,
    #model-picker-title {
        height: 1;
        color: $tau-chrome-text;
        text-style: bold;
        margin-bottom: 1;
    }

    #model-picker-tabs {
        height: 1;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #login-method-list,
    #login-provider-list,
    #theme-picker-list,
    #model-picker-list {
        height: auto;
        max-height: 12;
        background: $tau-transcript-background;
        color: $tau-screen-text;
        border: tall $tau-border;
    }

    #login-method-list ListItem Label,
    #login-provider-list ListItem Label,
    #theme-picker-list ListItem Label,
    #model-picker-list ListItem Label {
        color: $tau-screen-text;
    }

    #login-method-list ListItem.-highlight Label,
    #login-provider-list ListItem.-highlight Label,
    #theme-picker-list ListItem.-highlight Label,
    #model-picker-list ListItem.-highlight Label {
        background: $tau-highlight-background;
        color: $tau-highlight-text;
    }

    #login-method-intro {
        height: 1;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #login-method-list {
        max-height: 6;
    }

    #login-provider-search,
    #model-picker-search {
        height: 3;
        margin-bottom: 1;
        background: $tau-prompt-background;
        color: $tau-prompt-text;
        border: tall $tau-prompt-border;
    }

    #login-method-help,
    #login-provider-help,
    #theme-picker-help,
    #model-picker-help {
        height: 1;
        margin-top: 1;
        color: $tau-muted-text;
    }

    LoginScreen,
    OAuthLoginScreen {
        align: center middle;
    }

    #login-screen {
        width: 72;
        max-width: 92%;
        height: auto;
        padding: 1 2;
        background: $tau-chrome-background;
        border: tall $tau-border;
    }

    #login-title {
        height: 1;
        color: $tau-chrome-text;
        text-style: bold;
        margin-bottom: 1;
    }

    #login-help {
        height: 1;
        color: $tau-muted-text;
        margin-bottom: 1;
    }

    #login-api-key,
    #login-oauth-code {
        background: $tau-prompt-background;
        color: $tau-prompt-text;
        border: tall $tau-prompt-border;
        margin-bottom: 1;
    }

    #login-oauth-url {
        min-height: 1;
        max-height: 4;
        color: $tau-chrome-text;
        margin-bottom: 1;
    }

    #login-footer {
        height: 1;
        color: $tau-muted-text;
    }
    """
    BINDINGS: ClassVar[list[BindingEntry]] = []

    def __init__(
        self,
        session: CodingSession,
        *,
        tui_settings: TuiSettings | None = None,
        project_tui_settings: ProjectTuiSettings | None = None,
        startup_message: str | None = None,
        initial_prompt: str | None = None,
        startup_resume_picker: bool = False,
        show_first_time_setup: bool = False,
    ) -> None:
        self.tui_settings = tui_settings or TuiSettings()
        self.project_tui_settings = (
            project_tui_settings or load_project_tui_settings(session.cwd)
        )
        self.startup_message = startup_message
        self.initial_prompt = initial_prompt
        self.startup_resume_picker = startup_resume_picker
        self.show_first_time_setup = show_first_time_setup
        super().__init__()
        self._bindings = BindingsMap(_app_bindings(self.tui_settings.keybindings))
        self.session = session
        set_extension_ui_handler = getattr(self.session, "set_extension_ui_handler", None)
        if callable(set_extension_ui_handler):
            set_extension_ui_handler(self._handle_extension_ui_request)
        set_terminal_input_handler = getattr(
            self.session,
            "set_extension_terminal_input_handler",
            None,
        )
        if callable(set_terminal_input_handler):
            set_terminal_input_handler(self._register_extension_terminal_input_listener)
        set_autocomplete_provider_handler = getattr(
            self.session,
            "set_extension_autocomplete_provider_handler",
            None,
        )
        if callable(set_autocomplete_provider_handler):
            set_autocomplete_provider_handler(
                self._register_extension_autocomplete_provider
            )
        set_editor_component_handler = getattr(
            self.session,
            "set_extension_editor_component_handler",
            None,
        )
        if callable(set_editor_component_handler):
            set_editor_component_handler(self._handle_extension_editor_component)
        set_widget_component_handler = getattr(
            self.session,
            "set_extension_widget_component_handler",
            None,
        )
        if callable(set_widget_component_handler):
            set_widget_component_handler(self._handle_extension_widget_component)
        set_chrome_component_handler = getattr(
            self.session,
            "set_extension_chrome_component_handler",
            None,
        )
        if callable(set_chrome_component_handler):
            set_chrome_component_handler(self._handle_extension_chrome_component)
        self.state = TuiState(
            skills=session.skills,
            show_thinking=not self.tui_settings.hide_thinking,
        )
        self._load_session_transcript()
        self.adapter = TuiEventAdapter(
            self.state,
            extension_tool_sources=getattr(session, "extension_tool_sources", {}),
            extension_tool_renderers=getattr(session, "extension_tool_renderers", {}),
        )
        self._prompt_worker: Worker[None] | None = None
        self._compaction_worker: Worker[None] | None = None
        self._branch_worker: Worker[None] | None = None
        self._reload_worker: Worker[None] | None = None
        self._share_worker: Worker[None] | None = None
        self._compaction_queued_messages: list[tuple[str, Literal["steer", "follow_up"]]] = []
        self._terminal_worker: Worker[None] | None = None
        self._prompt_run_id = 0
        self._completion_refresh_run_id = 0
        self._completion_state = CompletionState()
        self._activity_frame = 0
        self._activity_timer: Timer | None = None
        self._activity_timer_interval_seconds: float | None = None
        self._retry_countdown_timer: Timer | None = None
        self._retry_countdown_expires_at: float | None = None
        self._retry_countdown_message: str | None = None
        self._retry_countdown_attempt: int | None = None
        self._retry_countdown_max_attempts: int | None = None
        self._terminal_progress_active = False
        self._last_dag_viewer_run_dir: Path | None = None
        self._last_dag_viewer_launch_command: tuple[str, ...] | None = None
        self._dag_viewer_servers: list[RunningDagViewerServer] = []
        self._dag_viewer_threads: list[threading.Thread] = []
        self._terminal_title = TerminalTitleController()
        self._extension_terminal_title: str | None = None
        self._extension_header_lines: tuple[str, ...] | None = None
        self._extension_footer_lines: tuple[str, ...] | None = None
        self._extension_header_component_factory: Callable[..., object] | None = None
        self._extension_header_component_name: str | None = None
        self._extension_footer_component_factory: Callable[..., object] | None = None
        self._extension_footer_component_name: str | None = None
        self._extension_widget_components_above: dict[str, Callable[..., object]] = {}
        self._extension_widget_component_names_above: dict[str, str] = {}
        self._extension_widget_components_below: dict[str, Callable[..., object]] = {}
        self._extension_widget_component_names_below: dict[str, str] = {}
        self._extension_working_visible = True
        self._extension_working_message: str | None = None
        self._extension_working_indicator_frames: tuple[str, ...] | None = None
        self._extension_working_indicator_interval_seconds: float | None = None
        self._terminal_notification = TerminalNotificationController(
            self.tui_settings.turn_notification
        )
        self._extension_statuses: dict[str, str] = {}
        self._extension_footer_branch_callback_id = 0
        self._extension_footer_branch_callbacks: dict[int, Callable[[], object]] = {}
        self._extension_footer_branch_last: str | None = None
        self._extension_footer_branch_timer: Timer | None = None
        self._extension_widgets_above: dict[str, tuple[str, ...]] = {}
        self._extension_widgets_below: dict[str, tuple[str, ...]] = {}
        self._extension_terminal_input_listener_id = 0
        self._extension_terminal_input_listeners: dict[
            int,
            tuple[str, Callable[[str], object]],
        ] = {}
        self._extension_autocomplete_provider_id = 0
        self._extension_autocomplete_providers: dict[
            int,
            tuple[str, Callable[[object], object]],
        ] = {}
        self._extension_editor_component_factory: Callable[..., object] | None = None
        self._extension_editor_component_name: str | None = None
        self._app_has_focus = True
        self._active_notification_keys: set[tuple[str, str]] = set()
        self._pending_decision_keys: set[str] = set()
        self._supports_pyperclip: bool | None = None
        self._last_clear_prompt_at: float | None = None
        self._theme_picker_original_theme: str | None = None
        self._last_empty_escape_at: float | None = None
        self._pty_proof_enabled = os.environ.get("TAU_TUI_PTY_PROOF") == "1"
        self._pty_proof_run_id = os.environ.get("TAU_TUI_PTY_RUN_ID", "tau-real-tui")
        self._anthropic_subscription_warning_shown = False

    def _load_session_transcript(self) -> None:
        """Load provider messages plus durable extension/application entries."""
        self.state.load_messages(
            self.session.messages,
            extension_tool_sources=getattr(self.session, "extension_tool_sources", {}),
            extension_tool_renderers=getattr(self.session, "extension_tool_renderers", {}),
        )
        session_state = getattr(self.session, "state", None)
        custom_entries = getattr(session_state, "custom_entries", ())
        entry_renderers = getattr(self.session, "extension_entry_renderers", {})
        message_renderers = getattr(self.session, "extension_message_renderers", {})
        self.state.load_custom_entries(
            custom_entries,
            entry_renderers=entry_renderers,
            message_renderers=message_renderers,
        )

    def _reset_extension_ui_state(self) -> None:
        """Clear extension-owned TUI state before rebinding resources or sessions."""
        had_extension_editor = self._extension_editor_component_factory is not None
        self._extension_terminal_input_listeners.clear()
        self._extension_autocomplete_providers.clear()
        self._extension_header_lines = None
        self._extension_footer_lines = None
        self._extension_header_component_factory = None
        self._extension_header_component_name = None
        self._extension_footer_component_factory = None
        self._extension_footer_component_name = None
        self._extension_widgets_above.clear()
        self._extension_widgets_below.clear()
        self._extension_widget_components_above.clear()
        self._extension_widget_component_names_above.clear()
        self._extension_widget_components_below.clear()
        self._extension_widget_component_names_below.clear()
        self._extension_statuses.clear()
        self._clear_extension_footer_branch_listeners()
        self._extension_working_visible = True
        self._extension_working_message = None
        self._extension_working_indicator_frames = None
        self._extension_working_indicator_interval_seconds = None
        self._extension_editor_component_factory = None
        self._extension_editor_component_name = None
        self._extension_terminal_title = None
        self.state.hidden_thinking_label = None
        self._clear_extension_chrome_component("header")
        self._clear_extension_chrome_component("footer")
        self._clear_extension_widget_component_container("above_editor")
        self._clear_extension_widget_component_container("below_editor")
        if had_extension_editor:
            self._apply_extension_editor_component()
        self._sync_terminal_title()
        self._refresh_current_prompt_completions()
        self._sync_activity_indicator()

    def copy_to_clipboard(self, text: str) -> None:
        """Copy text using native clipboard helpers, then Textual's fallback."""
        copied = False
        if self._supports_pyperclip is None:
            try:
                import pyperclip  # type: ignore[import-untyped]
            except ImportError:
                self._supports_pyperclip = False
            else:
                self._supports_pyperclip = True
        if self._supports_pyperclip:
            import pyperclip

            with suppress(Exception):
                pyperclip.copy(text)
                copied = True
        if not copied:
            with suppress(Exception):
                copied = _copy_text_with_platform_command(text)
        try:
            super().copy_to_clipboard(text)
        except Exception:
            if not copied:
                raise

    def get_theme_variable_defaults(self) -> dict[str, str]:
        """Return Tau-specific CSS variables for the selected TUI theme."""
        variables = super().get_theme_variable_defaults()
        return {**variables, **_theme_css_variables(self.tui_settings.resolved_theme)}

    def compose(self) -> ComposeResult:
        """Compose the TUI widgets."""
        yield Header()
        with Horizontal(id="workspace"):
            yield SessionSidebar(id="sidebar")
            with Vertical(id="main-pane"):
                if self._pty_proof_enabled:
                    yield Static(pty_ready_line(self._pty_proof_run_id), id="pty-proof-ready")
                yield Static("", id="startup-resources")
                yield Vertical(id="extension-header-component")
                yield TranscriptView(
                    id="transcript",
                    min_width=1,
                    clear_on_shrink=self.tui_settings.clear_on_shrink,
                    output_padding_x=self.tui_settings.output_padding_x,
                    wrap=True,
                    highlight=True,
                    markup=False,
                )
                yield Static("", id="queued-messages")
                yield Static("", id="extension-status")
                yield Static("", id="extension-widgets-above")
                yield Vertical(id="extension-widget-components-above")
                with Horizontal(id="prompt-row"):
                    yield Static("τ", id="prompt-prefix")
                    yield Static("", id="prompt-working-message")
                    yield PromptInput(
                        placeholder=_prompt_placeholder(self.tui_settings.keybindings),
                        id="prompt",
                        tui_keybindings=self.tui_settings.keybindings,
                        show_cursor=self.tui_settings.show_hardware_cursor,
                    )
                yield Static("", id="extension-widgets-below")
                yield Vertical(id="extension-widget-components-below")
                yield DagRunStatusPane("", id="dag-run-status-pane")
                yield CompactSessionInfo(id="compact-session-info")
                yield Static("", id="autocomplete")
        yield Static("", id="extension-footer")
        yield Vertical(id="extension-footer-component")
        yield Footer()

    async def on_mount(self) -> None:
        """Focus the prompt when the app starts."""
        prompt = self.query_one(PromptInput)
        prompt.shell_mode_style = self.tui_settings.resolved_theme.role_styles["tool"].border
        _apply_prompt_padding(prompt, self.tui_settings.editor_padding_x)
        self._sync_prompt_shell_mode(prompt.text)
        prompt.focus()
        self._update_responsive_layout(self.size.width, self.size.height)
        self._apply_sidebar_position()
        self._refresh_pending_decisions(notify=False)
        self._refresh()
        self._refresh_completions()
        if self.startup_message and not self.tui_settings.quiet_startup:
            self._notify(self.startup_message, severity="warning")
        if not self.tui_settings.quiet_startup:
            self._maybe_warn_anthropic_subscription_auth()
        if not self.tui_settings.quiet_startup and not self.is_headless:
            self.run_worker(self._warn_about_tmux_keyboard_setup(), exclusive=False)
        self.set_interval(
            DAG_RUN_STATUS_POLL_SECONDS,
            self._refresh_dag_run_status,
            name="dag-run-status",
        )
        if self.show_first_time_setup:
            self.call_after_refresh(self._open_first_time_setup)
            return
        self._continue_after_startup_setup()

    def _continue_after_startup_setup(self) -> None:
        """Continue normal startup actions after any first-run setup screen."""
        if self.startup_resume_picker:
            self.call_after_refresh(self.action_open_session_picker)
            return
        if self.initial_prompt and self.initial_prompt.strip():
            self._submit_prompt(self.initial_prompt.strip())

    async def _warn_about_tmux_keyboard_setup(self) -> None:
        """Warn when tmux is likely to swallow Pi-style modified keys."""
        warning = await asyncio.to_thread(_tmux_keyboard_setup_warning, os.environ)
        if warning:
            self._notify(warning, severity="warning")

    def _open_first_time_setup(self) -> None:
        """Open the first-run setup screen."""
        self.push_screen(
            FirstTimeSetupScreen(
                self.tui_settings,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_first_time_setup_result,
        )

    def _handle_first_time_setup_result(self, settings: TuiSettings | None) -> None:
        if settings is None:
            self.show_first_time_setup = False
            self._continue_after_startup_setup()
            return
        self._set_tui_settings(settings)
        self.show_first_time_setup = False
        self._continue_after_startup_setup()

    def on_unmount(self) -> None:
        """Stop the activity timer when the app is torn down."""
        if self._activity_timer is not None:
            self._activity_timer.stop()
            self._activity_timer = None
        self._stop_extension_footer_branch_timer()
        self._clear_retry_countdown()
        if self._terminal_progress_active:
            self._terminal_progress_active = False
            self._write_terminal_progress(active=False)
        self._shutdown_dag_viewer_servers()
        self._terminal_title.restore()

    def on_app_blur(self) -> None:
        """Track when the TUI loses focus for turn-completion notifications."""
        self._app_has_focus = False

    def on_app_focus(self) -> None:
        """Track when the TUI has focus and should not request attention."""
        self._app_has_focus = True

    def on_resize(self, event: Resize) -> None:
        """Update responsive chrome when the terminal changes size."""
        self._update_responsive_layout(event.size.width, event.size.height)

    def on_click(self, event: events.Click) -> None:
        """Return keyboard focus to the prompt after clicks in the main TUI."""
        if event.button != 1:
            return
        with suppress(NoMatches):
            self.screen.query_one("#prompt", PromptInput).focus()

    @on(events.TextSelected)
    async def on_text_selected(self) -> None:
        """Optionally copy selected transcript text automatically."""
        if not self.tui_settings.auto_copy_selection:
            return
        selection = self.screen.get_selected_text()
        if selection:
            self.copy_to_clipboard(selection)
            self._notify("Copied selection to clipboard.")

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """Update prompt autocomplete when the prompt text changes."""
        if event.text_area.id != "prompt":
            return
        if isinstance(event.text_area, PromptInput):
            event.text_area.prune_paste_markers()
        if self._pty_proof_enabled and "TAU_TUI_PTY_BROWSER_INPUT" in event.text_area.text:
            with suppress(NoMatches):
                self.query_one("#pty-proof-ready", Static).update(
                    pty_input_received_line(self._pty_proof_run_id, event.text_area.text)
                )
        self._sync_prompt_shell_mode(event.text_area.text)
        cursor_position = (
            event.text_area.cursor_position
            if isinstance(event.text_area, PromptInput)
            else len(event.text_area.text)
        )
        self._set_prompt_completion_state(
            event.text_area.text,
            cursor_position=cursor_position,
        )

    async def action_submit_prompt(self) -> None:
        """Submit the current prompt text or slash command."""
        await self._submit_prompt_from_editor(streaming_behavior="steer")

    async def action_submit_follow_up(self) -> None:
        """Submit the current prompt as a queued follow-up while running."""
        await self._submit_prompt_from_editor(streaming_behavior="follow_up")

    async def _submit_prompt_from_editor(
        self,
        *,
        streaming_behavior: Literal["steer", "follow_up"],
    ) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        raw_text = prompt.text
        applied_completion = self._apply_selected_completion(raw_text)
        if applied_completion is not None and applied_completion != raw_text:
            prompt.text = applied_completion
            prompt.move_cursor(_text_end_location(applied_completion))
            self._set_prompt_completion_state(applied_completion)
            return

        expanded_text = prompt.expanded_text()
        text = expanded_text.strip()
        if not text:
            prompt.text = ""
            prompt.clear_paste_markers()
            self._completion_state = CompletionState()
            self._refresh_completions()
            return

        if self._is_compaction_active():
            if text.startswith("/compact"):
                self._notify("A compaction is already running.", severity="warning")
            elif _is_reload_command_text(text):
                self._notify("Wait for compaction to finish before reloading.", severity="warning")
            elif _is_session_switch_command_text(text):
                prompt.text = raw_text
                prompt.move_cursor(_text_end_location(raw_text))
                self._completion_state = CompletionState()
                self._refresh_completions()
                self._notify(
                    "Compaction is still running. You can keep editing, but wait to submit.",
                    severity="warning",
                )
            elif _is_extension_command_text(self.session, text):
                prompt.add_to_history(text)
                prompt.text = ""
                prompt.clear_paste_markers()
                self._completion_state = CompletionState()
                self._sync_prompt_shell_mode(prompt.text)
                self._refresh_completions()
                command = await self._handle_session_command(text, current_editor_text=raw_text)
                if command.message:
                    self._append_command_message(text, command.message)
                self._deliver_command_notifications(command)
                self._apply_command_status_updates(command)
                self._apply_command_widget_updates(command)
                self._apply_command_working_indicator_update(command)
                self._apply_command_footer_update(command)
                self._apply_command_header_update(command)
                if command.theme is not None:
                    self._set_tui_theme(command.theme)
                if command.show_tool_results is not None:
                    self._set_tool_results_expanded(command.show_tool_results)
                if command.hidden_thinking_label_requested:
                    self._set_hidden_thinking_label(command.hidden_thinking_label)
                if command.terminal_title_requested:
                    self._set_extension_terminal_title(command.terminal_title)
                if command.editor_text is not None:
                    self._set_prompt_editor_text(command.editor_text)
                elif command.editor_insert_text is not None:
                    self._insert_prompt_editor_text(command.editor_insert_text)
                elif command.editor_paste_text is not None:
                    self._paste_prompt_editor_text(command.editor_paste_text)
                if command.user_message is not None:
                    self._queue_compaction_message(
                        command.user_message,
                        streaming_behavior=command.user_message_delivery,
                    )
                    self._sync_queue_state()
                    self._notify("Queued extension message for after compaction.")
                if command.exit_requested:
                    self.exit()
                    return
                self._refresh()
            else:
                self._queue_compaction_message(text, streaming_behavior=streaming_behavior)
                prompt.add_to_history(text)
                prompt.text = ""
                prompt.clear_paste_markers()
                self._completion_state = CompletionState()
                self._sync_prompt_shell_mode(prompt.text)
                self._refresh_completions()
                self._sync_queue_state()
                self._refresh()
                self._notify("Queued message for after compaction.")
            return

        if self._is_terminal_command_active():
            prompt.text = raw_text
            prompt.move_cursor(_text_end_location(raw_text))
            self._notify(
                "A terminal command is already running. Press Escape to cancel it first.",
                severity="warning",
            )
            return

        if _is_skill_command_text(text) and not self.tui_settings.enable_skill_commands:
            prompt.text = raw_text
            prompt.move_cursor(_text_end_location(raw_text))
            self._completion_state = CompletionState()
            self._refresh_completions()
            self._notify("Skill commands are disabled in TUI settings.", severity="warning")
            return

        if _is_reload_command_text(text) and self._is_reload_active():
            self._notify("A reload is already running.", severity="warning")
            return

        if _is_reload_command_text(text) and self._is_agent_or_queue_active():
            self._notify(
                "Wait for the current response to finish before reloading.",
                severity="warning",
            )
            return

        prompt.add_to_history(text)
        prompt.text = ""
        prompt.clear_paste_markers()
        self._completion_state = CompletionState()
        self._refresh_completions()

        terminal_command = parse_terminal_command(text)
        if terminal_command is not None:
            self._terminal_worker = self.run_worker(
                self._run_terminal_command(
                    terminal_command.command,
                    add_to_context=terminal_command.add_to_context,
                ),
                group="terminal",
                exclusive=True,
            )
            return

        if self._handle_dag_viewer_command(text):
            return

        if self._handle_pending_decisions_command(text):
            return

        if text.casefold() == "/debug":
            debug_log_path = self._write_debug_log()
            self._append_command_message(text, f"Debug log written\n{debug_log_path}")
            self._refresh()
            return

        if _is_reload_command_text(text):
            self._reload_worker = self.run_worker(
                self._run_reload_command(text),
                exclusive=False,
            )
            return

        if text.casefold() == "/thinking" and tuple(
            getattr(self.session, "available_thinking_levels", ())
        ):
            self._open_thinking_picker()
            self._refresh()
            return

        command = _local_tui_command(
            text,
            self.tui_settings.keybindings,
            self.session,
            self.tui_settings,
        )
        if command is None:
            command = await self._handle_session_command(text, current_editor_text=raw_text)
        if command.handled:
            if command.clear_requested:
                self.state.clear()
            if command.new_session_requested:
                await self._new_session()
            if command.clone_session_requested:
                await self._clone_session()
            if command.compact_summary is not None:
                if self._is_compaction_active():
                    self._notify("A compaction is already running.", severity="warning")
                elif self._is_agent_or_queue_active():
                    prompt.text = raw_text
                    prompt.move_cursor(_text_end_location(raw_text))
                    self._notify(
                        (
                            "Wait for the current agent turn and queued messages "
                            "to finish before compacting."
                        ),
                        severity="warning",
                    )
                    return
                else:
                    self._compaction_worker = self.run_worker(
                        self._run_compaction(command.compact_summary),
                        exclusive=False,
                    )
            if command.copy_last_message_requested:
                self.action_copy_last_message()
            if command.artifacts_requested:
                self._open_artifact_browser()
            if command.export_requested:
                try:
                    exported_path = await self.session.export(
                        command.export_destination,
                        format=command.export_format,
                    )
                    self._notify(f"Exported session to {exported_path}")
                    if command.export_open_requested:
                        if _open_export_artifact(exported_path):
                            self._notify(f"Opened export: {exported_path}")
                        else:
                            self._notify(
                                f"Could not open export automatically: {exported_path}",
                                severity="warning",
                            )
                    self.push_screen(
                        CommandOutputScreen(
                            (
                                "Session export: open requested"
                                if command.export_open_requested
                                else "Session export"
                            ),
                            _export_result_message(
                                exported_path,
                                command.export_format,
                                open_requested=command.export_open_requested,
                            ),
                            theme=self.tui_settings.resolved_theme,
                            keybindings=self.tui_settings.keybindings,
                        )
                    )
                except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
                    self._notify(f"Could not export session: {exc}", severity="error")
            if command.import_requested and command.import_path is not None:
                await self._import_session(command.import_path)
            if command.share_requested:
                if self._is_share_active():
                    self._notify("A share is already running.", severity="warning")
                else:
                    self._share_worker = self.run_worker(
                        self._run_share_session(),
                        exclusive=False,
                    )
            if command.resume_session_id is not None:
                await self._resume_session(command.resume_session_id)
            if command.resume_picker_requested:
                self.action_open_session_picker()
            if command.tree_picker_requested:
                if self._is_agent_or_queue_active():
                    prompt.text = raw_text
                    prompt.move_cursor(_text_end_location(raw_text))
                    self._notify(TREE_RUNNING_MESSAGE, severity="warning")
                    return
                await self._open_tree_picker()
            if command.fork_picker_requested:
                if self._is_agent_or_queue_active():
                    prompt.text = raw_text
                    prompt.move_cursor(_text_end_location(raw_text))
                    self._notify(TREE_RUNNING_MESSAGE, severity="warning")
                    return
                await self._open_fork_picker()
            if command.login_picker_requested:
                self._open_login_picker(initial_search=command.login_picker_query or "")
            if command.login_provider is not None:
                self._open_login(command.login_provider)
            if command.logout_picker_requested:
                self._open_logout_picker()
            if command.logout_provider is not None:
                self._logout(command.logout_provider)
            if command.model_picker_requested:
                self._open_model_picker(initial_search=command.model_picker_query or "")
            if command.scoped_models_picker_requested:
                self._open_scoped_models_picker()
            if command.settings_picker_requested:
                self._open_settings_picker()
            if command.config_picker_requested:
                self._open_config_map()
            if command.images_picker_requested:
                self._open_image_visibility_picker()
            if command.trust_picker_requested:
                self._open_trust_picker()
            if command.theme_picker_requested:
                self._open_theme_picker()
            if command.prompts_picker_requested:
                self._open_prompt_template_picker()
            if command.workflow_picker_requested:
                self._open_workflow_picker()
            if command.tools_picker_requested:
                self._open_tools_reference()
            if command.skills_picker_requested:
                self._open_skill_picker()
            if command.thinking_level is not None:
                await self._set_thinking_level(command.thinking_level)
            if command.show_images is not None:
                self._set_show_images(command.show_images)
            if command.show_tool_results is not None:
                self._set_tool_results_expanded(command.show_tool_results)
            if command.hidden_thinking_label_requested:
                self._set_hidden_thinking_label(command.hidden_thinking_label)
            if command.theme is not None:
                self._set_tui_theme(command.theme)
            if _is_reload_command_text(text):
                self._reload_tui_settings()
            self.state.set_skills(self.session.skills)
            if command.message and not (
                command.workflow_picker_requested or command.config_picker_requested
            ):
                if _command_message_uses_notification(text, command.message):
                    self._notify(command.message)
                elif _command_message_uses_transcript(text):
                    self._append_command_message(text, command.message)
                else:
                    self._show_command_message(text, command.message)
            self._deliver_command_notifications(command)
            self._apply_command_status_updates(command)
            self._apply_command_widget_updates(command)
            self._apply_command_working_indicator_update(command)
            self._apply_command_footer_update(command)
            self._apply_command_header_update(command)
            if command.terminal_title_requested:
                self._set_extension_terminal_title(command.terminal_title)
            if command.editor_text is not None:
                self._set_prompt_editor_text(command.editor_text)
                self._refresh()
                return
            if command.editor_insert_text is not None:
                self._insert_prompt_editor_text(command.editor_insert_text)
                self._refresh()
                return
            if command.editor_paste_text is not None:
                self._paste_prompt_editor_text(command.editor_paste_text)
                self._refresh()
                return
            if command.user_message is not None:
                await self._deliver_command_user_message(command)
                self._refresh()
                return
            self._refresh()
            if command.exit_requested:
                self.exit()
            return

        if self.state.running:
            await self._queue_prompt(text, streaming_behavior=streaming_behavior)
            return

        self._submit_prompt(text)

    def _is_compaction_active(self) -> bool:
        """Return whether a manual compaction worker is still running."""
        worker = self._compaction_worker
        return worker is not None and not worker.is_finished and not worker.is_cancelled

    def _is_branch_active(self) -> bool:
        """Return whether a branch/fork worker is still running."""
        worker = self._branch_worker
        return worker is not None and not worker.is_finished and not worker.is_cancelled

    def _is_terminal_command_active(self) -> bool:
        """Return whether an input-bar terminal command is still running."""
        worker = self._terminal_worker
        return worker is not None and not worker.is_finished and not worker.is_cancelled

    def _is_reload_active(self) -> bool:
        """Return whether a TUI resource reload worker is still running."""
        worker = self._reload_worker
        return worker is not None and not worker.is_finished and not worker.is_cancelled

    def _is_share_active(self) -> bool:
        """Return whether a TUI share worker is still running."""
        worker = self._share_worker
        return worker is not None and not worker.is_finished and not worker.is_cancelled

    def _is_tui_activity_active(self) -> bool:
        """Return whether any visible TUI operation should show active progress."""
        return (
            self.state.running
            or self._is_compaction_active()
            or self._is_branch_active()
            or self._is_terminal_command_active()
            or self._is_reload_active()
            or self._is_share_active()
        )

    def _is_agent_or_queue_active(self, *, include_branch: bool = True) -> bool:
        """Return whether compaction would race an active or queued agent turn."""
        self._sync_queue_state()
        worker = self._prompt_worker
        is_worker_active = worker is not None and not worker.is_finished and not worker.is_cancelled
        is_session_running = bool(getattr(self.session, "is_running", False))
        return (
            self.state.running
            or is_session_running
            or is_worker_active
            or self._is_compaction_active()
            or (include_branch and self._is_branch_active())
            or self._is_reload_active()
            or self.state.queued_message_count > 0
        )

    def _queue_compaction_message(
        self,
        text: str,
        *,
        streaming_behavior: Literal["steer", "follow_up"],
    ) -> None:
        """Queue prompt text while a manual compaction is running."""
        self._compaction_queued_messages.append((text, streaming_behavior))

    async def _run_compaction(self, summary: str) -> None:
        """Run manual compaction without disabling prompt editing."""
        self.state.clear()
        self.state.add_item("status", "Compacting session... (Escape to cancel)")
        self._refresh()
        queued_after_compaction: list[tuple[str, Literal["steer", "follow_up"]]] = []
        try:
            compact_message = await self.session.compact(summary)
        except asyncio.CancelledError:
            self._restore_compaction_queue_to_prompt()
            return
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._restore_compaction_queue_to_prompt()
            self._notify(f"Error: {exc}", severity="error")
            return
        finally:
            self._compaction_worker = None
        if self._compaction_queued_messages:
            queued_after_compaction = list(self._compaction_queued_messages)
            self._compaction_queued_messages.clear()
        self.state.clear()
        self.state.set_skills(self.session.skills)
        self._load_session_transcript()
        self._notify(compact_message)
        self._refresh()
        if queued_after_compaction:
            first_text, _first_mode = queued_after_compaction[0]
            self._submit_prompt(first_text, queued_after_start=queued_after_compaction[1:])

    def _restore_compaction_queue_to_prompt(self) -> int:
        """Move compaction-queued text back into the prompt if compaction does not finish."""
        if not self._compaction_queued_messages:
            return 0
        messages = [text for text, _mode in self._compaction_queued_messages]
        self._compaction_queued_messages.clear()
        try:
            prompt = self.query_one("#prompt", PromptInput)
        except NoMatches:
            return len(messages)
        combined_text = "\n\n".join(
            part for part in (*messages, prompt.expanded_text()) if part.strip()
        )
        prompt.text = combined_text
        prompt.move_cursor(_text_end_location(combined_text))
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._set_prompt_completion_state(prompt.text)
        self._sync_queue_state()
        self._refresh()
        return len(messages)

    async def _run_reload_command(self, text: str) -> None:
        """Reload session resources and TUI settings without freezing the interface."""
        self._reset_extension_ui_state()
        self.state.add_item("status", "Reloading local coding resources and project context...")
        self._sync_activity_indicator()
        self._refresh()
        try:
            command = await asyncio.to_thread(self.session.handle_command, text)
        except asyncio.CancelledError:
            self.state.items = [
                item
                for item in self.state.items
                if item.text != "Reloading local coding resources and project context..."
            ]
            self._sync_activity_indicator()
            self._refresh()
            self._notify("Reload cancelled.", severity="warning")
            return
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            command = CommandResult(handled=True, message=f"Could not reload: {exc}")
        finally:
            self._reload_worker = None

        if not command.handled:
            command = CommandResult(handled=True, message="Usage: /reload")
        if command.message:
            self.state.items = [
                item
                for item in self.state.items
                if item.text != "Reloading local coding resources and project context..."
            ]
            self._append_command_message(text, command.message)
        self._reload_tui_settings()
        self.state.set_skills(self.session.skills)
        self._sync_activity_indicator()
        self._refresh()

    def _submit_prompt(
        self,
        text: str,
        *,
        queued_after_start: Sequence[tuple[str, Literal["steer", "follow_up"]]] = (),
    ) -> None:
        """Add a prompt to the transcript and start the agent worker."""
        self._prompt_run_id += 1
        run_id = self._prompt_run_id
        self._follow_transcript_output()
        self._refresh()
        self._prompt_worker = self.run_worker(
            self._run_prompt(text, run_id, queued_after_start=queued_after_start),
            exclusive=True,
        )

    def _follow_transcript_output(self) -> None:
        """Put the transcript back in follow mode for explicit user actions."""
        if not self.screen_stack:
            return
        with suppress(NoMatches):
            self.query_one("#transcript", TranscriptView).follow_output()

    async def _run_terminal_command(self, command: str, *, add_to_context: bool) -> None:
        run_terminal_command = getattr(self.session, "run_terminal_command", None)
        if not callable(run_terminal_command):
            self._notify("Terminal commands are not available.", severity="error")
            self._terminal_worker = None
            return

        defer_display = self.state.running
        item = ChatItem(
            role="tool",
            text=f"$ {command.strip()}",
            tool_result_text=format_terminal_command_running_block(added_to_context=add_to_context),
            always_show_tool_result=True,
        )
        if defer_display:
            self.state.pending_terminal_commands.append(item)
        else:
            self.state.items.append(item)
        item_index = len(self.state.items) - 1 if not defer_display else None
        self._follow_transcript_output()
        self._refresh()
        streamed_output_parts: list[str] = []

        def update_terminal_output(delta: str) -> None:
            streamed_output_parts.append(delta)
            if item_index is not None and item_index >= len(self.state.items):
                return
            item.tool_result_text = format_terminal_command_running_block(
                added_to_context=add_to_context,
                output="".join(streamed_output_parts),
            )
            self._refresh()

        try:
            try:
                result = await run_terminal_command(
                    command,
                    add_to_context=add_to_context,
                    on_output_chunk=update_terminal_output,
                )
            except TypeError as exc:
                if "on_output_chunk" not in str(exc):
                    raise
                result = await run_terminal_command(command, add_to_context=add_to_context)
        except asyncio.CancelledError:
            if item_index is None or item_index < len(self.state.items):
                item.text = _terminal_command_transcript_title(command)
                item.always_show_tool_result = False
                item.tool_result_text = format_terminal_command_result_block(
                    ok=False,
                    added_to_context=add_to_context,
                    output="cancelled",
                )
            self._terminal_worker = None
            self._refresh()
            return
        except Exception as exc:  # noqa: BLE001 - surface command execution failures in the TUI
            if item_index is None or item_index < len(self.state.items):
                item.text = _terminal_command_transcript_title(command)
                item.always_show_tool_result = False
                item.tool_result_text = format_terminal_command_result_block(
                    ok=False,
                    added_to_context=add_to_context,
                    output=str(exc),
                )
            self._notify(f"Could not run command: {exc}", severity="error")
            self._refresh()
            self._terminal_worker = None
            return

        if item_index is not None and item_index >= len(self.state.items):
            self._terminal_worker = None
            return
        item.text = _terminal_command_transcript_title(result.command)
        item.always_show_tool_result = False
        formatted_output = _format_workflow_terminal_output(result.output) or result.output
        remembered_run_dir = _workflow_terminal_run_dir(result.output)
        if remembered_run_dir is not None:
            self._last_dag_viewer_run_dir = remembered_run_dir
        item.tool_result_text = format_terminal_command_result_block(
            ok=result.ok,
            added_to_context=result.added_to_context,
            output=formatted_output,
            exit_code=result.exit_code,
        )
        self._refresh_pending_decisions(notify=True)
        self._follow_transcript_output()
        self._refresh()
        self._terminal_worker = None

    def _set_tui_theme(self, theme: str) -> None:
        self._set_tui_settings(replace(self.tui_settings, theme=theme))

    def _set_show_images(self, show_images: bool) -> None:
        self._set_tui_settings(replace(self.tui_settings, show_images=show_images))
        self._notify(f"Show images: {'on' if show_images else 'off'}")

    def _set_tool_results_expanded(self, expanded: bool) -> None:
        self.state.show_tool_results = expanded
        self.state.rerender_custom_entries()
        self._refresh()

    def _set_hidden_thinking_label(self, label: str | None) -> None:
        self.state.hidden_thinking_label = label
        self._refresh()

    def _preview_tui_theme(self, theme: str) -> None:
        self._set_tui_settings(replace(self.tui_settings, theme=theme), persist=False)

    def _reload_tui_settings(self) -> None:
        try:
            self._set_tui_settings(load_tui_settings())
        except Exception as exc:  # noqa: BLE001 - preserve session reload output and surface TUI failure
            self._notify(f"Could not reload TUI settings: {exc}", severity="error")

    def _set_tui_settings(self, settings: TuiSettings, *, persist: bool = True) -> None:
        previous_settings = self.tui_settings
        self.tui_settings = settings
        self.state.show_thinking = not settings.hide_thinking
        self._sync_terminal_progress_indicator()
        set_auto_compact = getattr(self.session, "set_auto_compact_enabled", None)
        if callable(set_auto_compact):
            set_auto_compact(settings.auto_compact)
        set_shell_path = getattr(self.session, "set_shell_path", None)
        if callable(set_shell_path):
            set_shell_path(settings.shell_path)
        set_shell_command_prefix = getattr(self.session, "set_shell_command_prefix", None)
        if callable(set_shell_command_prefix):
            set_shell_command_prefix(settings.shell_command_prefix)
        set_auto_resize_images = getattr(self.session, "set_auto_resize_images", None)
        if callable(set_auto_resize_images):
            set_auto_resize_images(settings.auto_resize_images)
        set_disabled_resource_paths = getattr(self.session, "set_disabled_resource_paths", None)
        if callable(set_disabled_resource_paths):
            set_disabled_resource_paths(
                _effective_disabled_resource_paths(settings, self.project_tui_settings)
            )
        self._terminal_notification.mode = settings.turn_notification
        set_steering_mode = getattr(self.session, "set_steering_queue_mode", None)
        if callable(set_steering_mode):
            set_steering_mode(_agent_queue_mode_from_tui(settings.steering_mode))
        set_follow_up_mode = getattr(self.session, "set_follow_up_queue_mode", None)
        if callable(set_follow_up_mode):
            set_follow_up_mode(_agent_queue_mode_from_tui(settings.follow_up_mode))
        set_provider_timeout = getattr(self.session, "set_provider_timeout_seconds", None)
        if callable(set_provider_timeout):
            set_provider_timeout(
                _provider_timeout_seconds_from_http_idle_timeout_ms(
                    settings.http_idle_timeout_ms
                )
            )
        set_default_project_trust = getattr(self.session, "set_default_project_trust", None)
        if callable(set_default_project_trust):
            set_default_project_trust(settings.default_project_trust)
        if settings.thinking_level != previous_settings.thinking_level:
            self.run_worker(
                self._set_thinking_level(settings.thinking_level),
                exclusive=False,
            )
        if persist:
            save_tui_settings(self.tui_settings)
        self._apply_sidebar_position()
        self._bindings = BindingsMap(_app_bindings(self.tui_settings.keybindings))
        with suppress(NoMatches):
            prompt = self.query_one("#prompt", PromptInput)
            prompt.tui_keybindings = self.tui_settings.keybindings
            prompt.show_cursor = self.tui_settings.show_hardware_cursor
            prompt.shell_mode_style = self.tui_settings.resolved_theme.role_styles["tool"].border
            _apply_prompt_padding(prompt, self.tui_settings.editor_padding_x)
            prompt._apply_prompt_bindings()
            prompt.refresh_bindings()
        self.refresh_bindings()
        self.refresh_css(animate=False)
        self._refresh()

    def _settings_picker_settings_changed(self, settings: TuiSettings) -> None:
        self._set_tui_settings(settings)

    def _open_settings_picker(self) -> None:
        self.push_screen(
            SettingsPickerScreen(
                self.tui_settings,
                apply_settings=self._settings_picker_settings_changed,
                thinking_levels=tuple(getattr(self.session, "available_thinking_levels", ()))
                or THINKING_LEVELS,
                keybindings=self.tui_settings.keybindings,
            )
        )

    def _open_config_map(self) -> None:
        """Open a searchable map of Tau config files and resource commands."""
        self.push_screen(
            ConfigMapScreen(
                _config_map_items(
                    self.session,
                    self.tui_settings,
                    project_settings=self.project_tui_settings,
                ),
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
                on_toggle_resource=self._handle_config_map_toggle_resource,
                write_target_label=_config_map_write_target_label(self.session.cwd),
            ),
            callback=self._handle_config_map_result,
        )

    def _open_artifact_browser(self) -> None:
        """Open a browser for artifacts found in the current transcript."""
        self.push_screen(
            ArtifactBrowserScreen(
                _visual_artifacts_from_state(
                    self.state,
                    cwd=self.session.cwd,
                    session_id=getattr(self.session, "session_id", None),
                ),
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
                show_images=self.tui_settings.show_images,
                image_width_cells=self.tui_settings.image_width_cells,
            ),
            callback=self._handle_artifact_browser_result,
        )

    def _handle_artifact_browser_result(self, result: ArtifactBrowserResult | None) -> None:
        if result is None:
            return
        path = result.artifact.path
        if result.action == "copy":
            self.copy_to_clipboard(str(path))
            self._notify(f"Copied artifact path: {path}")
            return
        if _open_export_artifact(path):
            self._notify(f"Opened artifact: {path}")
        else:
            self._notify(f"Could not open artifact automatically: {path}", severity="warning")

    def _handle_config_map_result(self, result: ConfigMapResult | None) -> None:
        if result is None:
            return
        if result.action == "insert_command":
            prompt = self.query_one("#prompt", PromptInput)
            prompt.text = result.value
            prompt.move_cursor(_text_end_location(result.value))
            prompt.focus()
            self._sync_prompt_shell_mode(prompt.text)
            self._set_prompt_completion_state(prompt.text)
            self._refresh()
            return
        if result.action == "copy_path":
            self.copy_to_clipboard(result.value)
            self._notify(f"Copied path: {result.value}")
            return
        if result.action == "toggle_resource":
            self._handle_config_map_toggle_resource(result.value)

    def _handle_config_map_toggle_resource(self, value: str) -> tuple[ConfigMapItem, ...]:
        """Toggle a resource and return refreshed config-map rows for an open modal."""
        message = self._toggle_disabled_resource_path(Path(value))
        self._notify(message)
        if self._reload_worker is None:
            self._reload_worker = self.run_worker(
                self._run_reload_command("/reload"),
                exclusive=False,
            )
        else:
            self._notify("Resource setting saved; current reload is still running.")
        return _config_map_items(
            self.session,
            self.tui_settings,
            project_settings=self.project_tui_settings,
        )

    def _toggle_disabled_resource_path(self, path: Path) -> str:
        """Toggle one disabled resource path in durable TUI settings."""
        target = _normalized_config_resource_path(path)
        scope = _config_map_scope_for_path(target, cwd=self.session.cwd)
        user_current = tuple(Path(item) for item in self.tui_settings.disabled_resource_paths)
        project_current = tuple(
            Path(item) for item in self.project_tui_settings.disabled_resource_paths
        )
        user_disabled = {_normalized_config_resource_path(item): item for item in user_current}
        project_disabled = {
            _normalized_config_resource_path(item): item for item in project_current
        }
        if target in user_disabled or target in project_disabled:
            if target in project_disabled:
                project_remaining = tuple(
                    str(item)
                    for normalized, item in project_disabled.items()
                    if normalized != target
                )
                self._set_project_tui_settings(
                    replace(
                        self.project_tui_settings,
                        disabled_resource_paths=project_remaining,
                    )
                )
            if target in user_disabled:
                user_remaining = tuple(
                    str(item)
                    for normalized, item in user_disabled.items()
                    if normalized != target
                )
                self._set_tui_settings(
                    replace(self.tui_settings, disabled_resource_paths=user_remaining)
                )
            return f"Enabled {scope} resource: {target}"
        if scope == "project":
            updated = (*self.project_tui_settings.disabled_resource_paths, str(target))
            self._set_project_tui_settings(
                replace(self.project_tui_settings, disabled_resource_paths=updated)
            )
        else:
            updated = (*self.tui_settings.disabled_resource_paths, str(target))
            self._set_tui_settings(replace(self.tui_settings, disabled_resource_paths=updated))
        return f"Disabled {scope} resource: {target}"

    def _set_project_tui_settings(self, settings: ProjectTuiSettings) -> None:
        """Persist project-local TUI settings and apply effective disabled paths."""
        self.project_tui_settings = settings
        save_project_tui_settings(settings, self.session.cwd)
        set_disabled_resource_paths = getattr(self.session, "set_disabled_resource_paths", None)
        if callable(set_disabled_resource_paths):
            set_disabled_resource_paths(
                _effective_disabled_resource_paths(self.tui_settings, settings)
            )

    def _open_thinking_picker(self) -> None:
        levels = tuple(getattr(self.session, "available_thinking_levels", ()))
        if not levels:
            self._notify("Thinking controls are not available.", severity="warning")
            return
        self.push_screen(
            ThinkingPickerScreen(
                str(getattr(self.session, "thinking_level", DEFAULT_THINKING_LEVEL)),
                cast(tuple[ThinkingLevel, ...], levels),
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_thinking_picker_result,
        )

    def _handle_thinking_picker_result(self, level: str | None) -> None:
        if level is None:
            return
        self.run_worker(self._set_thinking_level(level), exclusive=False)

    def _open_image_visibility_picker(self) -> None:
        self.push_screen(
            ImageVisibilityPickerScreen(
                self.tui_settings.show_images,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_image_visibility_picker_result,
        )

    def _handle_image_visibility_picker_result(self, show_images: bool | None) -> None:
        if show_images is None:
            return
        self._set_show_images(show_images)

    def _open_trust_picker(self) -> None:
        project_trust_state = getattr(self.session, "project_trust_state", None)
        if project_trust_state is None:
            self._notify("Project trust is not available.", severity="warning")
            return
        try:
            state = project_trust_state()
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
            return
        self.push_screen(
            TrustPickerScreen(state, keybindings=self.tui_settings.keybindings),
            callback=self._handle_trust_picker_result,
        )

    def _handle_trust_picker_result(self, option: ProjectTrustOption | None) -> None:
        if option is None:
            return
        save_project_trust = getattr(self.session, "save_project_trust", None)
        if save_project_trust is None:
            self._notify("Project trust is not available.", severity="warning")
            return
        try:
            result = save_project_trust(option)
            if isawaitable(result):
                self.run_worker(self._notify_awaited_trust_result(result), exclusive=False)
                return
            self._notify(str(result))
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")

    async def _notify_awaited_trust_result(self, result: object) -> None:
        try:
            message = await result
            self._notify(str(message))
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")

    async def _queue_prompt(
        self,
        text: str,
        *,
        streaming_behavior: Literal["steer", "follow_up"],
    ) -> None:
        """Queue a prompt for the active agent worker."""
        try:
            async for event in self.session.prompt(text, streaming_behavior=streaming_behavior):
                self.adapter.apply(event)
        except Exception as exc:  # noqa: BLE001 - surface queueing failures in the TUI
            self._notify(f"Could not queue message: {exc}", severity="error")
            return
        self._refresh()

    async def _deliver_command_user_message(self, command: CommandResult) -> None:
        """Deliver a user message requested by a slash-command handler."""
        if command.user_message is None:
            return
        if self.state.running:
            await self._queue_prompt(
                command.user_message,
                streaming_behavior=command.user_message_delivery,
            )
            return
        self._submit_prompt(command.user_message)

    def _deliver_command_notifications(self, command: CommandResult) -> None:
        """Show notifications requested by a slash-command handler."""
        for notification in command.notifications:
            self._notify(notification.message, severity=notification.severity)

    def _apply_command_status_updates(self, command: CommandResult) -> None:
        """Apply persistent status updates requested by a slash-command handler."""
        changed = False
        for update in command.status_updates:
            if update.text is None:
                if update.key in self._extension_statuses:
                    self._extension_statuses.pop(update.key, None)
                    changed = True
            else:
                if self._extension_statuses.get(update.key) != update.text:
                    self._extension_statuses[update.key] = update.text
                    changed = True
        if changed:
            self._refresh_extension_footer_component_for_statuses()

    def _refresh_extension_footer_component_for_statuses(self) -> None:
        """Rebuild a footer component that reads status data from its provider."""
        if self._extension_footer_component_factory is None:
            return
        self._clear_extension_footer_branch_listeners()
        self._apply_extension_chrome_component("footer")

    def _apply_command_widget_updates(self, command: CommandResult) -> None:
        """Apply prompt-region widget updates requested by a slash-command handler."""
        for update in command.widget_updates:
            target = (
                self._extension_widgets_below
                if update.placement == "below_editor"
                else self._extension_widgets_above
            )
            other = (
                self._extension_widgets_above
                if update.placement == "below_editor"
                else self._extension_widgets_below
            )
            self._clear_extension_widget_component(update.key)
            if update.lines is None:
                target.pop(update.key, None)
                other.pop(update.key, None)
            else:
                other.pop(update.key, None)
                target[update.key] = update.lines
        if command.widget_updates:
            self._apply_extension_widget_components("above_editor")
            self._apply_extension_widget_components("below_editor")

    def _apply_command_working_indicator_update(self, command: CommandResult) -> None:
        """Apply extension-requested custom activity indicator state."""
        update = command.working_indicator_update
        if update is None:
            return
        if update.visible is not None:
            self._extension_working_visible = update.visible
        if update.message_requested:
            self._extension_working_message = update.message
        if update.indicator_requested:
            self._extension_working_indicator_frames = update.frames
            self._extension_working_indicator_interval_seconds = (
                update.interval_ms / 1000 if update.interval_ms is not None else None
            )
        self._sync_activity_indicator()

    def _apply_command_footer_update(self, command: CommandResult) -> None:
        """Apply extension-requested static footer replacement."""
        update = command.footer_update
        if update is None:
            return
        self._extension_footer_component_factory = None
        self._extension_footer_component_name = None
        self._clear_extension_chrome_component("footer")
        self._extension_footer_lines = update.lines
        self._refresh_footer_bindings()

    def _apply_command_header_update(self, command: CommandResult) -> None:
        """Apply extension-requested static header replacement."""
        update = command.header_update
        if update is None:
            return
        self._extension_header_component_factory = None
        self._extension_header_component_name = None
        self._clear_extension_chrome_component("header")
        self._extension_header_lines = update.lines
        self._refresh_chrome()

    def _register_extension_terminal_input_listener(
        self,
        *,
        extension_name: str,
        handler: Callable[[str], object],
    ) -> Callable[[], None]:
        """Register an extension listener for prompt terminal input."""
        self._extension_terminal_input_listener_id += 1
        listener_id = self._extension_terminal_input_listener_id
        self._extension_terminal_input_listeners[listener_id] = (extension_name, handler)

        def unsubscribe() -> None:
            self._extension_terminal_input_listeners.pop(listener_id, None)

        return unsubscribe

    def action_handle_extension_terminal_input(self, data: str) -> str | None:
        """Let extension listeners consume or rewrite prompt terminal input."""
        for extension_name, handler in tuple(self._extension_terminal_input_listeners.values()):
            try:
                result = handler(data)
            except Exception as exc:  # noqa: BLE001 - extension failures should surface, not crash
                self._notify(
                    f"Extension terminal input listener error ({extension_name}): {exc}",
                    severity="error",
                )
                continue
            replacement = _extension_terminal_input_result(result)
            if replacement is not None:
                return replacement
        return None

    def _handle_extension_widget_component(
        self,
        *,
        key: str,
        extension_name: str,
        factory: Callable[..., object] | None,
        placement: str,
    ) -> object:
        """Set or clear an extension-provided prompt-region widget component."""
        placement_key: Literal["above_editor", "below_editor"] = (
            "below_editor" if placement == "below_editor" else "above_editor"
        )
        target = (
            self._extension_widget_components_below
            if placement_key == "below_editor"
            else self._extension_widget_components_above
        )
        target_names = (
            self._extension_widget_component_names_below
            if placement_key == "below_editor"
            else self._extension_widget_component_names_above
        )
        other = (
            self._extension_widget_components_above
            if placement_key == "below_editor"
            else self._extension_widget_components_below
        )
        other_names = (
            self._extension_widget_component_names_above
            if placement_key == "below_editor"
            else self._extension_widget_component_names_below
        )
        other.pop(key, None)
        other_names.pop(key, None)
        if factory is None:
            target.pop(key, None)
            target_names.pop(key, None)
        else:
            target[key] = factory
            target_names[key] = extension_name
            self._extension_widgets_above.pop(key, None)
            self._extension_widgets_below.pop(key, None)
        self._apply_extension_widget_components("above_editor")
        self._apply_extension_widget_components("below_editor")
        return factory

    def _apply_extension_widget_components(
        self,
        placement: Literal["above_editor", "below_editor"],
    ) -> None:
        suffix = "below" if placement == "below_editor" else "above"
        self.run_worker(
            partial(self._mount_extension_widget_components, placement),
            group=f"extension-widget-components-{suffix}",
            exclusive=True,
        )

    async def _mount_extension_widget_components(
        self,
        placement: Literal["above_editor", "below_editor"],
    ) -> None:
        suffix = "below" if placement == "below_editor" else "above"
        factories = (
            self._extension_widget_components_below
            if placement == "below_editor"
            else self._extension_widget_components_above
        )
        names = (
            self._extension_widget_component_names_below
            if placement == "below_editor"
            else self._extension_widget_component_names_above
        )
        container = self.query_one(f"#extension-widget-components-{suffix}", Vertical)
        _dispose_extension_component_children(container)
        await container.remove_children()
        for key, factory in factories.items():
            try:
                content = self._build_extension_widget_component(factory)
                if isawaitable(content):
                    content = await content
            except Exception as exc:  # noqa: BLE001 - extension UI failures should be visible
                name = names.get(key)
                content = f"Extension widget component error ({name}:{key}): {exc}"
            await container.mount(_extension_component_widget(content))
        container.display = bool(factories)

    def _build_extension_widget_component(self, factory: Callable[..., object]) -> object:
        try:
            return factory(self, self.tui_settings.resolved_theme)
        except TypeError:
            return factory()

    def _clear_extension_widget_component(self, key: str) -> None:
        self._extension_widget_components_above.pop(key, None)
        self._extension_widget_component_names_above.pop(key, None)
        self._extension_widget_components_below.pop(key, None)
        self._extension_widget_component_names_below.pop(key, None)

    def _clear_extension_widget_component_container(
        self,
        placement: Literal["above_editor", "below_editor"],
    ) -> None:
        suffix = "below" if placement == "below_editor" else "above"
        with suppress(NoMatches):
            container = self.query_one(f"#extension-widget-components-{suffix}", Vertical)
            _dispose_extension_component_children(container)
            container.remove_children()
            container.display = False

    def _handle_extension_chrome_component(
        self,
        *,
        target: str,
        extension_name: str,
        factory: Callable[..., object] | None,
    ) -> object:
        """Set or clear an extension-provided header/footer component."""
        if target == "footer":
            self._extension_footer_component_factory = factory
            self._extension_footer_component_name = extension_name if factory is not None else None
            if factory is not None:
                self._extension_footer_lines = None
            self._apply_extension_chrome_component("footer")
            return factory
        if target == "header":
            self._extension_header_component_factory = factory
            self._extension_header_component_name = extension_name if factory is not None else None
            if factory is not None:
                self._extension_header_lines = None
            self._apply_extension_chrome_component("header")
            return factory
        raise ValueError(f"Unsupported extension chrome component target: {target}")

    def _apply_extension_chrome_component(self, target: Literal["footer", "header"]) -> None:
        factory = (
            self._extension_footer_component_factory
            if target == "footer"
            else self._extension_header_component_factory
        )
        if factory is None:
            self._clear_extension_chrome_component(target)
            if target == "footer":
                self._refresh_footer_bindings()
            else:
                self._refresh_chrome()
            return
        self.run_worker(
            self._mount_extension_chrome_component(target, factory),
            exclusive=False,
        )

    async def _mount_extension_chrome_component(
        self,
        target: Literal["footer", "header"],
        factory: Callable[..., object],
    ) -> None:
        try:
            content = self._build_extension_chrome_component(target, factory)
            if isawaitable(content):
                content = await content
        except Exception as exc:  # noqa: BLE001 - extension UI failures should be visible
            name = (
                self._extension_footer_component_name
                if target == "footer"
                else self._extension_header_component_name
            )
            content = f"Extension {target} component error ({name}): {exc}"
        container = self.query_one(f"#extension-{target}-component", Vertical)
        _dispose_extension_component_children(container)
        await container.remove_children()
        await container.mount(_extension_component_widget(content))
        container.display = True
        if target == "footer":
            self._refresh_footer_bindings()
        else:
            self._refresh_chrome()

    def _build_extension_chrome_component(
        self,
        target: Literal["footer", "header"],
        factory: Callable[..., object],
    ) -> object:
        if target == "footer":
            footer_data = _TauFooterDataProvider(self)
            try:
                return factory(self, self.tui_settings.resolved_theme, footer_data)
            except TypeError:
                return factory(self, self.tui_settings.resolved_theme)
        try:
            return factory(self, self.tui_settings.resolved_theme)
        except TypeError:
            return factory()

    def _clear_extension_chrome_component(self, target: Literal["footer", "header"]) -> None:
        with suppress(NoMatches):
            container = self.query_one(f"#extension-{target}-component", Vertical)
            _dispose_extension_component_children(container)
            container.remove_children()
            container.display = False

    def _register_extension_autocomplete_provider(
        self,
        *,
        extension_name: str,
        factory: Callable[[object], object],
    ) -> Callable[[], None]:
        """Register an extension autocomplete provider factory."""
        self._extension_autocomplete_provider_id += 1
        provider_id = self._extension_autocomplete_provider_id
        self._extension_autocomplete_providers[provider_id] = (extension_name, factory)
        self._refresh_current_prompt_completions()

        def unsubscribe() -> None:
            self._extension_autocomplete_providers.pop(provider_id, None)
            self._refresh_current_prompt_completions()

        return unsubscribe

    def _handle_extension_editor_component(
        self,
        *,
        action: str,
        extension_name: str | None = None,
        factory: Callable[..., object] | None = None,
    ) -> object:
        """Set, clear, or return the active PromptInput-compatible editor factory."""
        if action == "get":
            return self._extension_editor_component_factory
        if action != "set":
            raise ValueError(f"Unsupported editor component action: {action}")
        self._extension_editor_component_factory = factory
        self._extension_editor_component_name = extension_name if factory is not None else None
        self._apply_extension_editor_component()
        return factory

    def _apply_extension_editor_component(self) -> None:
        with suppress(NoMatches):
            current = self.query_one("#prompt", PromptInput)
            replacement = self._build_extension_prompt_input(current)
            if replacement is None:
                return
            parent = current.parent
            if parent is None:
                return
            try:
                index = list(parent.children).index(current)
            except ValueError:
                index = None
            self.run_worker(
                self._swap_prompt_input(parent, current, replacement, index=index),
                exclusive=False,
            )

    async def _swap_prompt_input(
        self,
        parent: Widget,
        current: PromptInput,
        replacement: PromptInput,
        *,
        index: int | None,
    ) -> None:
        await current.remove()
        if index is None:
            await parent.mount(replacement)
        else:
            await parent.mount(replacement, before=index)
        replacement.focus()
        self._sync_prompt_shell_mode(replacement.text)
        self._set_prompt_completion_state(
            replacement.text,
            cursor_position=replacement.cursor_position,
        )

    def _build_extension_prompt_input(self, current: PromptInput) -> PromptInput | None:
        text = current.text
        cursor_position = current.cursor_position
        factory = self._extension_editor_component_factory
        if factory is None:
            replacement = PromptInput(
                id="prompt",
                tui_keybindings=self.tui_settings.keybindings,
            )
        else:
            try:
                result = factory(
                    self,
                    self.tui_settings.resolved_theme,
                    self.tui_settings.keybindings,
                )
            except TypeError:
                result = factory()
            if not isinstance(result, PromptInput):
                self._notify(
                    (
                        "Extension editor component ignored "
                        f"({self._extension_editor_component_name}): "
                        "factory must return PromptInput"
                    ),
                    severity="error",
                )
                return None
            replacement = result
            replacement.id = "prompt"
            replacement.tui_keybindings = self.tui_settings.keybindings
            replacement._apply_prompt_bindings()
        replacement.text = text
        replacement.shell_mode_style = self.tui_settings.resolved_theme.role_styles["tool"].border
        _apply_prompt_padding(replacement, self.tui_settings.editor_padding_x)
        replacement.cursor_position = cursor_position
        return replacement

    def _set_extension_terminal_title(self, title: str | None) -> None:
        """Override or clear the terminal title requested by an extension command."""
        self._extension_terminal_title = title.strip() if title is not None else None
        if self._extension_terminal_title == "":
            self._extension_terminal_title = None
        self._sync_terminal_title()

    def _set_prompt_editor_text(self, text: str) -> None:
        """Replace the prompt editor contents with text from a command handler."""
        prompt = self.query_one("#prompt", PromptInput)
        prompt.text = text
        prompt.clear_paste_markers()
        prompt.move_cursor(_text_end_location(text))
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._set_prompt_completion_state(prompt.text)

    def _insert_prompt_editor_text(self, text: str) -> None:
        """Insert command-provided text at the current prompt cursor."""
        prompt = self.query_one("#prompt", PromptInput)
        prompt.insert(text)
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._set_prompt_completion_state(prompt.text)

    def _paste_prompt_editor_text(self, text: str) -> None:
        """Paste command-provided text using the prompt's large-paste handling."""
        self._insert_prompt_text(text, compact_large_paste=True)

    async def _handle_session_command(
        self,
        text: str,
        *,
        current_editor_text: str,
    ) -> CommandResult:
        """Run a session command, awaiting async extension command handlers when available."""
        handle_command_async = getattr(self.session, "handle_command_async", None)
        if callable(handle_command_async):
            parameters = signature(handle_command_async).parameters
            kwargs: dict[str, object] = {}
            if "current_editor_text" in parameters:
                kwargs["current_editor_text"] = current_editor_text
            if "show_tool_results" in parameters:
                kwargs["show_tool_results"] = self.state.show_tool_results
            if "current_theme" in parameters:
                kwargs["current_theme"] = self.tui_settings.resolved_theme.name
            return await handle_command_async(text, **kwargs)
        handle_command = self.session.handle_command
        parameters = signature(handle_command).parameters
        kwargs: dict[str, object] = {}
        if "current_editor_text" in parameters:
            kwargs["current_editor_text"] = current_editor_text
        if "show_tool_results" in parameters:
            kwargs["show_tool_results"] = self.state.show_tool_results
        if "current_theme" in parameters:
            kwargs["current_theme"] = self.tui_settings.resolved_theme.name
        return handle_command(text, **kwargs)

    async def _handle_extension_ui_request(
        self,
        *,
        method: str,
        extension_name: str,
        **payload: object,
    ) -> object:
        """Handle Pi-style extension UI requests from async extension commands."""
        keybindings = self.tui_settings.keybindings
        if method == "select":
            options = tuple(str(option) for option in payload.get("options", ()))
            if not options:
                return None
            timeout_seconds = _extension_ui_timeout_seconds(payload.get("timeout_seconds"))
            return await self.push_screen_wait(
                ExtensionSelectScreen(
                    str(payload.get("title", f"{extension_name} selection")),
                    options,
                    timeout_seconds=timeout_seconds,
                    keybindings=keybindings,
                )
            )
        if method == "confirm":
            return await self.push_screen_wait(
                ConfirmationScreen(
                    str(payload.get("title", f"{extension_name} confirmation")),
                    str(payload.get("message", "")),
                    theme=self.tui_settings.resolved_theme,
                    keybindings=keybindings,
                )
            )
        if method == "input":
            return await self.push_screen_wait(
                ExtensionInputScreen(
                    str(payload.get("title", f"{extension_name} input")),
                    placeholder=str(payload.get("placeholder", "")),
                    prefill=str(payload.get("prefill", "")),
                    timeout_seconds=_extension_ui_timeout_seconds(
                        payload.get("timeout_seconds")
                    ),
                    keybindings=keybindings,
                )
            )
        if method == "editor":
            return await self.push_screen_wait(
                ExtensionEditorScreen(
                    str(payload.get("title", f"{extension_name} editor")),
                    prefill=str(payload.get("prefill", "")),
                    external_editor_command=self.tui_settings.external_editor,
                    keybindings=keybindings,
                )
            )
        if method == "custom":
            factory = payload.get("factory")
            if not callable(factory):
                raise TypeError("custom extension UI requires a callable factory")
            options = payload.get("options")
            return await self.push_screen_wait(
                ExtensionCustomScreen(
                    extension_name,
                    factory,
                    options=options if isinstance(options, Mapping) else None,
                    theme=self.tui_settings.resolved_theme,
                    keybindings=keybindings,
                )
            )
        raise ValueError(f"Unsupported extension UI request: {method}")

    async def _run_prompt(
        self,
        text: str,
        run_id: int | None = None,
        *,
        queued_after_start: Sequence[tuple[str, Literal["steer", "follow_up"]]] = (),
    ) -> None:
        """Run one prompt and stream session events into the TUI state."""
        active_run_id = self._prompt_run_id if run_id is None else run_id
        queued_after_start_sent = False
        try:
            async for event in self.session.prompt(text):
                if active_run_id != self._prompt_run_id:
                    return
                self.adapter.apply(event)
                if isinstance(event, ErrorEvent) and not event.recoverable:
                    _attach_diagnostic_log_path_to_error(self.state, self.session)
                await self._apply_streaming_transcript_event(event)
                if (
                    isinstance(event, AgentStartEvent)
                    and queued_after_start
                    and not queued_after_start_sent
                ):
                    queued_after_start_sent = True
                    await self._queue_messages_after_prompt_start(
                        queued_after_start,
                        active_run_id=active_run_id,
                    )
                if isinstance(event, AgentEndEvent) and not self._app_has_focus:
                    self._terminal_notification.notify_turn_finished()
        except Exception as exc:  # noqa: BLE001 - surface unexpected worker errors in the TUI
            if active_run_id != self._prompt_run_id:
                return
            message = _format_prompt_error(exc, self.session)
            self.state.error = message
            self.state.add_item("error", message)
            self.state.running = False
            self._refresh()
        finally:
            if active_run_id == self._prompt_run_id:
                self._prompt_worker = None
                self._clear_retry_countdown(refresh=False)

    async def _queue_messages_after_prompt_start(
        self,
        messages: Sequence[tuple[str, Literal["steer", "follow_up"]]],
        *,
        active_run_id: int,
    ) -> None:
        """Queue messages into a prompt that has just started running."""
        for message_text, mode in messages:
            try:
                async for event in self.session.prompt(message_text, streaming_behavior=mode):
                    if active_run_id != self._prompt_run_id:
                        return
                    self.adapter.apply(event)
                    await self._apply_streaming_transcript_event(event)
            except Exception as exc:  # noqa: BLE001 - preserve visible failure for queued input
                self._notify(f"Could not queue message after compaction: {exc}", severity="error")
                return

    async def _apply_streaming_transcript_event(self, event: AgentEvent) -> None:
        """Apply an agent event to mounted transcript widgets without full redraws."""
        if not self.screen_stack:
            self._refresh()
            return
        theme = self.tui_settings.resolved_theme
        try:
            transcript = self.query_one("#transcript", TranscriptView)
        except NoMatches:
            self._refresh()
            return
        if isinstance(event, AgentStartEvent):
            self._refresh_chrome()
            return
        if isinstance(event, AgentEndEvent):
            await transcript.finish_assistant_message()
            self._clear_retry_countdown(refresh=False)
            if self._flush_pending_terminal_commands_to_transcript():
                self._refresh()
                return
            self._refresh_chrome()
            return
        if isinstance(event, MessageStartEvent):
            self._clear_retry_countdown(refresh=True)
            return
        if isinstance(event, MessageDeltaEvent):
            await transcript.append_assistant_delta(
                event.delta,
                theme=theme,
                output_padding_x=self.tui_settings.output_padding_x,
            )
            self._sync_activity_indicator()
            return
        if isinstance(event, ThinkingDeltaEvent):
            await transcript.append_thinking_delta(
                event.delta,
                theme=theme,
                show_thinking=self.state.show_thinking,
                placeholder_text=self.state.thinking_placeholder_text,
                output_padding_x=self.tui_settings.output_padding_x,
            )
            self._sync_activity_indicator()
            return
        if isinstance(event, MessageEndEvent):
            if event.message.role == "user":
                self._refresh()
                self._sync_terminal_title()
                return
            if event.message.role == "assistant":
                await transcript.finish_assistant_message(event.message.content)
                if event.message.finish_reason == "length":
                    self._refresh()
                else:
                    self._refresh_chrome()
                return
            return
        if isinstance(event, ToolExecutionStartEvent):
            await transcript.finish_assistant_message()
            await transcript.append_item(
                self.state.items[-1],
                theme=theme,
                show_tool_results=self.state.show_tool_results,
                show_images=self.tui_settings.show_images,
                image_width_cells=self.tui_settings.image_width_cells,
                output_padding_x=self.tui_settings.output_padding_x,
                tool_results_key_hint=_key_hint(self.tui_settings.keybindings.toggle_tool_results),
            )
            self._refresh_chrome()
            return
        if isinstance(event, ToolExecutionUpdateEvent) and _tool_update_has_pipeline_stage(event):
            await transcript.finish_assistant_message()
            self._refresh()
            return
        if isinstance(event, RetryEvent):
            self._start_retry_countdown(event)
        if isinstance(event, ErrorEvent):
            self._clear_retry_countdown(refresh=False)
        if isinstance(event, ToolExecutionUpdateEvent | RetryEvent | ErrorEvent):
            await transcript.finish_assistant_message()
            if self.state.items:
                await transcript.append_item(
                    self.state.items[-1],
                    theme=theme,
                    show_tool_results=self.state.show_tool_results,
                    show_images=self.tui_settings.show_images,
                    image_width_cells=self.tui_settings.image_width_cells,
                    output_padding_x=self.tui_settings.output_padding_x,
                    tool_results_key_hint=_key_hint(
                        self.tui_settings.keybindings.toggle_tool_results
                    ),
                )
            self._refresh_chrome()
            return
        if isinstance(event, ToolExecutionEndEvent):
            self._refresh()
            return
        if isinstance(event, QueueUpdateEvent):
            self._refresh_chrome()
            return
        self._refresh_chrome()

    def action_cancel(self) -> None:
        """Cancel the active compaction or agent turn."""
        if self._cancel_active_compaction(notify=True):
            self._last_empty_escape_at = None
            return
        if self._cancel_active_terminal_command(notify=True):
            self._last_empty_escape_at = None
            return
        if self._cancel_active_share(notify=True):
            self._last_empty_escape_at = None
            return
        if self._cancel_active_branch(notify=True):
            self._last_empty_escape_at = None
            return
        if self._cancel_active_prompt(notify=True):
            self._last_empty_escape_at = None
            return
        if self._clear_terminal_command_prompt():
            self._last_empty_escape_at = None
            return
        self._handle_empty_prompt_escape()

    def _cancel_active_compaction(self, *, notify: bool) -> bool:
        """Cancel the active manual compaction worker and restore visible session state."""
        worker = self._compaction_worker
        if worker is None or worker.is_finished or worker.is_cancelled:
            return False

        worker.cancel()
        self._compaction_worker = None
        self.state.clear()
        self.state.set_skills(self.session.skills)
        self._load_session_transcript()
        restored = self._restore_compaction_queue_to_prompt()
        self._refresh()
        if notify:
            if restored:
                self._notify(f"Cancelled compaction; restored {restored} queued message(s).")
            else:
                self._notify("Cancelled compaction.")
        return True

    def _cancel_active_terminal_command(self, *, notify: bool) -> bool:
        """Cancel the active input-bar terminal command."""
        worker = self._terminal_worker
        if worker is None or worker.is_finished or worker.is_cancelled:
            return False

        cancel_terminal = getattr(self.session, "cancel_terminal_command", None)
        if callable(cancel_terminal):
            cancel_terminal()
        worker.cancel()
        self._terminal_worker = None
        self._refresh()
        if notify:
            self._notify("Cancelled terminal command.")
        return True

    def _cancel_active_share(self, *, notify: bool) -> bool:
        """Cancel the active share worker and restore visible session state."""
        worker = self._share_worker
        if worker is None or worker.is_finished or worker.is_cancelled:
            return False

        worker.cancel()
        self._share_worker = None
        self.state.items = [
            item for item in self.state.items if item.text != "Sharing current session..."
        ]
        self._sync_activity_indicator()
        self._refresh()
        if notify:
            self._notify("Cancelled share.", severity="warning")
        return True

    def _cancel_active_branch(self, *, notify: bool) -> bool:
        """Cancel the active branch/fork worker and restore visible session state."""
        worker = self._branch_worker
        if worker is None or worker.is_finished or worker.is_cancelled:
            return False

        worker.cancel()
        self._branch_worker = None
        self.state.clear()
        self.state.set_skills(self.session.skills)
        self._load_session_transcript()
        self._refresh()
        if notify:
            self._notify("Cancelled branch operation.")
        return True

    def _clear_terminal_command_prompt(self) -> bool:
        """Clear a drafted terminal command when Escape exits shell mode."""
        try:
            prompt = self.query_one("#prompt", PromptInput)
        except NoMatches:
            return False
        if not _is_terminal_command_prompt(prompt.text):
            return False
        prompt.text = ""
        self._sync_prompt_shell_mode("")
        self._set_prompt_completion_state("", cursor_position=0)
        return True

    def _cancel_active_prompt(self, *, notify: bool, interrupt: bool = False) -> bool:
        """Cancel the active prompt worker and ignore any late events from it."""
        del interrupt
        worker = self._prompt_worker
        is_worker_active = worker is not None and not worker.is_cancelled
        is_session_running = bool(getattr(self.session, "is_running", False))
        if not (self.state.running or is_session_running or is_worker_active):
            return False

        self._prompt_run_id += 1
        cancel = getattr(self.session, "cancel", None)
        if callable(cancel):
            cancel()
        if worker is not None and not worker.is_cancelled:
            worker.cancel()
        self._prompt_worker = None
        self.state.running = False
        self.state.assistant_buffer = ""
        self._clear_retry_countdown(refresh=False)
        self._refresh()
        if notify:
            self._notify("Interrupted current operation.")
        return True

    def _handle_empty_prompt_escape(self) -> bool:
        action = self.tui_settings.double_escape_action
        if action == "none":
            self._last_empty_escape_at = None
            return False
        try:
            prompt = self.query_one("#prompt", PromptInput)
        except NoMatches:
            self._last_empty_escape_at = None
            return False
        if prompt.text.strip():
            self._last_empty_escape_at = None
            return False

        now = monotonic()
        last_escape_at = self._last_empty_escape_at
        if last_escape_at is not None and now - last_escape_at <= 0.5:
            self._last_empty_escape_at = None
            if action == "tree":
                self.run_worker(self._open_tree_picker(), exclusive=False)
            elif action == "fork":
                self.run_worker(self._open_fork_picker(), exclusive=False)
            return True

        self._last_empty_escape_at = now
        return False

    def action_accept_completion(self) -> None:
        """Accept the currently selected prompt completion."""
        if isinstance(self.screen, ModelPickerScreen):
            self.screen.action_toggle_mode()
            return
        if isinstance(self.screen, SessionPickerScreen):
            self.screen.action_toggle_scope()
            return
        if isinstance(
            self.screen,
            TreePickerScreen
            | UserMessagePickerScreen
            | SettingsPickerScreen
            | ThinkingPickerScreen
            | ImageVisibilityPickerScreen
            | LoginMethodPickerScreen
            | LoginProviderPickerScreen
            | SkillPickerScreen
            | PromptTemplatePickerScreen
            | ThemePickerScreen,
        ):
            self.screen.action_select_cursor()
            return
        prompt = self.query_one("#prompt", PromptInput)
        applied = self._apply_selected_completion(prompt.text)
        if applied is None:
            return
        prompt.text = applied
        prompt.move_cursor(_text_end_location(applied))
        self._set_prompt_completion_state(prompt.text)

    async def action_quit(self) -> None:
        """Quit the app, or use picker-local quit bindings when a modal owns them."""
        if isinstance(self.screen, SessionPickerScreen):
            self.screen.action_delete_session()
            return
        result = super().action_quit()
        if isawaitable(result):
            await result

    def action_completion_next(self) -> None:
        """Select the next prompt completion or move down in the prompt."""
        if isinstance(self.screen, CommandOutputScreen):
            self.screen.action_scroll_down()
            return
        if isinstance(
            self.screen,
            SessionPickerScreen
            | ToolsReferenceScreen
            | SkillPickerScreen
            | PromptTemplatePickerScreen
            | SettingsPickerScreen
            | ThinkingPickerScreen
            | ImageVisibilityPickerScreen
            | TreePickerScreen
            | UserMessagePickerScreen
            | LoginMethodPickerScreen
            | LoginProviderPickerScreen
            | ThemePickerScreen
            | ModelPickerScreen,
        ):
            self.screen.action_cursor_down()
            return
        if not self._completion_state.items:
            self.query_one("#prompt", PromptInput).action_cursor_down()
            return
        self._completion_state = self._completion_state.select_next()
        self._refresh_completions()

    def action_completion_previous(self) -> None:
        """Select the previous prompt completion or move up in the prompt."""
        if isinstance(self.screen, CommandOutputScreen):
            self.screen.action_scroll_up()
            return
        if isinstance(
            self.screen,
            SessionPickerScreen
            | ToolsReferenceScreen
            | SkillPickerScreen
            | PromptTemplatePickerScreen
            | SettingsPickerScreen
            | ThinkingPickerScreen
            | ImageVisibilityPickerScreen
            | TreePickerScreen
            | UserMessagePickerScreen
            | LoginMethodPickerScreen
            | LoginProviderPickerScreen
            | ThemePickerScreen
            | ModelPickerScreen,
        ):
            self.screen.action_cursor_up()
            return
        if not self._completion_state.items:
            if self.action_edit_queued_follow_up():
                return
            self.query_one("#prompt", PromptInput).action_cursor_up()
            return
        self._completion_state = self._completion_state.select_previous()
        self._refresh_completions()

    def action_edit_queued_follow_up(self) -> bool:
        """Move the latest queued follow-up back into the prompt for editing."""
        if not self.state.running:
            return False
        prompt = self.query_one("#prompt", PromptInput)
        if prompt.text.strip():
            return False
        pop_follow_up = getattr(self.session, "pop_latest_follow_up_message", None)
        if not callable(pop_follow_up):
            return False
        message = pop_follow_up()
        if not message:
            return False
        prompt.text = message
        prompt.move_cursor(_text_end_location(message))
        self._sync_queue_state()
        self._set_prompt_completion_state(prompt.text)
        self._refresh()
        return True

    async def action_run_extension_shortcut(self, key: str) -> bool:
        """Run a non-conflicting extension shortcut registered for the prompt surface."""
        if _extension_shortcut_conflicts_with_builtins(key, self.tui_settings.keybindings):
            return False
        shortcut_sources = getattr(self.session, "extension_shortcut_sources", {})
        if key.strip().lower() not in shortcut_sources:
            return False
        handle_shortcut = getattr(self.session, "handle_extension_shortcut", None)
        if not callable(handle_shortcut):
            return False
        try:
            prompt = self.query_one("#prompt", PromptInput)
            parameters = signature(handle_shortcut).parameters
            kwargs: dict[str, object] = {}
            if "current_editor_text" in parameters:
                kwargs["current_editor_text"] = prompt.expanded_text()
            if "show_tool_results" in parameters:
                kwargs["show_tool_results"] = self.state.show_tool_results
            if "current_theme" in parameters:
                kwargs["current_theme"] = self.tui_settings.resolved_theme.name
            result = handle_shortcut(key, **kwargs)
            if isawaitable(result):
                result = await result
        except Exception as exc:  # noqa: BLE001 - extensions are an isolation boundary
            self._notify(f"Extension shortcut error: {exc}", severity="error")
            return True
        if not result.handled:
            return False
        if result.message:
            self._append_command_message(f"[{key.strip().lower()}]", result.message)
        self._deliver_command_notifications(result)
        self._apply_command_status_updates(result)
        self._apply_command_widget_updates(result)
        self._apply_command_working_indicator_update(result)
        self._apply_command_footer_update(result)
        self._apply_command_header_update(result)
        if result.theme is not None:
            self._set_tui_theme(result.theme)
        if result.show_tool_results is not None:
            self._set_tool_results_expanded(result.show_tool_results)
        if result.hidden_thinking_label_requested:
            self._set_hidden_thinking_label(result.hidden_thinking_label)
        if result.terminal_title_requested:
            self._set_extension_terminal_title(result.terminal_title)
        if result.editor_text is not None:
            self._set_prompt_editor_text(result.editor_text)
        elif result.editor_insert_text is not None:
            self._insert_prompt_editor_text(result.editor_insert_text)
        elif result.editor_paste_text is not None:
            self._paste_prompt_editor_text(result.editor_paste_text)
        self._refresh()
        if result.exit_requested:
            self.exit()
        return True

    def action_open_command_palette(self) -> None:
        """Open the slash-command palette in the prompt."""
        prompt = self.query_one("#prompt", PromptInput)
        prompt.focus()
        prompt.text = "/"
        prompt.move_cursor((0, 1))
        self._set_prompt_completion_state(prompt.text, cursor_position=prompt.cursor_position)

    def action_open_session_picker(self) -> None:
        """Open the indexed session picker."""
        if self.state.running:
            self._notify("Tau is already working. Press Escape to cancel.")
            return
        current_records = _session_records(self.session, scope="current")
        all_records = _session_records(self.session, scope="all")
        if not current_records and not all_records:
            self._notify("No sessions found.")
            return
        self.push_screen(
            SessionPickerScreen(
                current_records,
                theme=self.tui_settings.resolved_theme,
                all_records=all_records,
                current_session_id=getattr(self.session, "session_id", None),
                keybindings=self.tui_settings.keybindings,
                rename_session=self._rename_picker_session,
                delete_session=self._delete_picker_session,
            ),
            callback=self._handle_session_picker_result,
        )

    def action_new_session(self) -> None:
        """Start a new session from a configured app keybinding."""
        if self.state.running:
            self._notify("Tau is already working. Press Escape to cancel.")
            return
        self.run_worker(self._new_session(), exclusive=False)

    def action_open_tree_picker(self) -> None:
        """Open the session tree from a configured app keybinding."""
        if self._is_agent_or_queue_active():
            self._notify(TREE_RUNNING_MESSAGE, severity="warning")
            return
        self.run_worker(self._open_tree_picker(), exclusive=False)

    def action_open_fork_picker(self) -> None:
        """Open the session fork picker from a configured app keybinding."""
        if self._is_agent_or_queue_active():
            self._notify(TREE_RUNNING_MESSAGE, severity="warning")
            return
        self.run_worker(self._open_fork_picker(), exclusive=False)

    def _rename_picker_session(
        self,
        session_id: str,
        name: str,
    ) -> SessionCompletionRecord | None:
        """Rename an indexed session from the session picker."""
        manager = getattr(self.session, "session_manager", None)
        if manager is None:
            return None
        return manager.touch_session(
            session_id,
            model=self.session.model,
            provider_name=self.session.provider_name,
            title=name,
        )

    def _delete_picker_session(self, session_id: str) -> bool:
        """Delete an indexed session from the session picker."""
        manager = getattr(self.session, "session_manager", None)
        delete_session = getattr(manager, "delete_session", None)
        if not callable(delete_session):
            return False
        return delete_session(session_id) is not None

    def action_cycle_thinking(self) -> None:
        """Cycle the active thinking mode."""
        self.run_worker(self._cycle_thinking_level(), exclusive=False)

    def action_cycle_model(self) -> None:
        """Cycle through scoped models."""
        if self.state.running:
            self._notify("Tau is already working. Press Escape to cancel.")
            return
        self.run_worker(self._cycle_scoped_model(), exclusive=False)

    def action_cycle_model_previous(self) -> None:
        """Cycle backwards through scoped models."""
        if self.state.running:
            self._notify("Tau is already working. Press Escape to cancel.")
            return
        self.run_worker(self._cycle_scoped_model(direction="previous"), exclusive=False)

    def action_open_model_picker(self) -> None:
        """Open the interactive model picker."""
        if self.state.running:
            self._notify("Tau is already working. Press Escape to cancel.")
            return
        self._open_model_picker()

    def action_toggle_tool_results(self) -> None:
        """Toggle inline tool result details in the transcript."""
        expanded = self.state.toggle_tool_results()
        self.state.rerender_custom_entries()
        self._refresh()
        self._notify("Tool results expanded." if expanded else "Tool results collapsed.")

    def action_open_dag_viewer_handoff(self) -> None:
        """Open the web DAG viewer for the current or most recent DAG run."""
        self._open_dag_viewer_handoff(source="keybinding")

    def action_toggle_thinking(self) -> None:
        """Toggle thinking-token display in the transcript."""
        self.state.toggle_thinking()
        self._refresh()

    def _handle_dag_viewer_command(self, text: str) -> bool:
        """Handle the local /dag-viewer handoff command."""
        stripped = text.strip()
        if not stripped.casefold().startswith("/dag-viewer"):
            return False
        try:
            parts = shlex.split(stripped)
        except ValueError as exc:
            self._append_command_message("/dag-viewer", f"Usage: /dag-viewer [run-dir]\n{exc}")
            self._refresh()
            return True
        if not parts or parts[0].casefold() != "/dag-viewer":
            return False
        if len(parts) > 2:
            self._append_command_message("/dag-viewer", "Usage: /dag-viewer [run-dir]")
            self._refresh()
            return True
        run_dir = Path(parts[1]) if len(parts) == 2 else None
        message = self._open_dag_viewer_handoff(run_dir=run_dir, source="/dag-viewer")
        self._append_command_message("/dag-viewer", message)
        self._refresh()
        return True

    def _handle_pending_decisions_command(self, text: str) -> bool:
        """Handle the local /decisions inbox command."""
        stripped = text.strip()
        if stripped.casefold() not in {"/decisions", "/decision-inbox"}:
            return False
        decisions = self._refresh_pending_decisions(notify=False)
        self._append_command_message("/decisions", pending_decision_report(decisions))
        self._refresh()
        return True

    def _refresh_pending_decisions(self, *, notify: bool) -> tuple[PendingDecision, ...]:
        """Refresh the prompt-region pending-decision inbox."""
        try:
            decisions = collect_pending_decisions()
        except RuntimeError as exc:
            self._extension_widgets_above["pending-decisions"] = (
                "Pending human decisions unavailable",
                str(exc),
            )
            self._extension_statuses["decisions"] = "unavailable"
            if notify:
                self._notify(f"Pending decisions unavailable: {exc}", severity="error")
            return ()
        lines = pending_decision_lines(decisions)
        if lines:
            self._extension_widgets_above["pending-decisions"] = lines
            self._extension_statuses["decisions"] = f"{len(decisions)} pending"
        else:
            self._extension_widgets_above.pop("pending-decisions", None)
            self._extension_statuses.pop("decisions", None)
        current_keys = {decision.key for decision in decisions}
        if notify:
            new_keys = current_keys - self._pending_decision_keys
            for decision in decisions:
                if decision.key not in new_keys:
                    continue
                message = f"Tau approval required: {decision.workflow_id}/{decision.node_id}"
                self._terminal_notification.notify_pending_decision(message)
                self._notify(message, severity="warning")
        self._pending_decision_keys = current_keys
        return decisions

    def _open_dag_viewer_handoff(
        self,
        *,
        run_dir: Path | None = None,
        source: str,
    ) -> str:
        """Launch a loopback DAG viewer using the existing dag-viewer-link target."""
        selected_run_dir = run_dir or self._last_dag_viewer_run_dir
        if selected_run_dir is None:
            message = (
                "DAG viewer unavailable: no current DAG run is known. "
                "Run a workflow first, or use /dag-viewer <run-dir>."
            )
            self._notify(message, severity="warning")
            return message
        try:
            link = build_dag_viewer_link(selected_run_dir)
        except Exception as exc:  # noqa: BLE001 - show invalid paths and malformed stores plainly
            message = f"DAG viewer unavailable for {selected_run_dir}: {exc}"
            self._notify(message, severity="error")
            return message
        if link.get("ok") is not True:
            message = _dag_viewer_unavailable_message(link, selected_run_dir)
            self._notify(message, severity="warning")
            return message
        try:
            launch_command = _dag_viewer_launch_command(link)
            launch_run_dir, run_id = _dag_viewer_launch_target(launch_command)
            server = create_dag_viewer_server(
                run_dir=launch_run_dir,
                run_id=run_id,
                host="127.0.0.1",
                port=0,
            )
        except Exception as exc:  # noqa: BLE001 - surface handoff/link drift to the operator
            message = f"DAG viewer unavailable for {selected_run_dir}: {exc}"
            self._notify(message, severity="error")
            return message
        thread = threading.Thread(
            target=server.serve_forever,
            name=f"tau-dag-viewer-{server.port}",
            daemon=True,
        )
        thread.start()
        self._dag_viewer_servers.append(server)
        self._dag_viewer_threads.append(thread)
        self._last_dag_viewer_run_dir = launch_run_dir
        self._last_dag_viewer_launch_command = launch_command
        node_id = _dag_viewer_node_target(launch_run_dir)
        url = _dag_viewer_url_with_node(server.url, node_id)
        opened = webbrowser.open(url)
        suffix = f" targeting node {node_id}" if node_id else ""
        message = f"DAG viewer opened{suffix}: {url}"
        if opened is False:
            message = f"{message}\nBrowser open returned false; copy the URL manually."
        self._notify(f"DAG viewer opened from {source}.")
        return message

    def _shutdown_dag_viewer_servers(self) -> None:
        """Stop loopback viewer servers launched from the TUI."""
        for server in self._dag_viewer_servers:
            with suppress(Exception):
                server.shutdown()
        for thread in self._dag_viewer_threads:
            if thread.is_alive():
                thread.join(timeout=2)
        self._dag_viewer_servers.clear()
        self._dag_viewer_threads.clear()

    def action_open_external_editor(self) -> None:
        """Open the prompt text in the configured external editor."""
        if self.state.running:
            self._notify("Tau is already working. Press Escape to cancel.")
            return
        self.run_worker(self._open_external_editor(), exclusive=False)

    def action_paste_clipboard(self) -> None:
        """Paste plain text from the system clipboard into the prompt."""
        self.run_worker(self._paste_clipboard(), exclusive=False)

    def action_dequeue_messages(self) -> None:
        """Restore all queued messages into the prompt for editing."""
        restored = self._restore_queued_messages_to_prompt()
        if restored == 0:
            self._notify("No queued messages to restore.")
        else:
            suffix = "s" if restored != 1 else ""
            self._notify(f"Restored {restored} queued message{suffix}.")

    def action_copy_last_message(self) -> None:
        """Copy the most recent agent/assistant message to the system clipboard."""
        text = _last_assistant_text(self.state)
        if not text:
            self._notify("No agent messages to copy yet.", severity="warning")
            return
        self.copy_to_clipboard(text)
        self._notify("Copied last agent message to clipboard.")

    def action_suspend_process(self) -> None:
        """Suspend Tau to the background and restore the TUI after foregrounding."""
        if sys.platform == "win32":
            self._notify("Suspend to background is not supported on Windows.", severity="warning")
            return
        try:
            with self.suspend():
                os.kill(0, signal.SIGTSTP)
        except Exception as exc:  # noqa: BLE001 - surface terminal/signal failures in the TUI
            self._notify(f"Could not suspend Tau: {exc}", severity="error")
            return
        self._refresh()

    async def _open_external_editor(self) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        original_text = prompt.expanded_text()
        editor_command = _external_editor_command(self.tui_settings.external_editor)
        if editor_command is None:
            self._notify(
                "Set TUI external_editor, VISUAL, or EDITOR to use the external editor.",
                severity="warning",
            )
            return
        try:
            with self.suspend():
                result = await _edit_text_with_external_editor(editor_command, original_text)
        except Exception as exc:  # noqa: BLE001 - surface editor launch failures in the TUI
            self._notify(f"External editor failed: {exc}", severity="error")
            return
        if result is None:
            self._notify("External editor exited without changes.", severity="warning")
            return
        prompt.text = result
        prompt.clear_paste_markers()
        prompt.move_cursor(_text_end_location(result))
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._set_prompt_completion_state(prompt.text)
        self._refresh()

    async def _paste_clipboard(self) -> None:
        try:
            image = await _read_clipboard_image()
            if image is not None:
                if self.tui_settings.block_images:
                    self._notify("Image paste is blocked by TUI settings.", severity="warning")
                    return
                self._insert_prompt_text(str(_write_clipboard_image_to_temp(image)))
                return
            text = await _read_clipboard_text()
        except Exception:  # noqa: BLE001 - clipboard access is best effort
            return
        if not text:
            return
        self._insert_prompt_text(text, compact_large_paste=True)

    def _insert_prompt_text(self, text: str, *, compact_large_paste: bool = False) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        if compact_large_paste:
            prompt.insert_paste_text(text)
        else:
            prompt.insert(text)
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._set_prompt_completion_state(prompt.text)
        self._refresh()

    def _restore_queued_messages_to_prompt(self) -> int:
        clear_queued = getattr(self.session, "clear_queued_messages", None)
        if not callable(clear_queued):
            return 0
        queued = clear_queued()
        messages = [
            *(message.content for message in queued.steering),
            *(message.content for message in queued.follow_up),
        ]
        if not messages:
            self._sync_queue_state()
            self._refresh()
            return 0
        prompt = self.query_one("#prompt", PromptInput)
        queued_text = "\n\n".join(messages)
        combined_text = "\n\n".join(part for part in (queued_text, prompt.text) if part.strip())
        prompt.text = combined_text
        prompt.move_cursor(_text_end_location(combined_text))
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._sync_queue_state()
        self._set_prompt_completion_state(prompt.text)
        self._refresh()
        return len(messages)

    def _handle_session_picker_result(self, session_id: str | None) -> None:
        if session_id is None:
            return
        initial_prompt = None
        if self.startup_resume_picker and self.initial_prompt and self.initial_prompt.strip():
            initial_prompt = self.initial_prompt.strip()
            self.initial_prompt = None
        self.run_worker(
            self._resume_session(session_id, submit_after_resume=initial_prompt),
            exclusive=False,
        )

    async def _resume_session(
        self,
        session_id: str,
        *,
        submit_after_resume: str | None = None,
    ) -> None:
        try:
            resume_message = await self.session.resume(session_id)
            if not _is_extension_cancel_message(resume_message) and self.is_running:
                self._reset_extension_ui_state()
            self.state.clear()
            self.state.set_skills(self.session.skills)
            self._load_session_transcript()
            self._notify(resume_message)
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
            submit_after_resume = None
        self._refresh()
        if submit_after_resume:
            self._submit_prompt(submit_after_resume)

    async def _import_session(self, path: Path) -> None:
        import_session = getattr(self.session, "import_session", None)
        if import_session is None:
            self._notify("Session import is not available.", severity="warning")
            return
        self.push_screen(
            ConfirmationScreen(
                "Import session",
                f"Import and resume session from {path}?",
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=lambda confirmed: self._handle_import_confirmation(path, confirmed),
        )

    def _handle_import_confirmation(self, path: Path, confirmed: bool) -> None:
        if not confirmed:
            self._notify("Import cancelled.")
            self._refresh()
            return
        self.run_worker(self._run_import_session(path), exclusive=False)

    async def _run_import_session(self, path: Path) -> None:
        import_session = getattr(self.session, "import_session", None)
        if import_session is None:
            self._notify("Session import is not available.", severity="warning")
            return
        try:
            message = await import_session(path)
            if not _is_extension_cancel_message(message):
                self._reset_extension_ui_state()
            self.state.clear()
            self.state.set_skills(self.session.skills)
            self._load_session_transcript()
            self._notify(message)
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
        self._refresh()

    async def _run_share_session(self) -> None:
        share = getattr(self.session, "share", None)
        if share is None:
            self._notify("Session sharing is not available.", severity="warning")
            self._share_worker = None
            return
        self.state.add_item("status", "Sharing current session...")
        self._sync_activity_indicator()
        self._refresh()
        try:
            message = await share()
        except asyncio.CancelledError:
            self.state.items = [
                item for item in self.state.items if item.text != "Sharing current session..."
            ]
            self._sync_activity_indicator()
            self._refresh()
            return
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self.state.items = [
                item for item in self.state.items if item.text != "Sharing current session..."
            ]
            self._sync_activity_indicator()
            self._notify(f"Error: {exc}", severity="error")
            self._refresh()
            return
        finally:
            self._share_worker = None
        self.state.items = [
            item for item in self.state.items if item.text != "Sharing current session..."
        ]
        self._sync_activity_indicator()
        self._notify(message)
        self._refresh()

    async def _open_tree_picker(self) -> None:
        if self._is_agent_or_queue_active():
            self._notify(TREE_RUNNING_MESSAGE, severity="warning")
            return
        tree_choices = getattr(self.session, "tree_choices", None)
        if tree_choices is None:
            self._notify("Session tree is not available.", severity="warning")
            return
        try:
            choices = tuple(await tree_choices())
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
            return
        if not choices:
            self._notify("No session entries are available for branching.", severity="warning")
            return
        self.push_screen(
            TreePickerScreen(
                choices,
                theme=self.tui_settings.resolved_theme,
                initial_filter_mode=cast(TreeFilterMode, self.tui_settings.tree_filter_mode),
                keybindings=self.tui_settings.keybindings,
                set_entry_label=self._set_tree_entry_label_from_picker,
            ),
            callback=self._handle_tree_picker_result,
        )

    async def _open_fork_picker(self) -> None:
        if self._is_agent_or_queue_active():
            self._notify(TREE_RUNNING_MESSAGE, severity="warning")
            return
        tree_choices = getattr(self.session, "tree_choices", None)
        if tree_choices is None:
            self._notify("Session tree is not available.", severity="warning")
            return
        try:
            choices = tuple(
                choice
                for choice in await tree_choices()
                if _tree_choice_matches_filter(
                    choice,
                    filter_mode="user-only",
                    show_tool_calls=True,
                )
            )
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
            return
        if not choices:
            self._notify("No messages to fork from.", severity="warning")
            return
        self.push_screen(
            UserMessagePickerScreen(choices, keybindings=self.tui_settings.keybindings),
            callback=self._handle_fork_picker_result,
        )

    def _handle_fork_picker_result(self, entry_id: str | None) -> None:
        if entry_id is None:
            return
        self._branch_worker = self.run_worker(
            self._branch_to_tree_entry(entry_id, summarize=False),
            exclusive=False,
        )

    async def _set_tree_entry_label_from_picker(
        self,
        entry_id: str,
        label: str | None,
    ) -> tuple[SessionTreeChoice, ...]:
        set_tree_entry_label = getattr(self.session, "set_tree_entry_label", None)
        tree_choices = getattr(self.session, "tree_choices", None)
        if set_tree_entry_label is None or tree_choices is None:
            raise RuntimeError("Session tree labels are not available.")
        result = set_tree_entry_label(entry_id, label)
        if isawaitable(result):
            result = await result
        if result:
            self._notify(str(result))
        return tuple(await tree_choices())

    def _handle_tree_picker_result(self, result: TreePickerResult | None) -> None:
        if result is None:
            return
        self._branch_worker = self.run_worker(
            self._branch_to_tree_entry(
                result.entry_id,
                summarize=result.summarize,
                custom_instructions=result.custom_instructions,
            ),
            exclusive=False,
        )

    async def _branch_to_tree_entry(
        self,
        entry_id: str,
        *,
        summarize: bool,
        custom_instructions: str | None = None,
    ) -> None:
        if self._is_agent_or_queue_active(include_branch=False):
            self._notify(TREE_RUNNING_MESSAGE, severity="warning")
            return
        branch_to_entry = getattr(self.session, "branch_to_entry", None)
        if branch_to_entry is None:
            self._notify("Session tree is not available.", severity="warning")
            return
        try:
            if summarize:
                self.state.clear()
                self.state.add_item("status", "Summarizing branch... (Escape to cancel)")
                self._refresh()

            result = branch_to_entry(
                entry_id,
                summarize=summarize,
                custom_instructions=custom_instructions,
            )
            if isawaitable(result):
                result = await result
            message_text = (
                result.message
                if isinstance(result, SessionTreeBranchResult)
                else result
                if isinstance(result, str)
                else ""
            )
            if not _is_extension_cancel_message(message_text):
                self._reset_extension_ui_state()
            self.state.clear()
            self.state.set_skills(self.session.skills)
            self._load_session_transcript()
            if isinstance(result, SessionTreeBranchResult):
                if result.input_prefill is not None:
                    prompt = self.query_one("#prompt", PromptInput)
                    prompt.value = result.input_prefill
                    prompt.move_cursor(_text_end_location(result.input_prefill))
                    prompt.focus()
                self._notify(result.message)
            elif isinstance(result, str):
                self._notify(result)
        except asyncio.CancelledError:
            self.state.clear()
            self.state.set_skills(self.session.skills)
            self._load_session_transcript()
            self._refresh()
            return
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
        finally:
            self._branch_worker = None
        self._refresh()

    async def _new_session(self) -> None:
        self._cancel_active_prompt(notify=False, interrupt=True)
        new_session = getattr(self.session, "new_session", None)
        if new_session is None:
            self._notify("Session manager is not available.")
            return
        try:
            message = await new_session()
            if not _is_extension_cancel_message(message):
                self._reset_extension_ui_state()
            self.state.clear()
            self.state.set_skills(self.session.skills)
            self._load_session_transcript()
            self._notify(message or "New session started.")
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
        self._refresh()

    async def _clone_session(self) -> None:
        clone_current_session = getattr(self.session, "clone_current_session", None)
        if clone_current_session is None:
            self._notify("Session manager is not available.", severity="warning")
            return
        try:
            message = await clone_current_session()
            if not _is_extension_cancel_message(message):
                self._reset_extension_ui_state()
            self.state.clear()
            self.state.set_skills(self.session.skills)
            self._load_session_transcript()
            self._notify(message)
        except Exception as exc:  # noqa: BLE001 - surface command failures in the TUI
            self._notify(f"Error: {exc}", severity="error")
        self._refresh()

    def _apply_selected_completion(self, value: str) -> str | None:
        item = self._completion_state.selected
        if item is None:
            return None
        return item.apply(value)

    def _append_command_message(self, command_text: str, message: str) -> None:
        """Append non-persistent command output to the visible transcript."""
        self.state.add_item("status", f"{_command_output_title(command_text)}\n{message}")

    def _write_debug_log(self) -> Path:
        """Write a TUI runtime diagnostic log and return its path."""
        path = TauPaths().logs_dir / "tui-debug.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            screenshot = self.export_screenshot()
        except Exception:  # noqa: BLE001 - diagnostics should never break the TUI
            screenshot = ""
        payload = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "terminal": {"width": self.size.width, "height": self.size.height},
            "screen": type(self.screen).__name__,
            "focused": {
                "type": type(self.focused).__name__ if self.focused is not None else None,
                "id": getattr(self.focused, "id", None),
            },
            "session": {
                "id": getattr(self.session, "session_id", None),
                "title": getattr(self.session, "session_title", None),
                "cwd": str(self.session.cwd),
                "provider": self.session.provider_name,
                "model": self.session.model,
            },
            "state": {
                "running": self.state.running,
                "items": [
                    {
                        "role": item.role,
                        "text": item.text,
                        "tool_call_id": item.tool_call_id,
                        "has_tool_result": item.tool_result_text is not None,
                    }
                    for item in self.state.items
                ],
            },
            "messages": [_debug_message_payload(message) for message in self.session.messages],
            "screenshot_svg_chars": len(screenshot),
        }
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return path

    def _show_command_message(self, command_text: str, message: str) -> None:
        self.push_screen(
            CommandOutputScreen(
                _command_output_title(command_text),
                message,
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
                render_markdown=_command_output_renders_markdown(command_text),
            )
        )

    def _open_workflow_picker(self) -> None:
        workflows = list_workflows()
        if not workflows:
            self._notify("No packaged Tau workflows are available.", severity="warning")
            return
        self.push_screen(
            WorkflowPickerScreen(
                workflows,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_workflow_picker_result,
        )

    def _open_tools_reference(self) -> None:
        """Open a read-only view of tools from the active session."""
        self.push_screen(
            ToolsReferenceScreen(
                self.session.tools,
                extension_sources=getattr(self.session, "extension_tool_sources", {}),
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
            )
        )

    def _open_skill_picker(self) -> None:
        """Open a searchable skill picker for the active session."""
        self.push_screen(
            SkillPickerScreen(
                self.session.skills,
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_skill_picker_result,
        )

    def _handle_skill_picker_result(self, result: SkillPickerResult | None) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        if result is None:
            prompt.text = ""
        elif result.action == "insert":
            prompt.text = f"/skill:{result.skill.name}"
        else:
            prompt.text = ""
            self.state.add_item(
                "status",
                (f"Skill: {result.skill.name} (not added to context)\n{result.skill.content}"),
            )
            self._refresh()
        prompt.move_cursor(_text_end_location(prompt.text))
        prompt.focus()

    def _open_prompt_template_picker(self) -> None:
        """Open a searchable prompt-template picker for the active session."""
        self.push_screen(
            PromptTemplatePickerScreen(
                self.session.prompt_templates,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_prompt_template_picker_result,
        )

    def _handle_prompt_template_picker_result(self, name: str | None) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        prompt.focus()
        if name is None:
            return
        invocation = f"/{name}"
        prompt.text = invocation
        prompt.move_cursor(_text_end_location(invocation))
        self._set_prompt_completion_state(invocation)

    def _handle_workflow_picker_result(self, result: WorkflowPickerResult | None) -> None:
        if result is None:
            return
        workflow_id = result.workflow_id
        if result.action == "insert_run":
            self._insert_workflow_run_command(workflow_id)
            return
        registry = _session_command_registry(self.session)
        command_text = f"/workflows {workflow_id}"
        command_result = registry.execute(self.session, command_text)
        if command_result.message is None:
            self._notify(f"Could not describe workflow: {workflow_id}", severity="error")
            return
        self._show_command_message(command_text, command_result.message)

    def _insert_workflow_run_command(self, workflow_id: str) -> None:
        try:
            workflow = get_workflow(workflow_id)
        except RuntimeError:
            self._notify(f"Unknown workflow: {workflow_id}", severity="error")
            return
        command = _workflow_run_terminal_command(workflow, cwd=self.session.cwd)
        text = f"!! {command}"
        prompt = self.query_one("#prompt", PromptInput)
        prompt.text = text
        prompt.move_cursor(_text_end_location(text))
        prompt.focus()
        self._sync_prompt_shell_mode(prompt.text)
        self._set_prompt_completion_state(prompt.text)
        self._notify(f"Inserted run command for {workflow.workflow_id}. Press Enter to launch.")
        self._refresh()

    def _open_login_picker(self, *, initial_search: str = "") -> None:
        if initial_search:
            self._open_login_provider_picker(
                BUILTIN_PROVIDER_CATALOG,
                initial_search=initial_search,
            )
            return
        self.push_screen(
            LoginMethodPickerScreen(
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_login_method_result,
        )

    def _handle_login_method_result(self, method: str | None) -> None:
        if method is None:
            return
        if method == "subscription":
            providers = _subscription_login_providers(BUILTIN_PROVIDER_CATALOG)
        elif method == "api-key":
            providers = _api_key_login_providers(BUILTIN_PROVIDER_CATALOG)
        else:
            self._notify(f"Unknown login method: {method}", severity="error")
            return
        if not providers:
            self._notify("No login providers are available for that method.", severity="warning")
            return
        self._open_login_provider_picker(providers)

    def _open_login_provider_picker(
        self,
        providers: Sequence[ProviderCatalogEntry],
        *,
        initial_search: str = "",
        title: str = "Login",
    ) -> None:
        visible_providers = _filter_login_providers(providers, initial_search)
        if not visible_providers:
            self._notify(
                f"No login providers match: {initial_search}",
                severity="warning",
            )
            return
        self.push_screen(
            LoginProviderPickerScreen(
                providers,
                theme=self.tui_settings.resolved_theme,
                title=title,
                initial_search=initial_search,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_login_provider_result,
        )

    def _handle_login_provider_result(self, provider_name: str | None) -> None:
        if provider_name is None:
            return
        self._open_login(provider_name)

    def _open_login(self, provider_name: str) -> None:
        entry = builtin_provider_entry(provider_name)
        if entry is None:
            self._notify(f"Unknown provider: {provider_name}", severity="error")
            return
        if entry.kind == "openai-codex":
            self.push_screen(
                OAuthLoginScreen(
                    entry,
                    theme=self.tui_settings.resolved_theme,
                    keybindings=self.tui_settings.keybindings,
                ),
                callback=lambda credential: self._handle_oauth_login_result(entry, credential),
            )
            return
        self.push_screen(
            LoginScreen(
                entry,
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
            ),
            callback=lambda api_key: self._handle_login_result(entry, api_key),
        )

    def _handle_login_result(self, entry: ProviderCatalogEntry, api_key: str | None) -> None:
        if api_key is None:
            return
        try:
            FileCredentialStore().set(entry.credential_name, api_key)
            provider = provider_config_from_catalog_entry(entry.name)
            upsert_saved_provider(provider, set_default=False)
            self.session.reload_provider_settings()
            try:
                self.session.set_provider(entry.name, persist_default=False)
            except TypeError:
                self.session.set_provider(entry.name)
        except Exception as exc:  # noqa: BLE001 - surface login failures in the TUI
            self._notify(f"Could not save login: {exc}", severity="error")
            return
        self._notify(_login_success_message(entry, self.session))
        self._maybe_warn_anthropic_subscription_auth(saved_entry=entry, saved_api_key=api_key)
        self._refresh()

    def _handle_oauth_login_result(
        self,
        entry: ProviderCatalogEntry,
        credential: OAuthCredential | None,
    ) -> None:
        if credential is None:
            return
        try:
            FileCredentialStore().set_oauth(entry.credential_name, credential)
            provider = provider_config_from_catalog_entry(entry.name)
            upsert_saved_provider(provider, set_default=False)
            self.session.reload_provider_settings()
            try:
                self.session.set_provider(entry.name, persist_default=False)
            except TypeError:
                self.session.set_provider(entry.name)
        except Exception as exc:  # noqa: BLE001 - surface login failures in the TUI
            self._notify(f"Could not save login: {exc}", severity="error")
            return
        self._notify(_login_success_message(entry, self.session))
        self._refresh()

    def _maybe_warn_anthropic_subscription_auth(
        self,
        *,
        saved_entry: ProviderCatalogEntry | None = None,
        saved_api_key: str | None = None,
    ) -> None:
        """Warn once when Anthropic subscription-style auth is the active auth path."""
        if not self.tui_settings.anthropic_extra_usage_warning:
            return
        if self._anthropic_subscription_warning_shown:
            return
        provider_name = getattr(self.session, "provider_name", None)
        saved_anthropic_oat = (
            saved_entry is not None
            and saved_entry.name == "anthropic"
            and _is_anthropic_subscription_auth_key(saved_api_key)
        )
        if provider_name != "anthropic" and not saved_anthropic_oat:
            return
        if not _anthropic_subscription_auth_active(saved_api_key=saved_api_key):
            return
        self._anthropic_subscription_warning_shown = True
        self._notify(ANTHROPIC_SUBSCRIPTION_AUTH_WARNING, severity="warning")

    def _open_logout_picker(self) -> None:
        providers = _stored_credential_providers(BUILTIN_PROVIDER_CATALOG)
        if not providers:
            self._notify(NO_STORED_CREDENTIALS_MESSAGE, severity="warning")
            return
        self.push_screen(
            LoginProviderPickerScreen(
                providers,
                theme=self.tui_settings.resolved_theme,
                title="Logout",
                keybindings=self.tui_settings.keybindings,
            ),
            callback=self._handle_logout_provider_result,
        )

    def _handle_logout_provider_result(self, provider_name: str | None) -> None:
        if provider_name is None:
            return
        self._logout(provider_name)

    def _logout(self, provider_name: str) -> None:
        entry = builtin_provider_entry(provider_name)
        if entry is None:
            self._notify(f"Unknown provider: {provider_name}", severity="error")
            return

        credential_store = FileCredentialStore()
        if not _credential_store_has_entry(credential_store, entry.credential_name):
            self._notify(NO_STORED_CREDENTIALS_MESSAGE, severity="warning")
            return

        try:
            credential_store.delete(entry.credential_name)
            self.session.reload_provider_settings()
        except Exception as exc:  # noqa: BLE001 - surface logout failures in the TUI
            self._notify(f"Could not log out: {exc}", severity="error")
            return

        if entry.kind == "openai-codex":
            self._notify(f"Logged out of {entry.display_name}.")
        else:
            self._notify(
                f"Removed stored API key for {entry.display_name}. "
                "Environment variables and providers.json config are unchanged."
            )
        self._refresh()

    def _available_model_choices(self) -> tuple[ModelChoice, ...]:
        fallback_choices = (
            ModelChoice(provider_name=self.session.provider_name, model=model)
            for model in self.session.available_models
        )
        return tuple(
            getattr(
                self.session,
                "available_model_choices",
                fallback_choices,
            )
        )

    def _configured_scoped_model_choices(self) -> tuple[ModelChoice, ...]:
        return tuple(
            getattr(
                self.session,
                "configured_scoped_model_choices",
                getattr(self.session, "scoped_model_choices", ()),
            )
        )

    def _refresh_provider_settings_for_picker(self) -> bool:
        """Reload provider settings before showing provider-backed pickers."""
        reload_provider_settings = getattr(self.session, "reload_provider_settings", None)
        if not callable(reload_provider_settings):
            return True
        try:
            reload_provider_settings()
        except Exception as exc:  # noqa: BLE001 - keep stale provider config out of picker choices
            self._notify(f"Could not reload provider settings: {exc}", severity="error")
            return False
        return True

    def _open_model_picker(self, *, initial_search: str = "") -> None:
        if not self._refresh_provider_settings_for_picker():
            return
        choices = self._available_model_choices()
        if not choices:
            self._notify(
                "No configured providers are usable. Run /login to set up a provider.",
                severity="warning",
            )
            return
        self.push_screen(
            ModelPickerScreen(
                choices,
                scoped_choices=tuple(getattr(self.session, "scoped_model_choices", ())),
                current_model=self.session.model,
                provider_name=self.session.provider_name,
                theme=self.tui_settings.resolved_theme,
                initial_search=initial_search,
                on_toggle_scoped=None,
                keybindings=self.tui_settings.keybindings,
                picker_kind="model",
            ),
            callback=self._handle_model_picker_result,
        )

    def _open_scoped_models_picker(self) -> None:
        if not self._refresh_provider_settings_for_picker():
            return
        choices = self._available_model_choices()
        if not choices:
            self._notify(
                "No configured providers are usable. Run /login to set up a provider.",
                severity="warning",
            )
            return
        self.push_screen(
            ModelPickerScreen(
                choices,
                scoped_choices=self._configured_scoped_model_choices(),
                current_model=self.session.model,
                provider_name=self.session.provider_name,
                theme=self.tui_settings.resolved_theme,
                on_toggle_scoped=self._toggle_scoped_model,
                on_set_scoped=self._set_scoped_models,
                keybindings=self.tui_settings.keybindings,
                picker_kind="scoped",
            ),
            callback=self._handle_scoped_models_picker_result,
        )

    def _toggle_scoped_model(self, choice: ModelChoice) -> Sequence[ModelChoice]:
        toggle_scoped_model = getattr(self.session, "toggle_scoped_model", None)
        if toggle_scoped_model is None:
            self._notify("Scoped model controls are not available.", severity="warning")
            return self._configured_scoped_model_choices()
        try:
            return tuple(toggle_scoped_model(choice))
        except Exception as exc:  # noqa: BLE001 - surface session state failures in the TUI
            self._notify(f"Could not update scoped models: {exc}", severity="error")
            return self._configured_scoped_model_choices()

    def _set_scoped_models(self, choices: Sequence[ModelChoice]) -> Sequence[ModelChoice]:
        set_scoped_models = getattr(self.session, "set_scoped_models", None)
        if set_scoped_models is None:
            self._notify("Scoped model controls are not available.", severity="warning")
            return self._configured_scoped_model_choices()
        try:
            return tuple(set_scoped_models(choices))
        except Exception as exc:  # noqa: BLE001 - surface session state failures in the TUI
            self._notify(f"Could not update scoped models: {exc}", severity="error")
            return self._configured_scoped_model_choices()

    def _handle_scoped_models_picker_result(self, choice: ModelChoice | None) -> None:
        del choice
        self._refresh()

    def _handle_model_picker_result(
        self,
        choice: ModelChoice | None,
        *,
        notify: bool = True,
    ) -> None:
        if choice is None:
            return
        try:
            set_model_choice = getattr(self.session, "set_model_choice", None)
            if set_model_choice is None:
                if choice.provider_name != self.session.provider_name:
                    self.session.set_provider(choice.provider_name)
                self.session.set_model(choice.model)
            else:
                set_model_choice(choice)
        except Exception as exc:  # noqa: BLE001 - surface model switch failures in the TUI
            self._notify(f"Could not switch model: {exc}", severity="error")
            return
        daxnuts_message = daxnuts_easter_message(choice.provider_name, choice.model)
        if daxnuts_message is not None:
            self.state.add_item("status", daxnuts_message)
        self._refresh()
        if notify:
            self._notify(f"Switched to {choice.provider_name}:{choice.model}.")

    def _open_theme_picker(self) -> None:
        self._theme_picker_original_theme = self.tui_settings.theme
        self.push_screen(
            ThemePickerScreen(
                current_theme=self.tui_settings.theme,
                theme=self.tui_settings.resolved_theme,
                keybindings=self.tui_settings.keybindings,
                on_preview=self._preview_tui_theme,
            ),
            callback=self._handle_theme_picker_result,
        )

    def _handle_theme_picker_result(self, theme: str | None) -> None:
        if theme is None:
            if self._theme_picker_original_theme is not None:
                self._preview_tui_theme(self._theme_picker_original_theme)
            self._theme_picker_original_theme = None
            return
        self._theme_picker_original_theme = None
        self._set_tui_theme(theme)

    async def _set_thinking_level(self, level: str) -> None:
        setter = getattr(self.session, "set_thinking_level", None)
        if setter is None:
            self._notify("Thinking controls are not available.", severity="warning")
            return
        try:
            result = setter(level)
            if isawaitable(result):
                result = await result
        except Exception as exc:  # noqa: BLE001 - surface session state failures in the TUI
            self._notify(f"Could not change thinking mode: {exc}", severity="error")
            return
        self._refresh()
        if isinstance(result, str) and result:
            self._notify(result)

    async def _cycle_thinking_level(self) -> None:
        cycler = getattr(self.session, "cycle_thinking_level", None)
        if cycler is None:
            self._notify("Thinking controls are not available.", severity="warning")
            return
        try:
            result = cycler()
            if isawaitable(result):
                result = await result
        except Exception as exc:  # noqa: BLE001 - surface session state failures in the TUI
            self._notify(f"Could not change thinking mode: {exc}", severity="error")
            return
        self._refresh()

    async def _cycle_scoped_model(
        self,
        *,
        direction: Literal["next", "previous"] = "next",
    ) -> None:
        scoped_choices = tuple(getattr(self.session, "scoped_model_choices", ()))
        choices = scoped_choices or self._available_model_choices()
        if len(choices) <= 1:
            self._notify(
                "Only one model in scope." if scoped_choices else "Only one model available.",
                severity="warning",
            )
            return
        current = ModelChoice(provider_name=self.session.provider_name, model=self.session.model)
        try:
            current_index = choices.index(current)
        except ValueError:
            current_index = 0 if direction == "previous" else -1
        delta = -1 if direction == "previous" else 1
        self._handle_model_picker_result(
            choices[(current_index + delta) % len(choices)],
            notify=False,
        )

    def _notify(
        self,
        message: str,
        *,
        severity: Literal["information", "warning", "error"] = "information",
    ) -> None:
        key = (message, severity)
        if key in self._active_notification_keys:
            return
        self._active_notification_keys.add(key)
        self.set_timer(
            self.NOTIFICATION_TIMEOUT,
            lambda: self._active_notification_keys.discard(key),
            name=f"notification-dedupe-{hash(key)}",
        )
        self.notify(message, severity=severity, markup=False)

    def _refresh(self) -> None:
        theme = self.tui_settings.resolved_theme
        self._refresh_chrome(theme=theme)
        transcript = self.query_one("#transcript", TranscriptView)
        transcript.update_from_state(
            self.state,
            theme=theme,
            show_images=self.tui_settings.show_images,
            image_width_cells=self.tui_settings.image_width_cells,
            clear_on_shrink=self.tui_settings.clear_on_shrink,
            output_padding_x=self.tui_settings.output_padding_x,
            tool_results_key_hint=_key_hint(self.tui_settings.keybindings.toggle_tool_results),
        )

    def _refresh_chrome(self, *, theme: TuiTheme | None = None) -> None:
        """Refresh non-transcript chrome without remounting transcript blocks."""
        theme = theme or self.tui_settings.resolved_theme
        self._sync_queue_state()
        sidebar = self.query_one("#sidebar", SessionSidebar)
        sidebar.update_from_session(self.session, theme=theme)
        self._refresh_dag_run_status(theme=theme)
        compact_info = self.query_one("#compact-session-info", CompactSessionInfo)
        compact_info.update_from_session(self.session, theme=theme)
        startup_resources = self.query_one("#startup-resources", Static)
        header_component = self.query_one("#extension-header-component", Vertical)
        header_component_active = self._extension_header_component_factory is not None
        header_component.display = header_component_active
        if header_component_active:
            startup_resources.display = False
            startup_text = ""
        elif self._extension_header_lines is None:
            startup_text = _render_startup_resources_summary(
                self.session,
                keybindings=self.tui_settings.keybindings,
                expanded=self.state.show_tool_results,
                startup_notice=self.startup_message,
            )
            startup_resources.display = (
                bool(startup_text) and not self.tui_settings.quiet_startup
            )
        else:
            startup_text = _render_extension_header(self._extension_header_lines)
            startup_resources.display = bool(startup_text)
        startup_resources.update(startup_text)
        queued_messages = self.query_one("#queued-messages", Static)
        queued_messages.display = self.state.queued_message_count > 0
        queued_messages.update(
            _render_queued_messages(
                self.state,
                theme=theme,
                keybindings=self.tui_settings.keybindings,
            )
        )
        extension_status = self.query_one("#extension-status", Static)
        status_text = _render_extension_statuses(self._extension_statuses)
        extension_status.display = bool(status_text)
        extension_status.update(status_text)
        widgets_above = self.query_one("#extension-widgets-above", Static)
        widgets_above_text = _render_extension_widgets(self._extension_widgets_above)
        widgets_above.display = bool(widgets_above_text)
        widgets_above.update(widgets_above_text)
        widget_components_above = self.query_one("#extension-widget-components-above", Vertical)
        widget_components_above.display = bool(self._extension_widget_components_above)
        widgets_below = self.query_one("#extension-widgets-below", Static)
        widgets_below_text = _render_extension_widgets(self._extension_widgets_below)
        widgets_below.display = bool(widgets_below_text)
        widgets_below.update(widgets_below_text)
        widget_components_below = self.query_one("#extension-widget-components-below", Vertical)
        widget_components_below.display = bool(self._extension_widget_components_below)
        self._sync_activity_indicator()
        self._refresh_footer_bindings()

    def _refresh_dag_run_status(self, *, theme: TuiTheme | None = None) -> None:
        """Refresh the compact DAG status pane from the viewer's live projection."""
        pane = self.query_one("#dag-run-status-pane", DagRunStatusPane)
        run_dir = self._last_dag_viewer_run_dir
        resolved_theme = theme or self.tui_settings.resolved_theme
        if run_dir is None:
            pane.update_from_snapshot(snapshot=None, run_dir=None, theme=resolved_theme)
            return
        try:
            snapshot = _build_tui_dag_status_snapshot(run_dir)
        except (OSError, RuntimeError, ValueError) as exc:
            pane.update_from_snapshot(
                snapshot=None,
                run_dir=run_dir,
                error=str(exc),
                theme=resolved_theme,
            )
            return
        pane.update_from_snapshot(snapshot=snapshot, run_dir=run_dir, theme=resolved_theme)

    def _sync_queue_state(self) -> None:
        queue_event = getattr(self.session, "queue_update_event", None)
        if callable(queue_event):
            event = queue_event()
            steering = event.steering
            follow_up = event.follow_up
        else:
            steering = ()
            follow_up = ()
        if self._compaction_queued_messages:
            steering = (
                *steering,
                *(text for text, mode in self._compaction_queued_messages if mode == "steer"),
            )
            follow_up = (
                *follow_up,
                *(text for text, mode in self._compaction_queued_messages if mode == "follow_up"),
            )
        self.adapter.apply(QueueUpdateEvent(steering=steering, follow_up=follow_up))

    def _flush_pending_terminal_commands_to_transcript(self) -> bool:
        if not self.state.pending_terminal_commands:
            return False
        self.state.items.extend(self.state.pending_terminal_commands)
        self.state.pending_terminal_commands.clear()
        return True

    def _sync_activity_indicator(self) -> None:
        active = self._is_tui_activity_active()
        if active:
            interval_seconds = self._activity_indicator_interval_seconds()
            if (
                self._activity_timer is not None
                and self._activity_timer_interval_seconds != interval_seconds
            ):
                self._activity_timer.stop()
                self._activity_timer = None
                self._activity_timer_interval_seconds = None
            if self._activity_timer is None:
                self._activity_timer = self.set_interval(
                    interval_seconds,
                    self._tick_activity,
                    name="activity-indicator",
                )
                self._activity_timer_interval_seconds = interval_seconds
            else:
                self._activity_timer.resume()
            self._apply_activity_indicator()
            self._sync_terminal_title()
            self._sync_terminal_progress_indicator()
            return
        self._activity_frame = 0
        if self._activity_timer is not None:
            self._activity_timer.pause()
        self._apply_activity_indicator()
        self._sync_terminal_title()
        self._sync_terminal_progress_indicator()

    def _start_retry_countdown(self, event: RetryEvent) -> None:
        self._retry_countdown_attempt = event.attempt
        self._retry_countdown_max_attempts = event.max_attempts
        self._retry_countdown_expires_at = monotonic() + max(0.0, event.delay_seconds)
        self._update_retry_countdown_message()
        if self._retry_countdown_timer is None:
            self._retry_countdown_timer = self.set_interval(
                1.0,
                self._tick_retry_countdown,
                name="retry-countdown",
            )
        else:
            self._retry_countdown_timer.resume()
        self._sync_activity_indicator()

    def _tick_retry_countdown(self) -> None:
        if self._retry_countdown_expires_at is None:
            self._stop_retry_countdown_timer()
            return
        remaining_seconds = self._update_retry_countdown_message()
        if remaining_seconds <= 0:
            self._stop_retry_countdown_timer()
        self._apply_activity_indicator()

    def _update_retry_countdown_message(self) -> int:
        attempt = self._retry_countdown_attempt
        max_attempts = self._retry_countdown_max_attempts
        expires_at = self._retry_countdown_expires_at
        if attempt is None or max_attempts is None or expires_at is None:
            self._retry_countdown_message = None
            return 0
        remaining_seconds = max(0, ceil(expires_at - monotonic()))
        cancel_key = _key_hint_with_default(self.tui_settings.keybindings.cancel, "escape")
        self._retry_countdown_message = (
            f"Retrying ({attempt}/{max_attempts}) in {remaining_seconds}s... "
            f"({cancel_key} to cancel)"
        )
        return remaining_seconds

    def _clear_retry_countdown(self, *, refresh: bool = False) -> None:
        self._retry_countdown_expires_at = None
        self._retry_countdown_message = None
        self._retry_countdown_attempt = None
        self._retry_countdown_max_attempts = None
        self._stop_retry_countdown_timer()
        if refresh:
            self._apply_activity_indicator()

    def _stop_retry_countdown_timer(self) -> None:
        if self._retry_countdown_timer is not None:
            self._retry_countdown_timer.stop()
            self._retry_countdown_timer = None

    def _activity_indicator_interval_seconds(self) -> float:
        if self._extension_working_indicator_frames is not None:
            return self._extension_working_indicator_interval_seconds or ACTIVITY_TICK_SECONDS
        return ACTIVITY_TICK_SECONDS

    def _sync_terminal_progress_indicator(self) -> None:
        active = self._is_tui_activity_active() and self.tui_settings.show_terminal_progress
        if active == self._terminal_progress_active:
            return
        self._terminal_progress_active = active
        self._write_terminal_progress(active=active)

    def _write_terminal_progress(self, *, active: bool) -> None:
        stream = getattr(self.console, "file", None)
        if stream is None:
            return
        stream.write(
            TERMINAL_PROGRESS_ACTIVE_SEQUENCE if active else TERMINAL_PROGRESS_CLEAR_SEQUENCE
        )
        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()

    def _tick_activity(self) -> None:
        if not self._is_tui_activity_active():
            return
        self._activity_frame += 1
        self._apply_activity_indicator()
        self._sync_terminal_title()

    def _sync_terminal_title(self) -> None:
        self._terminal_title.update(
            self._extension_terminal_title or getattr(self.session, "session_title", None),
            cwd=getattr(self.session, "cwd", None),
            running=self._is_tui_activity_active(),
            frame=self._activity_frame,
        )

    def _apply_activity_indicator(self) -> None:
        theme = self.tui_settings.resolved_theme
        try:
            prompt = self.query_one("#prompt", PromptInput)
            prompt_prefix = self.query_one("#prompt-prefix", Static)
            working_message = self.query_one("#prompt-working-message", Static)
        except NoMatches:
            return
        running = self._is_tui_activity_active()
        prompt.styles.border = (
            "tall",
            _activity_prompt_border_color(
                theme,
                frame=self._activity_frame,
                running=running,
                shell_mode=_is_terminal_command_prompt(prompt.text),
                thinking_level=getattr(self.session, "thinking_level", None),
            ),
        )
        if running and self._retry_countdown_message is not None:
            message = self._retry_countdown_message
        else:
            message = self._operation_working_message(running=running)
        working_message.display = bool(message)
        working_message.update(_text_from_ansi(message) if message else "")
        prompt_prefix.update(
            _render_activity_indicator(
                theme,
                frame=self._activity_frame,
                running=running,
                shell_mode=_is_terminal_command_prompt(prompt.text),
                visible=self._extension_working_visible,
                custom_frames=self._extension_working_indicator_frames,
            )
        )

    def _operation_working_message(self, *, running: bool) -> str | None:
        """Return the visible prompt-chrome message for the active operation."""
        if not running:
            return None
        if self._extension_working_visible and self._extension_working_message is not None:
            return self._extension_working_message
        cancel_key = _key_hint_with_default(self.tui_settings.keybindings.cancel, "escape")
        if self._is_compaction_active():
            return f"Compacting context... ({cancel_key} to cancel)"
        if self._is_branch_active():
            return f"Summarizing branch... ({cancel_key} to cancel)"
        if self._is_reload_active():
            return "Reloading local coding resources and project context..."
        if self._is_share_active():
            return "Sharing current session..."
        if self._is_terminal_command_active():
            return f"Running terminal command... ({cancel_key} to cancel)"
        return None

    def _refresh_completions(self) -> None:
        suggestions = self.query_one("#autocomplete", Static)
        suggestions.display = bool(self._completion_state.items)
        suggestions.update(
            render_completion_suggestions(
                _visible_completion_state(
                    self._completion_state,
                    max_lines=self.tui_settings.autocomplete_max_visible,
                    width=max(suggestions.content_size.width or suggestions.size.width, 1),
                ),
                theme=self.tui_settings.resolved_theme,
            )
        )
        self._refresh_footer_bindings()

    def _update_responsive_layout(self, width: int, height: int) -> None:
        if self.tui_settings.sidebar_position == "off":
            self.add_class("-hide-sidebar")
            return
        show_sidebar = width >= SIDEBAR_MIN_WIDTH and height >= SIDEBAR_MIN_HEIGHT
        self.set_class(not show_sidebar, "-hide-sidebar")

    def _apply_sidebar_position(self) -> None:
        position = self.tui_settings.sidebar_position
        self.set_class(position == "right", "-sidebar-right")
        if position == "off":
            self.add_class("-hide-sidebar")
        else:
            self._update_responsive_layout(self.size.width, self.size.height)

    def _build_completion_state(
        self,
        text: str,
        *,
        cursor_position: int | None = None,
    ) -> CompletionState:
        base_state = self._build_base_completion_state(
            text,
            cursor_position=cursor_position,
        )
        if not self._extension_autocomplete_providers:
            return base_state
        return _extension_autocomplete_completion_state(
            text,
            cursor_position=cursor_position,
            base_state=base_state,
            providers=self._extension_autocomplete_providers.values(),
            notify=self._notify,
        )

    async def _build_completion_state_async(
        self,
        text: str,
        *,
        cursor_position: int | None = None,
    ) -> CompletionState:
        base_state = await self._build_base_completion_state_async(
            text,
            cursor_position=cursor_position,
        )
        if not self._extension_autocomplete_providers:
            return base_state
        return await _extension_autocomplete_completion_state_async(
            text,
            cursor_position=cursor_position,
            base_state=base_state,
            providers=self._extension_autocomplete_providers.values(),
            notify=self._notify,
        )

    def _build_base_completion_state(
        self,
        text: str,
        *,
        cursor_position: int | None = None,
    ) -> CompletionState:
        registry = _session_command_registry(self.session)
        return build_completion_state(
            text,
            command_registry=registry,
            skills=self.session.skills,
            prompt_templates=self.session.prompt_templates,
            model_names=self.session.available_models,
            provider_names=self.session.available_providers,
            thinking_levels=getattr(self.session, "available_thinking_levels", ()),
            theme_names=available_tui_theme_names(),
            session_options=_session_options(self.session),
            cwd=self.session.cwd,
            enable_skill_commands=self.tui_settings.enable_skill_commands,
            cursor_position=cursor_position,
        )

    async def _build_base_completion_state_async(
        self,
        text: str,
        *,
        cursor_position: int | None = None,
    ) -> CompletionState:
        registry = _session_command_registry(self.session)
        return await build_completion_state_async(
            text,
            command_registry=registry,
            skills=self.session.skills,
            prompt_templates=self.session.prompt_templates,
            model_names=self.session.available_models,
            provider_names=self.session.available_providers,
            thinking_levels=getattr(self.session, "available_thinking_levels", ()),
            theme_names=available_tui_theme_names(),
            session_options=_session_options(self.session),
            cwd=self.session.cwd,
            enable_skill_commands=self.tui_settings.enable_skill_commands,
            cursor_position=cursor_position,
        )

    def _set_prompt_completion_state(
        self,
        text: str,
        *,
        cursor_position: int | None = None,
    ) -> None:
        self._completion_state = self._build_completion_state(
            text,
            cursor_position=cursor_position,
        )
        self._refresh_completions()
        if self._completion_refresh_may_need_async(text, cursor_position=cursor_position):
            self._completion_refresh_run_id += 1
            run_id = self._completion_refresh_run_id
            self.run_worker(
                self._set_prompt_completion_state_async(
                    text,
                    cursor_position=cursor_position,
                    run_id=run_id,
                ),
                exclusive=False,
            )

    async def _set_prompt_completion_state_async(
        self,
        text: str,
        *,
        cursor_position: int | None,
        run_id: int,
    ) -> None:
        state = await self._build_completion_state_async(
            text,
            cursor_position=cursor_position,
        )
        if run_id != self._completion_refresh_run_id:
            return
        with suppress(NoMatches):
            prompt = self.query_one("#prompt", PromptInput)
            if prompt.text != text:
                return
            expected_cursor = (
                len(text) if cursor_position is None else max(0, min(cursor_position, len(text)))
            )
            if prompt.cursor_position != expected_cursor:
                return
        self._completion_state = state
        self._refresh_completions()

    def _completion_refresh_may_need_async(
        self,
        text: str,
        *,
        cursor_position: int | None = None,
    ) -> bool:
        if self._extension_autocomplete_providers:
            return True
        cursor = len(text) if cursor_position is None else max(0, min(cursor_position, len(text)))
        text_before_cursor = text[:cursor]
        if not text_before_cursor.startswith("/") or text_before_cursor.startswith("//"):
            return False
        token_end = text_before_cursor.find(" ")
        if token_end < 0:
            return False
        command_name = text_before_cursor[:token_end].removeprefix("/").lower()
        command = _session_command_registry(self.session).get(command_name)
        return command is not None and command.argument_completion_provider is not None

    def _refresh_current_prompt_completions(self) -> None:
        with suppress(NoMatches):
            prompt = self.query_one("#prompt", PromptInput)
            self._set_prompt_completion_state(
                prompt.text,
                cursor_position=prompt.cursor_position,
            )

    def action_refresh_completions_for_cursor(self) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        self._set_prompt_completion_state(
            prompt.text,
            cursor_position=prompt.cursor_position,
        )

    def _refresh_footer_bindings(self) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        footer_mode = _prompt_footer_mode(self.state, self._completion_state)
        prompt.set_footer_mode(
            footer_mode,
            dag_viewer_handoff_available=(
                footer_mode == "normal" and self._last_dag_viewer_run_dir is not None
            ),
        )
        custom_footer = self.query_one("#extension-footer", Static)
        component_footer = self.query_one("#extension-footer-component", Vertical)
        built_in_footer = self.query_one(Footer)
        custom_footer_text = _render_extension_footer(self._extension_footer_lines)
        footer_component_active = self._extension_footer_component_factory is not None
        component_footer.display = footer_component_active
        custom_footer.display = bool(custom_footer_text) and not footer_component_active
        custom_footer.update(custom_footer_text)
        built_in_footer.display = not (bool(custom_footer_text) or footer_component_active)

    def _register_extension_footer_branch_listener(
        self,
        callback: Callable[[], object],
    ) -> Callable[[], None]:
        """Subscribe an extension footer component to git branch changes."""
        if not callable(callback):
            raise TypeError("branch change callback must be callable")
        self._extension_footer_branch_callback_id += 1
        callback_id = self._extension_footer_branch_callback_id
        self._extension_footer_branch_callbacks[callback_id] = callback
        self._start_extension_footer_branch_timer()

        def unsubscribe() -> None:
            self._extension_footer_branch_callbacks.pop(callback_id, None)
            if not self._extension_footer_branch_callbacks:
                self._stop_extension_footer_branch_timer()

        return unsubscribe

    def _start_extension_footer_branch_timer(self) -> None:
        if (
            self._extension_footer_branch_timer is not None
            or not self._extension_footer_branch_callbacks
        ):
            return
        self._extension_footer_branch_last = _git_branch(self.session.cwd)
        self._extension_footer_branch_timer = self.set_interval(
            EXTENSION_BRANCH_WATCH_INTERVAL_SECONDS,
            self._tick_extension_footer_branch_change,
            name="extension-footer-branch-watch",
        )

    def _stop_extension_footer_branch_timer(self) -> None:
        if self._extension_footer_branch_timer is not None:
            self._extension_footer_branch_timer.stop()
            self._extension_footer_branch_timer = None
        self._extension_footer_branch_last = None

    def _clear_extension_footer_branch_listeners(self) -> None:
        self._extension_footer_branch_callbacks.clear()
        self._stop_extension_footer_branch_timer()

    def _tick_extension_footer_branch_change(self) -> None:
        if not self._extension_footer_branch_callbacks:
            self._stop_extension_footer_branch_timer()
            return
        current_branch = _git_branch(self.session.cwd)
        if current_branch == self._extension_footer_branch_last:
            return
        self._extension_footer_branch_last = current_branch
        for callback in tuple(self._extension_footer_branch_callbacks.values()):
            try:
                result = callback()
                if isawaitable(result):
                    asyncio.create_task(result)
            except Exception as exc:  # noqa: BLE001 - extension callback failures are non-fatal
                self._notify(
                    f"Extension footer branch callback failed: {exc}",
                    severity="error",
                )

    def _sync_prompt_shell_mode(self, text: str) -> None:
        prompt = self.query_one("#prompt", PromptInput)
        prompt.shell_mode_style = self.tui_settings.resolved_theme.role_styles["tool"].border
        prompt.set_class(_is_terminal_command_prompt(text), "-shell-mode")
        prompt.refresh()
        self._apply_activity_indicator()


def _activity_prompt_border_color(
    theme: TuiTheme,
    *,
    frame: int,
    running: bool,
    shell_mode: bool,
    thinking_level: str | None = None,
) -> str:
    """Return the prompt border color for the current activity animation frame."""
    del frame, running
    if shell_mode:
        return theme.role_styles["tool"].border
    return _thinking_prompt_border_color(theme, thinking_level)


def _thinking_prompt_border_color(theme: TuiTheme, thinking_level: str | None) -> str:
    """Return a Pi-style prompt border color for the active thinking depth."""
    level = str(thinking_level or "off").casefold()
    if level == "off":
        return theme.prompt_border
    if level == "minimal":
        return theme.role_styles["thinking"].border
    if level == "low":
        return theme.role_styles["assistant"].border
    if level == "medium":
        return theme.accent
    if level == "high":
        return theme.success
    if level == "xhigh":
        return theme.error
    return theme.prompt_border


def _render_activity_indicator(
    theme: TuiTheme,
    *,
    frame: int,
    running: bool,
    shell_mode: bool = False,
    visible: bool = True,
    custom_frames: tuple[str, ...] | None = None,
) -> Text:
    """Render the prompt prefix: a moving square while running, ``$`` in shell mode."""
    if shell_mode and not running:
        return Text("$", style=f"bold {theme.role_styles['tool'].border}")
    if not running:
        return Text("τ", style=f"bold {theme.accent}")
    if not visible:
        return Text(" ")
    if custom_frames is not None:
        if not custom_frames:
            return Text(" ")
        custom_frame = custom_frames[frame % len(custom_frames)]
        return _text_from_ansi(custom_frame, style=f"bold {theme.accent}")

    cycle_length = (ACTIVITY_INDICATOR_HEIGHT - 1) * 2
    cycle_position = frame % cycle_length
    active_row = (
        cycle_position
        if cycle_position < ACTIVITY_INDICATOR_HEIGHT
        else cycle_length - cycle_position
    )
    direction = 1 if cycle_position < ACTIVITY_INDICATOR_HEIGHT else -1
    trail_rows = {
        active_row: theme.accent,
        active_row - direction: _blend_hex_colors(
            theme.accent,
            theme.screen_background,
            fraction=0.35,
        ),
        active_row - (direction * 2): _blend_hex_colors(
            theme.accent,
            theme.screen_background,
            fraction=0.65,
        ),
    }

    rendered = Text()
    for row in range(ACTIVITY_INDICATOR_HEIGHT):
        color = trail_rows.get(row)
        if color is None:
            rendered.append(" ")
        else:
            rendered.append("■", style=color)
        if row < ACTIVITY_INDICATOR_HEIGHT - 1:
            rendered.append("\n")
    return rendered


def _text_from_ansi(text: str, *, style: str | None = None) -> Text:
    if "\x1b[" in text:
        return Text.from_ansi(text)
    return Text(text, style=style)


def _is_terminal_command_prompt(text: str) -> bool:
    """Return whether the prompt is currently in terminal-command mode."""
    return _terminal_command_prefix_span(text) is not None


def _terminal_command_prefix_span(text: str) -> tuple[int, int] | None:
    """Return the input span for a leading ! or !! terminal-command prefix."""
    leading_whitespace = len(text) - len(text.lstrip())
    stripped = text[leading_whitespace:]
    if stripped.startswith("!!"):
        return (leading_whitespace, leading_whitespace + 2)
    if stripped.startswith("!"):
        return (leading_whitespace, leading_whitespace + 1)
    return None


def _blend_hex_colors(start: str, end: str, *, fraction: float) -> str:
    """Blend two ``#rrggbb`` colors by ``fraction``."""
    start_rgb = _hex_to_rgb(start)
    end_rgb = _hex_to_rgb(end)
    blended = tuple(
        round(start_channel + (end_channel - start_channel) * fraction)
        for start_channel, end_channel in zip(start_rgb, end_rgb, strict=True)
    )
    return f"#{blended[0]:02x}{blended[1]:02x}{blended[2]:02x}"


def _hex_to_rgb(color: str) -> tuple[int, int, int]:
    value = color.removeprefix("#")
    if len(value) != 6:
        raise ValueError(f"Expected #rrggbb color, got {color!r}")
    return (int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def _visible_completion_state(
    state: CompletionState,
    *,
    max_lines: int,
    width: int | None = None,
) -> CompletionState:
    """Return a completion-state window with the selected item visible."""
    if not state.items or max_lines <= 0:
        return CompletionState()

    selected_line_limit = max(max_lines - 1, 1)
    start = 0
    while start < state.selected_index:
        candidate = CompletionState(
            items=state.items[start:],
            selected_index=state.selected_index - start,
        )
        if _completion_selected_render_line(candidate, width=width) < selected_line_limit:
            break
        start += 1

    end = len(state.items)
    while end > state.selected_index + 1:
        candidate = CompletionState(
            items=state.items[start:end],
            selected_index=state.selected_index - start,
        )
        if _completion_render_line_count(candidate, width=width) <= max_lines:
            break
        end -= 1

    while start < state.selected_index:
        candidate = CompletionState(
            items=state.items[start:end],
            selected_index=state.selected_index - start,
        )
        if _completion_render_line_count(candidate, width=width) <= max_lines:
            break
        start += 1

    return CompletionState(
        items=state.items[start:end],
        selected_index=state.selected_index - start,
    )


def _completion_selected_render_line(state: CompletionState, *, width: int | None = None) -> int:
    """Return the rendered line number for the selected completion item."""
    line = 0
    has_rendered_text = False
    previous_category: str | None = None
    for index, item in enumerate(state.items):
        if item.category != previous_category:
            if has_rendered_text:
                line += 1
            if item.category:
                line += 1
                has_rendered_text = True
            previous_category = item.category
        elif has_rendered_text:
            line += 1
        if index == state.selected_index:
            return line
        line += _completion_item_extra_wrapped_lines(item, width=width)
        has_rendered_text = True
    return line


def _completion_render_line_count(state: CompletionState, *, width: int | None = None) -> int:
    """Return how many lines the completion state renders into."""
    if not state.items:
        return 0
    line_count = 0
    previous_category: str | None = None
    for index, item in enumerate(state.items):
        if item.category != previous_category:
            if index:
                line_count += 1
            if item.category:
                line_count += 1
            previous_category = item.category
        line_count += 1 + _completion_item_extra_wrapped_lines(item, width=width)
    return line_count


def _completion_item_extra_wrapped_lines(
    item: CompletionItem,
    *,
    width: int | None,
) -> int:
    """Return extra rendered lines used when a completion description wraps."""
    if width is None or width <= 0 or not item.description:
        return 0
    output = StringIO()
    console = Console(
        file=output,
        width=width,
        force_terminal=False,
        color_system=None,
        legacy_windows=False,
    )
    console.print(
        render_completion_suggestions(
            CompletionState(items=(item,), selected_index=0),
            theme=TAU_DARK_THEME,
        ),
        end="",
    )
    line_count = len(output.getvalue().splitlines())
    return max(line_count - 1, 0)


def _session_command_registry(session: CodingSession) -> CommandRegistry:
    registry = getattr(session, "command_registry", None)
    if isinstance(registry, CommandRegistry):
        return registry
    return create_default_command_registry()


def _session_options(session: CodingSession) -> tuple[CompletionOption, ...]:
    return tuple(_session_option(record) for record in _session_records(session))


def _session_records(
    session: CodingSession,
    *,
    scope: Literal["current", "all"] = "current",
) -> tuple[SessionCompletionRecord, ...]:
    manager = getattr(session, "session_manager", None)
    if manager is None:
        return ()
    if scope == "all":
        try:
            return tuple(manager.list_sessions())
        except TypeError:
            return tuple(manager.list_sessions(session.cwd))
    try:
        records = manager.list_sessions(session.cwd)
    except TypeError:
        records = manager.list_sessions()
    return tuple(records)


def _session_option(record: SessionCompletionRecord) -> CompletionOption:
    description_parts = [record.title if record.title else "Untitled session"]
    if record.model:
        description_parts.append(record.model)
    description_parts.append(_short_path(record.cwd))
    return CompletionOption(value=record.id, description=" - ".join(description_parts))


def _short_path(path: Path) -> str:
    home = Path.home()
    try:
        return f"~/{path.relative_to(home)}"
    except ValueError:
        return str(path)


def _session_picker_label(
    record: SessionCompletionRecord,
    *,
    show_path: bool = False,
    current_session_id: str | None = None,
    thread_depth: int = 0,
) -> str:
    marker = "* " if current_session_id is not None and record.id == current_session_id else ""
    indent = "  " * max(0, thread_depth)
    parts = [f"{marker}{indent}{_session_updated_at_label(record.updated_at)}"]
    if record.model:
        parts.append(record.model)
    title = _named_session_title(record.title)
    if title is not None:
        parts.append(title)
    if show_path:
        parts.append(_short_path(record.cwd))
    return " - ".join(parts)


def _session_picker_sort_label(sort_mode: SessionPickerSortMode) -> str:
    """Return the Pi-facing label for a Tau session picker sort mode."""

    if sort_mode == "relevance":
        return "fuzzy"
    return sort_mode


def _session_picker_title(scope: Literal["current", "all"]) -> str:
    """Return the Pi-style session picker title for a scope."""
    if scope == "all":
        return "Resume Session (All)"
    return "Resume Session (Current Folder)"


def _session_picker_empty_message(
    *,
    scope: Literal["current", "all"],
    named_only: bool,
    named_key: str,
) -> str:
    """Return Pi-style empty-state guidance for the session picker."""
    if named_only:
        if scope == "all":
            return f"No named sessions found. Press {named_key} to show all."
        return (
            f"No named sessions in current folder. Press {named_key} to show all, "
            "or Tab to view all."
        )
    if scope == "all":
        return "No sessions found."
    return "No sessions in current folder. Press Tab to view all."


def _filter_session_picker_records(
    records: Sequence[SessionCompletionRecord],
    query: str,
    *,
    named_only: bool = False,
    sort_mode: SessionPickerSortMode = "threaded",
) -> tuple[SessionCompletionRecord, ...]:
    normalized = " ".join(query.casefold().split())
    candidates = tuple(
        record for record in records if _named_session_title(record.title) is not None
    )
    if not named_only:
        candidates = tuple(records)
    if not normalized:
        return _sort_session_picker_records(candidates, sort_mode=sort_mode)
    if sort_mode == "relevance":
        scored = tuple(
            (record, score)
            for record in candidates
            if (score := _session_picker_record_match_score(record, query)) is not None
        )
        return tuple(
            record
            for record, _score in sorted(
                scored,
                key=lambda item: (item[1], -item[0].updated_at),
            )
        )
    filtered = tuple(
        record for record in candidates if _session_picker_record_matches_query(record, query)
    )
    return _sort_session_picker_records(filtered, sort_mode=sort_mode)


def _session_picker_record_match_score(
    record: SessionCompletionRecord,
    query: str,
) -> float | None:
    text = _session_picker_search_text(record)
    trimmed = query.strip()
    if trimmed.startswith("re:"):
        pattern = trimmed[3:].strip()
        if not pattern:
            return None
        try:
            match = re.search(pattern, text, flags=re.IGNORECASE)
        except re.error:
            return None
        if match is None:
            return None
        return match.start() * 0.1

    score = 0.0
    for kind, value in _session_picker_query_tokens(trimmed):
        token_score = _session_picker_query_token_score(text, kind=kind, value=value)
        if token_score is None:
            return None
        score += token_score
    return score


def _session_picker_record_matches_query(
    record: SessionCompletionRecord,
    query: str,
) -> bool:
    return _session_picker_record_match_score(record, query) is not None


def _session_picker_query_token_score(
    text: str,
    *,
    kind: Literal["token", "phrase"],
    value: str,
) -> float | None:
    normalized_value = " ".join(value.casefold().split())
    if not normalized_value:
        return 0.0
    index = text.find(normalized_value)
    if index < 0:
        return None
    return index * 0.1


def _session_picker_query_tokens(query: str) -> tuple[tuple[Literal["token", "phrase"], str], ...]:
    tokens: list[tuple[Literal["token", "phrase"], str]] = []
    buffer: list[str] = []
    in_quote = False
    had_unclosed_quote = False

    def flush(kind: Literal["token", "phrase"]) -> None:
        value = "".join(buffer).strip()
        buffer.clear()
        if value:
            tokens.append((kind, value))

    for char in query:
        if char == '"':
            if in_quote:
                flush("phrase")
                in_quote = False
            else:
                flush("token")
                in_quote = True
            continue
        if not in_quote and char.isspace():
            flush("token")
            continue
        buffer.append(char)

    if in_quote:
        had_unclosed_quote = True

    if had_unclosed_quote:
        return tuple(("token", token) for token in _query_tokens(query))

    flush("phrase" if in_quote else "token")
    return tuple(tokens)


def _sort_session_picker_records(
    records: Sequence[SessionCompletionRecord],
    *,
    sort_mode: SessionPickerSortMode,
) -> tuple[SessionCompletionRecord, ...]:
    if sort_mode == "threaded":
        return _sort_threaded_session_picker_records(records)
    if sort_mode == "name":
        return tuple(
            sorted(
                records,
                key=lambda record: (
                    (_named_session_title(record.title) or "").casefold(),
                    record.model.casefold(),
                    _short_path(record.cwd).casefold(),
                    record.id.casefold(),
                ),
            )
        )
    return tuple(records)


def _sort_threaded_session_picker_records(
    records: Sequence[SessionCompletionRecord],
) -> tuple[SessionCompletionRecord, ...]:
    by_id = {record.id: record for record in records}
    children: dict[str | None, list[SessionCompletionRecord]] = {None: []}
    for record in records:
        parent_id = getattr(record, "parent_session_id", None)
        if parent_id not in by_id:
            parent_id = None
        children.setdefault(parent_id, []).append(record)

    latest_by_id: dict[str, float] = {}

    def latest_subtree_update(
        record: SessionCompletionRecord,
        seen: frozenset[str] = frozenset(),
    ) -> float:
        if record.id in latest_by_id:
            return latest_by_id[record.id]
        if record.id in seen:
            return record.updated_at
        latest = max(
            [record.updated_at]
            + [
                latest_subtree_update(child, seen | {record.id})
                for child in children.get(record.id, [])
                if child.id != record.id
            ]
        )
        latest_by_id[record.id] = latest
        return latest

    def sort_key(record: SessionCompletionRecord) -> tuple[float, float, str]:
        return (-latest_subtree_update(record), -record.updated_at, record.id.casefold())

    ordered: list[SessionCompletionRecord] = []
    emitted: set[str] = set()

    def append_tree(parent_id: str | None, seen: frozenset[str] = frozenset()) -> None:
        for record in sorted(children.get(parent_id, []), key=sort_key):
            if record.id in emitted:
                continue
            ordered.append(record)
            emitted.add(record.id)
            if record.id in seen:
                continue
            append_tree(record.id, seen | {record.id})

    append_tree(None)
    if len(ordered) != len(records):
        for record in sorted(records, key=sort_key):
            if record.id not in emitted:
                ordered.append(record)
                emitted.add(record.id)
                append_tree(record.id, frozenset({record.id}))
    return tuple(ordered)


def _session_picker_thread_depths(
    records: Sequence[SessionCompletionRecord],
) -> dict[str, int]:
    by_id = {record.id: record for record in records}
    depths: dict[str, int] = {}

    def depth_for(record: SessionCompletionRecord, seen: frozenset[str] = frozenset()) -> int:
        cached = depths.get(record.id)
        if cached is not None:
            return cached
        parent_id = getattr(record, "parent_session_id", None)
        if parent_id is None or parent_id not in by_id or parent_id in seen:
            depths[record.id] = 0
            return 0
        depth = depth_for(by_id[parent_id], seen | {record.id}) + 1
        depths[record.id] = depth
        return depth

    for record in records:
        depth_for(record)
    return depths


def _replace_session_picker_record(
    records: Sequence[SessionCompletionRecord],
    updated: SessionCompletionRecord,
) -> tuple[SessionCompletionRecord, ...]:
    """Return records with a matching session id replaced by an updated record."""
    replaced = False
    next_records: list[SessionCompletionRecord] = []
    for record in records:
        if record.id == updated.id:
            next_records.append(updated)
            replaced = True
        else:
            next_records.append(record)
    if not replaced:
        next_records.append(updated)
    return tuple(next_records)


def _remove_session_picker_record(
    records: Sequence[SessionCompletionRecord],
    session_id: str,
) -> tuple[SessionCompletionRecord, ...]:
    """Return records without a matching session id."""
    return tuple(record for record in records if record.id != session_id)


def _session_picker_search_text(record: SessionCompletionRecord) -> str:
    fields = [
        record.id,
        record.title or "",
        record.model,
        _session_picker_label(record),
    ]
    return " ".join(" ".join(field.casefold().split()) for field in fields)


def _tree_choice_matches_filter(
    choice: SessionTreeChoice,
    *,
    filter_mode: TreeFilterMode,
    show_tool_calls: bool,
) -> bool:
    normalized_label = " ".join(choice.label.casefold().split())
    if choice.is_tool_call and (filter_mode == "no-tools" or not show_tool_calls):
        return False
    if filter_mode == "user-only":
        return normalized_label.startswith("user:")
    if filter_mode == "labeled-only":
        return choice.tree_label is not None
    return True


def _tree_choice_matches_search(choice: SessionTreeChoice, query: str) -> bool:
    tokens = _query_tokens(query)
    if not tokens:
        return True
    searchable = _tree_choice_search_text(choice)
    return _query_tokens_match(tokens, searchable)


def _tree_choice_search_text(choice: SessionTreeChoice) -> str:
    fields = [
        choice.entry_id,
        choice.label,
        choice.tree_label or "",
        choice.copy_text or "",
    ]
    return " ".join(" ".join(field.casefold().split()) for field in fields)


def _tree_search_character(event: Key) -> str | None:
    character = event.character
    if character is None or len(character) != 1:
        return None
    if character.casefold() in {"s", "c"}:
        return None
    if ord(character) < 32 or ord(character) == 127:
        return None
    return character


def _tree_choice_has_children(
    choice: SessionTreeChoice,
    choices: Sequence[SessionTreeChoice],
) -> bool:
    return any(candidate.parent_entry_id == choice.entry_id for candidate in choices)


def _tree_choice_is_branch_foldable(
    choice: SessionTreeChoice,
    choices: Sequence[SessionTreeChoice],
    *,
    source_choices: Sequence[SessionTreeChoice] | None = None,
) -> bool:
    children_by_parent, parent_by_id = _visible_tree_relationships(
        choices,
        source_choices=source_choices,
    )
    if not children_by_parent.get(choice.entry_id):
        return False
    parent_id = parent_by_id.get(choice.entry_id)
    if parent_id is None:
        return True
    return len(children_by_parent.get(parent_id, ())) > 1


def _tree_branch_segment_index(
    choices: Sequence[SessionTreeChoice],
    selected_index: int,
    *,
    direction: Literal["up", "down"],
    source_choices: Sequence[SessionTreeChoice] | None = None,
) -> int:
    if selected_index < 0 or selected_index >= len(choices):
        return 0
    children_by_parent, parent_by_id = _visible_tree_relationships(
        choices,
        source_choices=source_choices,
    )
    index_by_id = {choice.entry_id: index for index, choice in enumerate(choices)}
    current_id = choices[selected_index].entry_id

    if direction == "down":
        while True:
            children = children_by_parent.get(current_id, ())
            if not children:
                return index_by_id[current_id]
            if len(children) > 1:
                return index_by_id[children[0]]
            current_id = children[0]

    while True:
        parent_id = parent_by_id.get(current_id)
        if parent_id is None:
            return index_by_id[current_id]
        siblings = children_by_parent.get(parent_id, ())
        current_index = index_by_id[current_id]
        if len(siblings) > 1 and current_index < selected_index:
            return current_index
        current_id = parent_id


def _visible_tree_relationships(
    choices: Sequence[SessionTreeChoice],
    *,
    source_choices: Sequence[SessionTreeChoice] | None = None,
) -> tuple[dict[str | None, tuple[str, ...]], dict[str, str | None]]:
    visible_ids = {choice.entry_id for choice in choices}
    source_parent_by_id = {
        choice.entry_id: choice.parent_entry_id for choice in (source_choices or choices)
    }
    children_by_parent_lists: dict[str | None, list[str]] = {None: []}
    parent_by_id: dict[str, str | None] = {}

    for choice in choices:
        parent_id = choice.parent_entry_id
        seen: set[str] = set()
        while parent_id is not None and parent_id not in visible_ids and parent_id not in seen:
            seen.add(parent_id)
            parent_id = source_parent_by_id.get(parent_id)
        if parent_id not in visible_ids:
            parent_id = None
        parent_by_id[choice.entry_id] = parent_id
        children_by_parent_lists.setdefault(parent_id, []).append(choice.entry_id)

    return (
        {parent_id: tuple(child_ids) for parent_id, child_ids in children_by_parent_lists.items()},
        parent_by_id,
    )


def _tree_choice_has_folded_ancestor(
    choice: SessionTreeChoice,
    *,
    choices_by_id: dict[str, SessionTreeChoice],
    folded_entry_ids: set[str],
) -> bool:
    parent_id = choice.parent_entry_id
    seen: set[str] = set()
    while parent_id is not None and parent_id not in seen:
        if parent_id in folded_entry_ids:
            return True
        seen.add(parent_id)
        parent = choices_by_id.get(parent_id)
        if parent is None:
            return False
        parent_id = parent.parent_entry_id
    return False


def _tree_picker_label(
    choice: SessionTreeChoice,
    *,
    theme: TuiTheme,
    show_label_timestamps: bool = False,
    highlighted: bool = False,
) -> Text:
    marker = "* " if choice.active else "  "
    label = choice.label
    indent_width = len(label) - len(label.lstrip(" "))
    indent = label[:indent_width]
    body = label[indent_width:]
    author, separator, rest = body.partition(":")
    text = Text(f"{marker}{indent}")
    accent = theme.highlight_text if highlighted else theme.accent
    if choice.tree_label:
        text.append(f"[{choice.tree_label}] ", style=accent)
        if show_label_timestamps and choice.tree_label_timestamp is not None:
            text.append(f"{_session_updated_at_label(choice.tree_label_timestamp)} ")
    if separator:
        text.append(author, style=accent)
        text.append(f"{separator}{rest}")
    else:
        text.append(body)
    return text


def _tree_picker_viewport_label(
    choice: SessionTreeChoice,
    *,
    theme: TuiTheme,
    show_label_timestamps: bool = False,
    selected: bool = False,
    viewport_width: int = 0,
) -> Text:
    label = _tree_picker_label(
        choice,
        theme=theme,
        show_label_timestamps=show_label_timestamps,
        highlighted=selected,
    )
    if not selected or viewport_width <= 0 or label.cell_len <= viewport_width:
        return label

    marker_width = 2
    plain = label.plain
    gutter = plain[:marker_width]
    body = plain[marker_width:]
    body_width = max(0, viewport_width - marker_width)
    anchor_col = _tree_label_anchor_col(body)
    min_visible_anchor = min(20, max(4, body_width // 3))
    if anchor_col <= body_width - min_visible_anchor:
        return _right_crop_text(label, viewport_width)

    anchor_context = min(12, max(2, body_width // 4))
    scroll = max(0, anchor_col - anchor_context)
    viewport_body = _slice_cells(body, scroll, body_width)
    if scroll:
        viewport_body = f"...{viewport_body[3:]}" if cell_len(viewport_body) > 3 else "..."
    return Text(f"{gutter}{viewport_body}")


def _right_crop_text(text: Text, width: int) -> Text:
    cropped = text.copy()
    cropped.truncate(width, overflow="crop")
    return cropped


def _tree_label_anchor_col(body: str) -> int:
    leading_spaces = len(body) - len(body.lstrip(" "))
    return cell_len(body[:leading_spaces])


def _slice_cells(value: str, start: int, width: int) -> str:
    if width <= 0:
        return ""
    end = start + width
    parts: list[str] = []
    cursor = 0
    for character in value:
        character_width = cell_len(character)
        next_cursor = cursor + character_width
        if next_cursor > start and cursor < end:
            parts.append(character)
        cursor = next_cursor
        if cursor >= end:
            break
    return "".join(parts)


def _user_message_picker_label(choice: SessionTreeChoice, index: int, total: int) -> str:
    preview = " ".join((choice.copy_text or choice.label).split())
    if preview.startswith("user:"):
        preview = preview.partition(":")[2].strip()
    if len(preview) > 72:
        preview = f"{preview[:69]}..."
    return f"Message {index + 1} of {total}: {preview}"


def _workflow_picker_label(workflow: WorkflowDefinition) -> str:
    runtime = _workflow_runtime_label(workflow)
    return (
        f"{workflow.workflow_id}: {workflow.title}\n"
        f"  {workflow.summary}\n"
        f"  topology: {workflow.topology} - runtime: {runtime}\n"
        f"  result: {workflow.result_schema} via {workflow.result_node_id}"
    )


def _workflow_run_terminal_command(workflow: WorkflowDefinition, *, cwd: Path) -> str:
    run_dir = cwd / ".tau" / "workflow-runs" / _workflow_run_directory_name(workflow.workflow_id)
    parts = [
        "uv",
        "run",
        "tau",
        "workflows",
        "run",
        workflow.workflow_id,
        "--repo",
        str(cwd),
    ]
    if workflow.workflow_id != "tau-operator-reference":
        parts.extend(["--goal", f"Run {workflow.title} for {cwd}"])
    parts.extend(["--run-dir", str(run_dir)])
    if workflow.workflow_id in {"approved-release-bundle", "durable-repository-qualification"}:
        parts.extend(["--publish-path", str(run_dir / "publish")])
    parts.append("--open-viewer")
    parts.extend(["--viewer-hold-seconds", "120"])
    return shlex.join(parts)


def _terminal_command_transcript_title(command: str) -> str:
    return f"$ {command.strip()} (Ctrl+O to expand)"


def _workflow_runtime_label(workflow: WorkflowDefinition) -> str:
    if workflow.runtime == {
        "local": True,
        "network_required": False,
        "provider_required": False,
        "mutation_allowed": False,
    }:
        return "local, no network/provider, read-only inputs"
    return ", ".join(f"{key}={value}" for key, value in sorted(workflow.runtime.items()))


def _workflow_run_directory_name(workflow_id: str) -> str:
    return f"{workflow_id}-{datetime.now().strftime('%Y%m%dT%H%M%S')}"


def _format_workflow_terminal_output(output: str) -> str | None:
    try:
        payload = json.loads(output.strip())
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    workflow_id = payload.get("workflow_id")
    schema = payload.get("schema")
    if not isinstance(workflow_id, str) or schema != "tau.workflow_run_receipt.v1":
        return None
    lines = ["Tau workflow receipt", f"workflow: {workflow_id}"]
    status = payload.get("status")
    if isinstance(status, str):
        lines.append(f"status: {status}")
    result = payload.get("result")
    if isinstance(result, dict) and isinstance(result.get("status"), str):
        lines.append(f"result: {result['status']}")
    run_dir = payload.get("run_dir")
    if isinstance(run_dir, str):
        lines.append(f"run dir: {run_dir}")
    receipt_path = payload.get("run_receipt_path")
    if isinstance(receipt_path, str):
        lines.append(f"receipt: {receipt_path}")
    viewer = payload.get("viewer")
    if isinstance(viewer, dict):
        command = viewer.get("command")
        url = viewer.get("url")
        if isinstance(command, list) and all(isinstance(part, str) for part in command):
            lines.append(f"viewer command: {shlex.join(command)}")
        if isinstance(url, str) and url:
            lines.append(f"viewer url: {url}")
    if payload.get("ok") is not True:
        lines.append("next: inspect the workflow receipt")
        if isinstance(run_dir, str):
            lines.append(f"approve command: uv run tau workflows approve {shlex.quote(run_dir)}")
            lines.append(f"resume command: uv run tau workflows resume {shlex.quote(run_dir)}")
    lines.extend(["", "Raw output:", output.strip()])
    return "\n".join(lines)


def _workflow_terminal_run_dir(output: str) -> Path | None:
    """Return the run directory from a workflow receipt emitted by a terminal command."""
    try:
        payload = json.loads(output.strip())
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    if payload.get("schema") != "tau.workflow_run_receipt.v1":
        return None
    run_dir = payload.get("run_dir")
    if not isinstance(run_dir, str) or not run_dir.strip():
        return None
    return Path(run_dir).expanduser()


def _build_tui_dag_status_snapshot(run_dir: Path) -> dict[str, Any]:
    """Build the TUI status payload from the shared DAG viewer projection."""
    resolved_run_dir = run_dir.expanduser().resolve()
    replay, events = load_dag_replay(run_dir=resolved_run_dir)
    return build_dag_live_snapshot(
        replay=replay,
        recent_events=events,
        receipt_index=build_receipt_index(resolved_run_dir, replay.transition_receipts),
    )


def _dag_viewer_launch_command(link_payload: Mapping[str, object]) -> tuple[str, ...]:
    """Return the single launch command produced by build_dag_viewer_link."""
    dag_viewer = link_payload.get("dag_viewer")
    if not isinstance(dag_viewer, Mapping):
        raise RuntimeError("dag_viewer_link_missing_summary")
    command = dag_viewer.get("launch_command")
    if command is None:
        commands = dag_viewer.get("launch_commands")
        if isinstance(commands, list) and len(commands) == 1:
            command = commands[0]
        elif isinstance(commands, list) and len(commands) > 1:
            raise RuntimeError("dag_viewer_run_id_required")
    if not isinstance(command, list) or not all(isinstance(part, str) for part in command):
        raise RuntimeError("dag_viewer_launch_command_missing")
    return tuple(command)


def _dag_viewer_launch_target(command: Sequence[str]) -> tuple[Path, str | None]:
    """Decode the run directory and run id from the existing dag-view launch command."""
    if len(command) < 4 or command[0] != "tau" or command[1] != "dag-view":
        raise RuntimeError("dag_viewer_launch_command_invalid")
    run_dir: Path | None = None
    run_id: str | None = None
    index = 2
    while index < len(command):
        option = command[index]
        if option not in {"--run-dir", "--run-id"}:
            raise RuntimeError("dag_viewer_launch_command_invalid")
        if index + 1 >= len(command):
            raise RuntimeError("dag_viewer_launch_command_invalid")
        value = command[index + 1]
        if option == "--run-dir":
            run_dir = Path(value).expanduser().resolve()
        else:
            run_id = value
        index += 2
    if run_dir is None:
        raise RuntimeError("dag_viewer_launch_command_missing_run_dir")
    return run_dir, run_id


def _dag_viewer_node_target(run_dir: Path) -> str | None:
    """Return the active or blocked node id from a DAG current-state file."""
    path = run_dir.expanduser().resolve() / "current-state.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    active_node_id = payload.get("active_node_id")
    if isinstance(active_node_id, str) and active_node_id.strip():
        return active_node_id
    blocked_nodes = payload.get("blocked_nodes")
    if isinstance(blocked_nodes, list):
        for item in blocked_nodes:
            if isinstance(item, str) and item.strip():
                return item
            if isinstance(item, dict):
                node_id = item.get("node_id")
                if isinstance(node_id, str) and node_id.strip():
                    return node_id
    return None


def _dag_viewer_url_with_node(url: str, node_id: str | None) -> str:
    """Append viewer query state that filters and selects the current node."""
    if not node_id:
        return url
    parsed = urlparse(url)
    values = dict(parse_qsl(parsed.query, keep_blank_values=True))
    values.update(
        {
            "filter_kind": "NODE",
            "filter_q": node_id,
            "entity_kind": "NODE",
            "node_id": node_id,
        }
    )
    return urlunparse(parsed._replace(query=urlencode(values)))


def _dag_viewer_unavailable_message(
    link_payload: Mapping[str, object],
    run_dir: Path,
) -> str:
    """Format a clear TUI message when the viewer link cannot be resolved."""
    status = link_payload.get("status")
    reason = status if isinstance(status, str) and status else "MISSING"
    dag_viewer = link_payload.get("dag_viewer")
    if isinstance(dag_viewer, Mapping):
        store_error = dag_viewer.get("store_error")
        source = dag_viewer.get("source")
        if isinstance(store_error, str) and store_error:
            reason = store_error
        elif isinstance(source, str) and source:
            reason = f"{reason} ({source})"
    return f"DAG viewer unavailable for {run_dir}: {reason}"


def _active_tree_choice_index(choices: Sequence[SessionTreeChoice]) -> int:
    return _tree_choice_index(choices, None)


def _active_tree_choice_id(choices: Sequence[SessionTreeChoice]) -> str | None:
    for choice in choices:
        if choice.active:
            return choice.entry_id
    return None


def _nearest_visible_tree_choice_index(
    visible_choices: Sequence[SessionTreeChoice],
    source_choices: Sequence[SessionTreeChoice],
    entry_id: str | None,
) -> int | None:
    if not visible_choices:
        return None
    target_entry_id = entry_id or _active_tree_choice_id(source_choices)
    visible_index_by_id = {choice.entry_id: index for index, choice in enumerate(visible_choices)}
    if target_entry_id is not None:
        source_parent_by_id = {choice.entry_id: choice.parent_entry_id for choice in source_choices}
        current_id: str | None = target_entry_id
        seen: set[str] = set()
        while current_id is not None and current_id not in seen:
            visible_index = visible_index_by_id.get(current_id)
            if visible_index is not None:
                return visible_index
            seen.add(current_id)
            current_id = source_parent_by_id.get(current_id)
        return len(visible_choices) - 1
    return _tree_choice_index(visible_choices, None)


def _tree_choice_index(choices: Sequence[SessionTreeChoice], entry_id: str | None) -> int:
    if entry_id is not None:
        for index, choice in enumerate(choices):
            if choice.entry_id == entry_id:
                return index
    for index, choice in enumerate(choices):
        if choice.active:
            return index
    return 0


def _session_updated_at_label(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M")


def _named_session_title(title: str | None) -> str | None:
    if title is None:
        return None
    stripped = title.strip()
    if not stripped or stripped.lower() == "untitled session":
        return None
    return stripped


def _login_provider_label(provider: ProviderCatalogEntry) -> str:
    status = _login_provider_status_label(provider)
    auth_type = _login_provider_auth_type_label(provider)
    return f"{provider.display_name} [{auth_type}]\n  {provider.name} - {status}"


def _login_provider_empty_label(screen: LoginProviderPickerScreen) -> str:
    if not screen.providers:
        return "No login providers available"
    if screen.search_value:
        return f'No providers match "{screen.search_value}"'
    return "No matching providers"


def _login_provider_auth_type_label(provider: ProviderCatalogEntry) -> str:
    if provider.kind == "openai-codex":
        return "subscription"
    return "API key"


def _login_provider_status_label(provider: ProviderCatalogEntry) -> str:
    try:
        config = provider_config_from_catalog_entry(provider.name)
        return _provider_credential_status_label(config, FileCredentialStore())
    except Exception:  # noqa: BLE001 - auth status should not prevent opening the picker
        return "status unavailable"


def _provider_credential_status_label(
    provider: ProviderConfig,
    credential_store: FileCredentialStore,
) -> str:
    """Return a redacted credential source label for provider pickers."""
    credential_name = getattr(provider, "credential_name", None)
    if credential_name:
        get_oauth = getattr(credential_store, "get_oauth", None)
        if callable(get_oauth) and get_oauth(credential_name) is not None:
            return "stored OAuth"
        if credential_store.get(credential_name):
            return "stored credential"

    if provider.name == "anthropic" and os.environ.get("ANTHROPIC_AUTH_TOKEN"):
        return "env: ANTHROPIC_AUTH_TOKEN"

    api_key_env = getattr(provider, "api_key_env", "")
    if api_key_env and os.environ.get(api_key_env):
        return f"env: {api_key_env}"

    return "unconfigured"


def _filter_login_providers(
    providers: Sequence[ProviderCatalogEntry],
    query: str,
) -> tuple[ProviderCatalogEntry, ...]:
    tokens = _query_tokens(query)
    if not tokens:
        return tuple(providers)
    return tuple(
        provider
        for provider in providers
        if _query_tokens_match(tokens, f"{provider.name} {provider.display_name}")
    )


def _subscription_login_providers(
    providers: Sequence[ProviderCatalogEntry],
) -> tuple[ProviderCatalogEntry, ...]:
    return tuple(provider for provider in providers if provider.kind == "openai-codex")


def _api_key_login_providers(
    providers: Sequence[ProviderCatalogEntry],
) -> tuple[ProviderCatalogEntry, ...]:
    return tuple(provider for provider in providers if provider.kind != "openai-codex")


def _stored_credential_providers(
    providers: Sequence[ProviderCatalogEntry],
) -> tuple[ProviderCatalogEntry, ...]:
    credential_store = FileCredentialStore()
    return tuple(
        provider
        for provider in providers
        if _credential_store_has_entry(credential_store, provider.credential_name)
    )


def _credential_store_has_entry(
    credential_store: FileCredentialStore,
    credential_name: str,
) -> bool:
    return (
        credential_store.get(credential_name) is not None
        or credential_store.get_oauth(credential_name) is not None
    )


def _is_anthropic_subscription_auth_key(api_key: str | None) -> bool:
    return isinstance(api_key, str) and api_key.startswith(ANTHROPIC_SUBSCRIPTION_AUTH_PREFIX)


def _anthropic_subscription_auth_active(
    *,
    saved_api_key: str | None = None,
    credential_store: FileCredentialStore | None = None,
    env: Mapping[str, str] = os.environ,
) -> bool:
    """Return whether Tau's active Anthropic auth source is subscription-style."""
    runtime_api_key = env.get(RUNTIME_API_KEY_ENV)
    if runtime_api_key:
        return _is_anthropic_subscription_auth_key(runtime_api_key)

    if saved_api_key:
        return _is_anthropic_subscription_auth_key(saved_api_key)

    try:
        credential = (credential_store or FileCredentialStore()).get("anthropic")
    except Exception:  # noqa: BLE001 - warning-only checks must not block the TUI
        credential = None
    if credential:
        return _is_anthropic_subscription_auth_key(credential)

    if env.get(ANTHROPIC_AUTH_TOKEN_ENV):
        return True

    return _is_anthropic_subscription_auth_key(env.get("ANTHROPIC_API_KEY"))


def _login_success_message(entry: ProviderCatalogEntry, session: CodingSession) -> str:
    provider_name = getattr(session, "provider_name", entry.name)
    model = getattr(session, "model", None)
    if isinstance(model, str) and model:
        return f"Saved login for {entry.display_name}. Selected {provider_name}:{model}."
    return f"Saved login for {entry.display_name}."


def _theme_picker_choices() -> tuple[str, ...]:
    return (*available_tui_theme_names(), DEFAULT_AUTOMATIC_TUI_THEME_SETTING)


def _theme_picker_label(theme_setting: str, *, current_theme: str) -> str:
    marker = "✓" if theme_setting == current_theme else " "
    if theme_setting == DEFAULT_AUTOMATIC_TUI_THEME_SETTING:
        return f"{marker} automatic ({theme_setting})"
    return f"{marker} {theme_setting}"


def _settings_picker_items(settings: TuiSettings) -> tuple[SettingsPickerItem, ...]:
    return (
        SettingsPickerItem(
            key="theme",
            label="Theme",
            value=settings.theme,
            description="Color theme for the interface",
        ),
        SettingsPickerItem(
            key="auto_compact",
            label="Auto-compact",
            value="on" if settings.auto_compact else "off",
            description="Automatically compact context when the session approaches its limit",
        ),
        SettingsPickerItem(
            key="steering_mode",
            label="Steering mode",
            value=settings.steering_mode,
            description="How queued steering messages are drained into running turns",
        ),
        SettingsPickerItem(
            key="follow_up_mode",
            label="Follow-up mode",
            value=settings.follow_up_mode,
            description="How queued follow-up prompts are submitted after a turn",
        ),
        SettingsPickerItem(
            key="http_idle_timeout_ms",
            label="HTTP idle timeout",
            value=_format_http_idle_timeout_ms(settings.http_idle_timeout_ms),
            description="Provider HTTP stream idle timeout for future model calls",
        ),
        SettingsPickerItem(
            key="sidebar_position",
            label="Sidebar",
            value=settings.sidebar_position,
            description="Where session context appears in wide terminals",
        ),
        SettingsPickerItem(
            key="block_images",
            label="Block images",
            value="on" if settings.block_images else "off",
            description="Prevent clipboard and prompt images from being sent to providers",
        ),
        SettingsPickerItem(
            key="show_images",
            label="Show images",
            value="on" if settings.show_images else "off",
            description="Render image tool results inline when the terminal supports images",
        ),
        SettingsPickerItem(
            key="image_width_cells",
            label="Image width",
            value=str(settings.image_width_cells),
            description="Preferred inline image width in terminal cells",
        ),
        SettingsPickerItem(
            key="enable_skill_commands",
            label="Skill commands",
            value="on" if settings.enable_skill_commands else "off",
            description="Allow skills to register slash commands",
        ),
        SettingsPickerItem(
            key="show_hardware_cursor",
            label="Show hardware cursor",
            value="on" if settings.show_hardware_cursor else "off",
            description="Show the terminal cursor while preserving IME positioning",
        ),
        SettingsPickerItem(
            key="editor_padding_x",
            label="Editor padding",
            value=str(settings.editor_padding_x),
            description="Horizontal padding for the prompt editor",
        ),
        SettingsPickerItem(
            key="output_padding_x",
            label="Output padding",
            value=str(settings.output_padding_x),
            description="Horizontal padding for transcript output",
        ),
        SettingsPickerItem(
            key="autocomplete_max_visible",
            label="Autocomplete max items",
            value=str(settings.autocomplete_max_visible),
            description="Maximum visible rows in autocomplete suggestions",
        ),
        SettingsPickerItem(
            key="clear_on_shrink",
            label="Clear on shrink",
            value="on" if settings.clear_on_shrink else "off",
            description="Clear empty rows when transcript content shrinks",
        ),
        SettingsPickerItem(
            key="show_terminal_progress",
            label="Terminal progress",
            value="on" if settings.show_terminal_progress else "off",
            description="Emit terminal progress indicators while Tau is running",
        ),
        SettingsPickerItem(
            key="anthropic_extra_usage_warning",
            label="Anthropic extra usage",
            value="on" if settings.anthropic_extra_usage_warning else "off",
            description="Warn when Anthropic subscription auth may use paid extra usage",
        ),
        SettingsPickerItem(
            key="auto_copy_selection",
            label="Auto-copy selection",
            value="on" if settings.auto_copy_selection else "off",
            description="Copy selected transcript text to the clipboard automatically",
        ),
        SettingsPickerItem(
            key="external_editor",
            label="External editor",
            value=settings.external_editor or "VISUAL/EDITOR",
            description=(
                "Command used by the prompt editor action; blank falls back to VISUAL or EDITOR"
            ),
        ),
        SettingsPickerItem(
            key="hide_thinking",
            label="Hide thinking",
            value="on" if settings.hide_thinking else "off",
            description="Hide streamed thinking tokens behind a status placeholder",
        ),
        SettingsPickerItem(
            key="thinking_level",
            label="Thinking level",
            value=settings.thinking_level,
            description="Reasoning depth for thinking-capable models",
        ),
        SettingsPickerItem(
            key="double_escape_action",
            label="Double Escape",
            value=settings.double_escape_action,
            description="Action to take when Escape is pressed twice on an empty prompt",
        ),
        SettingsPickerItem(
            key="tree_filter_mode",
            label="Tree filter mode",
            value=settings.tree_filter_mode,
            description="Default filter used by the session tree picker",
        ),
        SettingsPickerItem(
            key="default_project_trust",
            label="Default project trust",
            value=settings.default_project_trust,
            description="Fallback trust policy when no saved project decision exists",
        ),
        SettingsPickerItem(
            key="quiet_startup",
            label="Quiet startup",
            value="on" if settings.quiet_startup else "off",
            description="Suppress startup notifications from the TUI",
        ),
        SettingsPickerItem(
            key="collapse_changelog",
            label="Collapse changelog",
            value="on" if settings.collapse_changelog else "off",
            description="Prefer condensed changelog notifications after updates",
        ),
        SettingsPickerItem(
            key="turn_notification",
            label="Turn notification",
            value=settings.turn_notification,
            description="Request terminal attention when a Tau turn finishes in the background",
        ),
        SettingsPickerItem(
            key="auto_resize_images",
            label="Auto-resize images",
            value="on" if settings.auto_resize_images else "off",
            description="Resize large images before they are sent to providers",
        ),
    )


def _settings_picker_label(item: SettingsPickerItem) -> str:
    return f"{item.label}: {item.value}"


def _settings_picker_empty_label(screen: SettingsPickerScreen) -> str:
    if screen.search_value:
        return f'No settings match "{screen.search_value}"'
    return "No settings available"


def _thinking_picker_label(level: ThinkingLevel, current_level: str) -> str:
    marker = "current" if level == current_level else "       "
    description = THINKING_LEVEL_DESCRIPTIONS.get(level, "")
    return f"{marker}  {level} - {description}" if description else f"{marker}  {level}"


def _image_visibility_picker_label(show_images: bool, *, current_value: bool) -> str:
    marker = "current" if show_images == current_value else "       "
    label = "Yes" if show_images else "No"
    description = (
        "Show images inline in terminal" if show_images else "Show text placeholder instead"
    )
    return f"{marker}  {label} - {description}"


def _first_time_setup_choices() -> tuple[FirstTimeSetupChoice, ...]:
    choices = [
        FirstTimeSetupChoice(
            label=_theme_setup_label(theme_name),
            value=theme_name,
            description="Use this theme",
        )
        for theme_name in available_tui_theme_names()
    ]
    choices.append(
        FirstTimeSetupChoice(
            label="Skip setup",
            value=None,
            description="Keep the current default",
        )
    )
    return tuple(choices)


def _first_time_setup_selected_index(
    choices: Sequence[FirstTimeSetupChoice],
    current_theme: str,
) -> int:
    for index, choice in enumerate(choices):
        if choice.value == current_theme:
            return index
    return 0


def _theme_setup_label(theme_name: str) -> str:
    return theme_name.replace("-", " ").title()


def _filter_settings_picker_items(
    items: Sequence[SettingsPickerItem],
    query: str,
) -> tuple[SettingsPickerItem, ...]:
    tokens = _query_tokens(query)
    if not tokens:
        return tuple(items)
    return tuple(
        item
        for item in items
        if _query_tokens_match(tokens, f"{item.label} {item.value} {item.key} {item.description}")
    )


def _next_queue_drain_mode(mode: TuiQueueDrainMode) -> TuiQueueDrainMode:
    return "all" if mode == "one-at-a-time" else "one-at-a-time"


def _format_http_idle_timeout_ms(timeout_ms: int) -> str:
    if timeout_ms == 0:
        return "disabled"
    if timeout_ms % 1000 == 0:
        timeout_s = timeout_ms // 1000
        if timeout_s % 60 == 0:
            timeout_minutes = timeout_s // 60
            return f"{timeout_minutes}m"
        return f"{timeout_s}s"
    return f"{timeout_ms}ms"


def _provider_timeout_seconds_from_http_idle_timeout_ms(timeout_ms: int) -> float:
    if timeout_ms == 0:
        # Match Pi's practical "disabled" transport timeout ceiling for JS timers.
        return 2_147_483_647 / 1000
    return timeout_ms / 1000


def _extension_ui_timeout_seconds(value: object) -> float | None:
    if value is None:
        return None
    try:
        timeout_seconds = float(value)
    except (TypeError, ValueError):
        return None
    if timeout_seconds <= 0:
        return None
    return timeout_seconds


def _agent_queue_mode_from_tui(mode: TuiQueueDrainMode) -> Literal["one_at_a_time", "all"]:
    return "one_at_a_time" if mode == "one-at-a-time" else "all"


def _project_trust_decision_label(decision: ProjectTrustStoreEntry | None) -> str:
    if decision is None:
        return "none"
    label = "trusted" if decision.decision else "untrusted"
    return f"{label} ({decision.path})"


def _project_trust_session_label(state: ProjectTrustState) -> str:
    return "trusted" if state.project_trusted else "untrusted"


def _project_trust_option_label(
    option: ProjectTrustOption,
    saved_decision: ProjectTrustStoreEntry | None,
) -> str:
    marker = (
        "✓ "
        if option.saved_path is not None
        and saved_decision is not None
        and option.saved_path == saved_decision.path
        and option.trusted == saved_decision.decision
        else "  "
    )
    return f"{marker}{option.label}"


def _project_trust_saved_option_index(state: ProjectTrustState) -> int:
    """Return the option index matching the saved project trust decision."""
    saved_decision = state.saved_decision
    if saved_decision is None:
        return 0
    for index, option in enumerate(state.options):
        if (
            option.saved_path is not None
            and option.saved_path == saved_decision.path
            and option.trusted == saved_decision.decision
        ):
            return index
    return 0


def _next_tui_settings(
    settings: TuiSettings,
    key: SettingsPickerKey,
    *,
    thinking_levels: Sequence[ThinkingLevel] = THINKING_LEVELS,
) -> TuiSettings:
    if key == "theme":
        try:
            current_index = _theme_picker_choices().index(settings.theme)
        except ValueError:
            current_index = -1
        choices = _theme_picker_choices()
        next_theme = choices[(current_index + 1) % len(choices)]
        return replace(settings, theme=next_theme)
    if key == "auto_compact":
        return replace(settings, auto_compact=not settings.auto_compact)
    if key == "steering_mode":
        return replace(settings, steering_mode=_next_queue_drain_mode(settings.steering_mode))
    if key == "follow_up_mode":
        return replace(settings, follow_up_mode=_next_queue_drain_mode(settings.follow_up_mode))
    if key == "http_idle_timeout_ms":
        try:
            current_index = HTTP_IDLE_TIMEOUT_MS_CHOICES.index(settings.http_idle_timeout_ms)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            http_idle_timeout_ms=HTTP_IDLE_TIMEOUT_MS_CHOICES[
                (current_index + 1) % len(HTTP_IDLE_TIMEOUT_MS_CHOICES)
            ],
        )
    if key == "sidebar_position":
        sidebar_positions = ("right", "left", "off")
        try:
            current_index = sidebar_positions.index(settings.sidebar_position)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            sidebar_position=sidebar_positions[(current_index + 1) % len(sidebar_positions)],
        )
    if key == "default_project_trust":
        default_project_trust_choices: tuple[DefaultProjectTrust, ...] = (
            "ask",
            "always",
            "never",
        )
        try:
            current_index = default_project_trust_choices.index(settings.default_project_trust)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            default_project_trust=default_project_trust_choices[
                (current_index + 1) % len(default_project_trust_choices)
            ],
        )
    if key == "autocomplete_max_visible":
        try:
            current_index = AUTOCOMPLETE_MAX_VISIBLE_CHOICES.index(
                settings.autocomplete_max_visible
            )
        except ValueError:
            current_index = -1
        return replace(
            settings,
            autocomplete_max_visible=AUTOCOMPLETE_MAX_VISIBLE_CHOICES[
                (current_index + 1) % len(AUTOCOMPLETE_MAX_VISIBLE_CHOICES)
            ],
        )
    if key == "auto_resize_images":
        return replace(settings, auto_resize_images=not settings.auto_resize_images)
    if key == "block_images":
        return replace(settings, block_images=not settings.block_images)
    if key == "show_images":
        return replace(settings, show_images=not settings.show_images)
    if key == "image_width_cells":
        try:
            current_index = IMAGE_WIDTH_CELL_CHOICES.index(settings.image_width_cells)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            image_width_cells=IMAGE_WIDTH_CELL_CHOICES[
                (current_index + 1) % len(IMAGE_WIDTH_CELL_CHOICES)
            ],
        )
    if key == "enable_skill_commands":
        return replace(settings, enable_skill_commands=not settings.enable_skill_commands)
    if key == "show_hardware_cursor":
        return replace(settings, show_hardware_cursor=not settings.show_hardware_cursor)
    if key == "editor_padding_x":
        try:
            current_index = EDITOR_PADDING_X_CHOICES.index(settings.editor_padding_x)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            editor_padding_x=EDITOR_PADDING_X_CHOICES[
                (current_index + 1) % len(EDITOR_PADDING_X_CHOICES)
            ],
        )
    if key == "output_padding_x":
        try:
            current_index = OUTPUT_PADDING_X_CHOICES.index(settings.output_padding_x)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            output_padding_x=OUTPUT_PADDING_X_CHOICES[
                (current_index + 1) % len(OUTPUT_PADDING_X_CHOICES)
            ],
        )
    if key == "show_terminal_progress":
        return replace(settings, show_terminal_progress=not settings.show_terminal_progress)
    if key == "anthropic_extra_usage_warning":
        return replace(
            settings,
            anthropic_extra_usage_warning=not settings.anthropic_extra_usage_warning,
        )
    if key == "clear_on_shrink":
        return replace(settings, clear_on_shrink=not settings.clear_on_shrink)
    if key == "quiet_startup":
        return replace(settings, quiet_startup=not settings.quiet_startup)
    if key == "collapse_changelog":
        return replace(settings, collapse_changelog=not settings.collapse_changelog)
    if key == "turn_notification":
        modes = ("desktop", "bell", "off")
        try:
            current_index = modes.index(settings.turn_notification)
        except ValueError:
            current_index = -1
        return replace(settings, turn_notification=modes[(current_index + 1) % len(modes)])
    if key == "auto_copy_selection":
        return replace(settings, auto_copy_selection=not settings.auto_copy_selection)
    if key == "hide_thinking":
        return replace(settings, hide_thinking=not settings.hide_thinking)
    if key == "thinking_level":
        available = tuple(level for level in thinking_levels if level in THINKING_LEVELS)
        return replace(
            settings,
            thinking_level=next_thinking_level(
                settings.thinking_level,
                available=available or THINKING_LEVELS,
            ),
        )
    if key == "double_escape_action":
        double_escape_actions: tuple[Literal["tree", "fork", "none"], ...] = (
            "tree",
            "fork",
            "none",
        )
        try:
            current_index = double_escape_actions.index(settings.double_escape_action)
        except ValueError:
            current_index = -1
        return replace(
            settings,
            double_escape_action=double_escape_actions[
                (current_index + 1) % len(double_escape_actions)
            ],
        )
    try:
        current_index = TREE_FILTER_MODES.index(cast(TreeFilterMode, settings.tree_filter_mode))
    except ValueError:
        current_index = -1
    return replace(
        settings,
        tree_filter_mode=TREE_FILTER_MODES[(current_index + 1) % len(TREE_FILTER_MODES)],
    )


def _model_picker_label(
    choice: ModelChoice,
    *,
    current_model: str,
    current_provider: str,
    scoped: bool = False,
    unavailable: bool = False,
) -> str:
    marker = (
        "* "
        if (choice.provider_name == current_provider and choice.model == current_model)
        else "  "
    )
    suffix_parts = []
    if scoped:
        suffix_parts.append("scoped")
    if unavailable:
        suffix_parts.append("unavailable")
    suffix = f" [{', '.join(suffix_parts)}]" if suffix_parts else ""
    return f"{marker}{choice.provider_name}:{choice.model}{suffix}"


def _filter_model_choices(choices: Sequence[ModelChoice], query: str) -> tuple[ModelChoice, ...]:
    normalized = query.strip().lower()
    if not normalized:
        return tuple(choices)
    matches = [choice for choice in choices if _model_picker_choice_matches(choice, normalized)]
    return tuple(sorted(matches, key=lambda choice: _model_picker_search_rank(choice, normalized)))


def _model_picker_choice_matches(choice: ModelChoice, normalized_query: str) -> bool:
    search_text = _model_picker_search_text(choice)
    if normalized_query in search_text:
        return True
    return _query_tokens_match(_query_tokens(normalized_query), search_text)


def _model_picker_search_text(choice: ModelChoice) -> str:
    provider = choice.provider_name.lower()
    model = choice.model.lower()
    # Match Pi's model selector behavior: provider-prefixed references should
    # rank ahead of proxy-provider model IDs such as openrouter/openai/gpt-5.
    return f"{provider} {provider}/{model} {provider} {model}"


def _model_picker_search_rank(choice: ModelChoice, normalized_query: str) -> tuple[int, str, str]:
    provider = choice.provider_name.lower()
    model = choice.model.lower()
    reference = f"{provider}/{model}"
    if reference == normalized_query:
        rank = 0
    elif reference.startswith(normalized_query):
        rank = 1
    elif provider == normalized_query or model == normalized_query:
        rank = 2
    else:
        rank = 3
    return rank, provider, model


def _filter_workflow_picker_records(
    workflows: Sequence[WorkflowDefinition],
    query: str,
) -> tuple[WorkflowDefinition, ...]:
    tokens = _query_tokens(query)
    if not tokens:
        return tuple(workflows)
    return tuple(
        workflow
        for workflow in workflows
        if _query_tokens_match(tokens, _workflow_picker_search_text(workflow))
    )


def _workflow_picker_search_text(workflow: WorkflowDefinition) -> str:
    fields = [
        workflow.workflow_id,
        workflow.summary,
        workflow.topology,
        _workflow_picker_label(workflow),
    ]
    return " ".join(" ".join(field.casefold().split()) for field in fields)


def _command_message_uses_transcript(command_text: str) -> bool:
    """Return whether slash-command output should appear inline in the transcript."""
    command_name = command_text.split(maxsplit=1)[0].casefold()
    return command_name in {"/reload", "/system"}


def _command_message_uses_notification(command_text: str, message: str) -> bool:
    """Return whether slash-command output should appear as a notification."""
    command_name = command_text.split(maxsplit=1)[0].casefold()
    return command_name == "/name" and message.startswith("Session renamed: ")


def _debug_message_payload(message: AgentMessage) -> object:
    model_dump = getattr(message, "model_dump", None)
    if callable(model_dump):
        return model_dump(mode="json")
    return str(message)


def _is_reload_command_text(text: str) -> bool:
    return text.strip().casefold() == "/reload"


def _is_session_switch_command_text(text: str) -> bool:
    token = text.strip().split(maxsplit=1)[0].casefold()
    return token in {"/new", "/resume"}


def _is_extension_cancel_message(message: object) -> bool:
    return isinstance(message, str) and message.casefold().endswith("cancelled by extension.")


def _is_extension_command_text(session: CodingSession, text: str) -> bool:
    stripped = text.strip()
    if (
        not stripped.startswith("/")
        or stripped.startswith("//")
        or stripped.casefold().startswith("/skill:")
    ):
        return False
    token = stripped.split(maxsplit=1)[0].removeprefix("/")
    if ":" in token:
        return False
    command = _session_command_registry(session).get(token)
    source = getattr(command, "source", None)
    return isinstance(source, str) and source.startswith("extension:")


def _is_skill_command_text(text: str) -> bool:
    """Return whether submitted text starts with Tau's skill command prefix."""
    return text.strip().casefold().startswith("/skill:")


def _apply_prompt_padding(prompt: PromptInput, padding_x: int) -> None:
    """Apply Pi-style horizontal editor padding to Tau's prompt widget."""
    prompt.styles.padding = Spacing.unpack((0, padding_x))
    prompt.refresh(layout=True)


def _command_output_title(command_text: str) -> str:
    command_name = command_text.split(maxsplit=1)[0].removeprefix("/")
    return f"/{command_name or 'help'}"


def _command_output_renders_markdown(command_text: str) -> bool:
    command_name = command_text.split(maxsplit=1)[0].casefold()
    return command_name in {"/changelog", "/hotkeys"}


def _is_thinking_cycle_key(key: str, configured_key: str) -> bool:
    if _matches_configured_key(key, configured_key):
        return True
    return "shift+tab" in _configured_key_parts(configured_key) and key == "backtab"


def _matches_configured_key(key: str, configured_key: str) -> bool:
    return key in _configured_key_parts(configured_key)


def _export_result_message(
    path: Path,
    export_format: str | None,
    *,
    open_requested: bool = False,
) -> str:
    """Return durable TUI output for a completed session export."""
    resolved = path.expanduser()
    display_path = str(resolved)
    file_uri = resolved.resolve().as_uri()
    normalized_format = (resolved.suffix.removeprefix(".") or export_format or "html").lower()
    if normalized_format == "htm":
        normalized_format = "html"
    lines = [
        "Session exported.",
        "",
    ]
    if open_requested:
        lines.append("Open requested: yes")
    lines.extend(
        (
            f"Format: {normalized_format}",
            f"Path: {display_path}",
            f"Open: {file_uri}",
        )
    )
    if normalized_format == "html":
        lines.extend(
            (
                "",
                "The HTML export is the browser-readable transcript artifact for large "
                "Markdown, tables, and linked media.",
            )
        )
    return "\n".join(lines)


def _open_export_artifact(path: Path) -> bool:
    """Open an exported artifact through the default browser/default handler."""
    try:
        return bool(webbrowser.open(path.expanduser().resolve().as_uri()))
    except (OSError, ValueError):
        return False


def _visual_artifacts_from_state(
    state: TuiState,
    *,
    cwd: Path,
    session_id: str | None,
) -> tuple[VisualArtifact, ...]:
    """Collect local inspectable artifacts from the visible transcript state."""
    artifacts: list[VisualArtifact] = []
    seen: set[tuple[str, str]] = set()
    for item_index, item in enumerate(state.items, 1):
        for payload_index, payload in enumerate(
            _visual_payloads_for_chat_item(item, cwd=cwd),
            1,
        ):
            key = _visual_artifact_key(payload)
            if key in seen:
                continue
            path = _visual_artifact_path(
                payload,
                session_id=session_id,
                item_index=item_index,
                payload_index=payload_index,
            )
            if path is None:
                continue
            seen.add(key)
            artifacts.append(
                VisualArtifact(
                    title=_visual_artifact_title(item, payload),
                    path=path,
                    mime_type=payload.mime_type,
                    bytes=payload.bytes,
                    source=f"{item.role} item {item_index}",
                )
            )
        for path in _markdown_artifact_paths_for_chat_item(item, cwd=cwd):
            key = ("path", str(path))
            if key in seen:
                continue
            try:
                byte_count = path.stat().st_size
            except OSError:
                continue
            seen.add(key)
            artifacts.append(
                VisualArtifact(
                    title=path.name,
                    path=path,
                    mime_type=MARKDOWN_ARTIFACT_MIME_TYPES[path.suffix.lower()],
                    bytes=byte_count,
                    source=f"{item.role} item {item_index}",
                    preview_kind="markdown",
                )
            )
        for path in _json_artifact_paths_for_chat_item(item, cwd=cwd):
            key = ("path", str(path))
            if key in seen:
                continue
            try:
                byte_count = path.stat().st_size
            except OSError:
                continue
            seen.add(key)
            artifacts.append(
                VisualArtifact(
                    title=path.name,
                    path=path,
                    mime_type=JSON_ARTIFACT_MIME_TYPES[path.suffix.lower()],
                    bytes=byte_count,
                    source=f"{item.role} item {item_index}",
                    preview_kind="json",
                )
            )
        for path in _html_artifact_paths_for_chat_item(item, cwd=cwd):
            key = ("path", str(path))
            if key in seen:
                continue
            try:
                byte_count = path.stat().st_size
            except OSError:
                continue
            seen.add(key)
            artifacts.append(
                VisualArtifact(
                    title=path.name,
                    path=path,
                    mime_type=HTML_ARTIFACT_MIME_TYPES[path.suffix.lower()],
                    bytes=byte_count,
                    source=f"{item.role} item {item_index}",
                    preview_kind="html",
                )
            )
    return tuple(artifacts)


def _visual_payloads_for_chat_item(item: ChatItem, *, cwd: Path) -> tuple[ToolImagePayload, ...]:
    payloads: list[ToolImagePayload] = []
    if item.tool_images:
        payloads.extend(item.tool_images)
    elif item.tool_image is not None:
        payloads.append(item.tool_image)
    if item.role != "tool":
        payloads.extend(markdown_visual_payloads(item.text, base_path=cwd))
        if item.tool_result_text:
            payloads.extend(markdown_visual_payloads(item.tool_result_text, base_path=cwd))
    return tuple(payloads)


def _markdown_artifact_paths_for_chat_item(item: ChatItem, *, cwd: Path) -> tuple[Path, ...]:
    return _linked_artifact_paths_for_chat_item(
        item,
        cwd=cwd,
        mime_types=MARKDOWN_ARTIFACT_MIME_TYPES,
        max_bytes=MAX_MARKDOWN_ARTIFACT_BYTES,
    )


def _json_artifact_paths_for_chat_item(item: ChatItem, *, cwd: Path) -> tuple[Path, ...]:
    return _linked_artifact_paths_for_chat_item(
        item,
        cwd=cwd,
        mime_types=JSON_ARTIFACT_MIME_TYPES,
        max_bytes=MAX_JSON_ARTIFACT_BYTES,
    )


def _html_artifact_paths_for_chat_item(item: ChatItem, *, cwd: Path) -> tuple[Path, ...]:
    return _linked_artifact_paths_for_chat_item(
        item,
        cwd=cwd,
        mime_types=HTML_ARTIFACT_MIME_TYPES,
        max_bytes=MAX_HTML_ARTIFACT_BYTES,
    )


def _linked_artifact_paths_for_chat_item(
    item: ChatItem,
    *,
    cwd: Path,
    mime_types: Mapping[str, str],
    max_bytes: int,
) -> tuple[Path, ...]:
    paths: list[Path] = []
    seen: set[Path] = set()
    for text in (item.text, item.tool_result_text or ""):
        for path in _linked_artifact_paths(
            text,
            base_path=cwd,
            mime_types=mime_types,
            max_bytes=max_bytes,
        ):
            if path in seen:
                continue
            seen.add(path)
            paths.append(path)
    return tuple(paths)


def _linked_artifact_paths(
    markdown: str,
    *,
    base_path: Path,
    mime_types: Mapping[str, str],
    max_bytes: int,
) -> tuple[Path, ...]:
    paths: list[Path] = []
    for match in MARKDOWN_ARTIFACT_LINK_PATTERN.finditer(markdown):
        path = _artifact_link_target_path(match.group("target"), base_path=base_path)
        if path is None:
            continue
        if mime_types.get(path.suffix.lower()) is None:
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        if path.is_file() and 0 < stat.st_size <= max_bytes:
            paths.append(path)
    return tuple(paths)


def _artifact_link_target_path(target: str, *, base_path: Path) -> Path | None:
    cleaned = target.strip()
    if cleaned.startswith("<") and cleaned.endswith(">"):
        cleaned = cleaned[1:-1].strip()
    parsed = urlparse(cleaned)
    if parsed.scheme in {"http", "https", "data"}:
        return None
    if parsed.scheme == "file":
        raw_path = unquote(parsed.path)
    elif parsed.scheme:
        return None
    else:
        raw_path = unquote(cleaned.split("#", 1)[0].split("?", 1)[0])
    if not raw_path:
        return None
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = base_path / path
    return path.resolve()


def _json_artifact_summary_table(artifact: VisualArtifact, payload: object) -> Table:
    table = Table.grid(padding=(0, 2))
    table.add_column(style="bold")
    table.add_column()
    table.add_row("file", artifact.path.name)
    table.add_row("type", artifact.mime_type)
    table.add_row("size", _format_artifact_size(artifact.bytes))
    if isinstance(payload, Mapping):
        for key in (
            "schema",
            "status",
            "verdict",
            "ok",
            "workflow_id",
            "run_id",
            "node_id",
            "run_receipt_path",
        ):
            value = payload.get(key)
            if value is not None:
                table.add_row(key, _json_summary_value(value))
    return table


def _json_summary_value(value: object) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int | float):
        return str(value)
    return json.dumps(value, sort_keys=True)


@dataclass(frozen=True, slots=True)
class HtmlArtifactPreview:
    """Terminal-readable preview extracted from a local HTML artifact."""

    title: str
    markdown: str
    image_targets: tuple[str, ...] = ()


class HtmlArtifactPreviewParser(HTMLParser):
    """Extract visible text, headings, and table rows from a local HTML artifact."""

    _BLOCK_TAGS: ClassVar[set[str]] = {
        "caption",
        "dd",
        "dt",
        "figcaption",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "li",
        "p",
        "pre",
        "summary",
    }
    _SKIP_TAGS: ClassVar[set[str]] = {"script", "style", "svg"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title_parts: list[str] = []
        self.blocks: list[str] = []
        self.image_targets: list[str] = []
        self._in_title = False
        self._skip_depth = 0
        self._block_tag: str | None = None
        self._block_parts: list[str] = []
        self._row: list[str] | None = None
        self._cell_parts: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        normalized = tag.lower()
        if normalized in self._SKIP_TAGS:
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if normalized == "title":
            self._in_title = True
        elif normalized == "img":
            source = _html_attr_value(attrs, "src")
            if source:
                self.image_targets.append(source)
        elif normalized == "tr":
            self._flush_block()
            self._row = []
        elif normalized in {"td", "th"} and self._row is not None:
            self._cell_parts = []
        elif normalized in self._BLOCK_TAGS:
            self._flush_block()
            self._block_tag = normalized
            self._block_parts = []
        elif normalized == "br":
            self._append_text("\n")

    def handle_endtag(self, tag: str) -> None:
        normalized = tag.lower()
        if normalized in self._SKIP_TAGS and self._skip_depth:
            self._skip_depth -= 1
            return
        if self._skip_depth:
            return
        if normalized == "title":
            self._in_title = False
        elif normalized in {"td", "th"} and self._cell_parts is not None:
            if self._row is not None:
                self._row.append(_compact_html_text("".join(self._cell_parts)))
            self._cell_parts = None
        elif normalized == "tr":
            if self._row:
                cells = [cell for cell in self._row if cell]
                if cells:
                    row = " | ".join(_escape_markdown_table_cell(cell) for cell in cells)
                    self.blocks.append(f"| {row} |")
            self._row = None
        elif normalized == self._block_tag:
            self._flush_block()

    def handle_data(self, data: str) -> None:
        if self._skip_depth:
            return
        text = html_unescape(data)
        if self._in_title:
            self.title_parts.append(text)
        elif self._cell_parts is not None:
            self._cell_parts.append(text)
        else:
            self._append_text(text)

    def _append_text(self, text: str) -> None:
        if self._block_tag is not None:
            self._block_parts.append(text)

    def _flush_block(self) -> None:
        if self._block_tag is None:
            return
        text = _compact_html_text("".join(self._block_parts))
        if text:
            self.blocks.append(_html_block_markdown(self._block_tag, text))
        self._block_tag = None
        self._block_parts = []

    def preview(self, *, fallback_title: str) -> HtmlArtifactPreview:
        self._flush_block()
        title = _compact_html_text("".join(self.title_parts)) or fallback_title
        blocks = [block for block in self.blocks if block]
        if not blocks:
            blocks = ["No visible HTML body text was extracted. Open the artifact in a browser."]
        markdown = "\n\n".join(blocks[:80])
        if len(markdown) > 8_000:
            markdown = markdown[:8_000].rstrip() + "\n\n[Preview truncated.]"
        return HtmlArtifactPreview(
            title=title,
            markdown=markdown,
            image_targets=tuple(dict.fromkeys(self.image_targets)),
        )


def _html_artifact_preview_markdown(html_text: str, *, fallback_title: str) -> HtmlArtifactPreview:
    parser = HtmlArtifactPreviewParser()
    parser.feed(html_text)
    parser.close()
    return parser.preview(fallback_title=fallback_title)


def _html_attr_value(attrs: Sequence[tuple[str, str | None]], name: str) -> str | None:
    wanted = name.casefold()
    for key, value in attrs:
        if key.casefold() == wanted and value:
            return html_unescape(value)
    return None


def _html_image_payloads(
    targets: Sequence[str],
    *,
    base_path: Path,
) -> tuple[ToolImagePayload, ...]:
    payloads: list[ToolImagePayload] = []
    seen: set[Path] = set()
    for target in targets:
        path = _artifact_link_target_path(target, base_path=base_path)
        if path is None or path in seen:
            continue
        mime_type = HTML_ARTIFACT_IMAGE_MIME_TYPES.get(path.suffix.lower())
        if mime_type is None:
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        if not path.is_file() or stat.st_size <= 0 or stat.st_size > MAX_HTML_ARTIFACT_IMAGE_BYTES:
            continue
        try:
            data = path.read_bytes()
        except OSError:
            continue
        payloads.append(
            ToolImagePayload(
                path=str(path),
                mime_type=mime_type,
                bytes=len(data),
                image_base64=base64.b64encode(data).decode("ascii"),
            )
        )
        seen.add(path)
    return tuple(payloads)


def _html_artifact_summary_table(artifact: VisualArtifact, title: str) -> Table:
    table = Table.grid(padding=(0, 2))
    table.add_column(style="bold")
    table.add_column()
    table.add_row("file", artifact.path.name)
    table.add_row("type", artifact.mime_type)
    table.add_row("size", _format_artifact_size(artifact.bytes))
    table.add_row("title", title)
    return table


def _html_block_markdown(tag: str, text: str) -> str:
    if tag.startswith("h") and len(tag) == 2 and tag[1].isdigit():
        level = max(1, min(6, int(tag[1])))
        return f"{'#' * level} {text}"
    if tag == "li":
        return f"- {text}"
    if tag == "pre":
        return f"```text\n{text}\n```"
    if tag == "dt":
        return f"**{text}**"
    if tag == "dd":
        return f": {text}"
    return text


def _compact_html_text(value: str) -> str:
    return " ".join(value.split())


def _escape_markdown_table_cell(value: str) -> str:
    return value.replace("|", "\\|")


def _visual_artifact_key(payload: ToolImagePayload) -> tuple[str, str]:
    if payload.path:
        path = Path(payload.path).expanduser()
        if path.is_absolute():
            return ("path", str(path))
    digest = hashlib.sha256(payload.image_base64.encode("ascii", errors="ignore")).hexdigest()
    return ("payload", digest)


def _visual_artifact_path(
    payload: ToolImagePayload,
    *,
    session_id: str | None,
    item_index: int,
    payload_index: int,
) -> Path | None:
    source_path = Path(payload.path).expanduser()
    if source_path.is_absolute() and source_path.exists() and source_path.is_file():
        return source_path
    try:
        data = base64.b64decode(payload.image_base64, validate=True)
    except (binascii.Error, ValueError):
        return None
    if not data:
        return None
    cache_dir = Path(tempfile.gettempdir()) / "tau-tui-artifacts"
    cache_dir.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(data).hexdigest()[:12]
    safe_session = _safe_artifact_name(session_id or "session")
    safe_name = _safe_artifact_name(Path(payload.path).stem or "artifact")
    suffix = _artifact_suffix(payload.mime_type, Path(payload.path).suffix)
    path = cache_dir / (
        f"{safe_session}-{item_index:03d}-{payload_index:02d}-{safe_name}-{digest}{suffix}"
    )
    try:
        path.write_bytes(data)
    except OSError:
        return None
    return path


def _visual_artifact_title(item: ChatItem, payload: ToolImagePayload) -> str:
    filename = Path(payload.path).name or "visual artifact"
    if filename.startswith("graphviz-"):
        return f"Graphviz graph from {item.role}"
    if filename.startswith("mermaid-"):
        return f"Mermaid graph from {item.role}"
    return filename


def _artifact_suffix(mime_type: str, existing_suffix: str) -> str:
    if existing_suffix:
        return existing_suffix
    return {
        "image/gif": ".gif",
        "image/jpeg": ".jpg",
        "image/png": ".png",
        "image/svg+xml": ".svg",
        "image/webp": ".webp",
    }.get(mime_type, ".bin")


def _safe_artifact_name(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", value).strip(".-_").lower()
    return normalized[:48] or "artifact"


def _artifact_browser_summary(artifacts: Sequence[VisualArtifact]) -> str:
    if not artifacts:
        return "Found 0 artifacts"
    image_count = sum(1 for artifact in artifacts if artifact.mime_type.startswith("image/"))
    markdown_count = sum(1 for artifact in artifacts if artifact.preview_kind == "markdown")
    json_count = sum(1 for artifact in artifacts if artifact.preview_kind == "json")
    html_count = sum(1 for artifact in artifacts if artifact.preview_kind == "html")
    return (
        f"Found {len(artifacts)} artifact(s), {image_count} image-backed, "
        f"{markdown_count} Markdown report(s), {json_count} JSON receipt(s), "
        f"{html_count} HTML export(s)"
    )


def _artifact_browser_kind(artifact: VisualArtifact) -> ArtifactBrowserKind:
    if artifact.preview_kind in {"markdown", "json", "html"}:
        return artifact.preview_kind
    return "image"


def _artifact_browser_kind_tabs(
    artifacts: Sequence[VisualArtifact],
    kind: ArtifactBrowserKind,
) -> str:
    counts = {
        artifact_kind: sum(
            1
            for artifact in artifacts
            if artifact_kind == "all" or _artifact_browser_kind(artifact) == artifact_kind
        )
        for artifact_kind in ARTIFACT_BROWSER_KINDS
    }
    labels = []
    for artifact_kind in ARTIFACT_BROWSER_KINDS:
        label = f"{artifact_kind} {counts[artifact_kind]}"
        labels.append(f"[{label}]" if artifact_kind == kind else label)
    return "Kind: " + " | ".join(labels)


def _filter_artifacts(
    artifacts: Sequence[VisualArtifact],
    query: str,
    *,
    kind: ArtifactBrowserKind,
) -> tuple[VisualArtifact, ...]:
    tokens = tuple(token for token in query.casefold().split() if token)
    filtered: list[VisualArtifact] = []
    for artifact in artifacts:
        if kind != "all" and _artifact_browser_kind(artifact) != kind:
            continue
        if tokens and not _artifact_matches_search(artifact, tokens):
            continue
        filtered.append(artifact)
    return tuple(filtered)


def _artifact_matches_search(
    artifact: VisualArtifact,
    tokens: Sequence[str],
) -> bool:
    searchable = " ".join(
        (
            artifact.title,
            artifact.source,
            artifact.mime_type,
            artifact.preview_kind,
            artifact.path.name,
            str(artifact.path),
        )
    ).casefold()
    return all(token in searchable for token in tokens)


def _artifact_browser_empty_label(screen: ArtifactBrowserScreen) -> str:
    if not screen.artifacts:
        return "No artifacts in the current transcript."
    if screen.search_value.strip():
        return f"No {screen.kind} artifacts matching {screen.search_value!r}."
    return f"No {screen.kind} artifacts in the current transcript."


def _artifact_browser_label(index: int, artifact: VisualArtifact) -> str:
    size = _format_artifact_size(artifact.bytes)
    return (
        f"{index:02d}. {artifact.title} - {artifact.source} - "
        f"{artifact.mime_type}, {size} - {artifact.path}"
    )


def _format_artifact_size(byte_count: int) -> str:
    if byte_count < 1024:
        return f"{byte_count} B"
    if byte_count < 1024 * 1024:
        return f"{byte_count / 1024:.1f} KiB"
    return f"{byte_count / (1024 * 1024):.1f} MiB"


def _matches_configured_or_default_key(
    key: str,
    configured_key: str,
    default_key: str,
) -> bool:
    active_key = configured_key if configured_key.strip() else default_key
    return _matches_configured_key(key, active_key)


def _configured_key_parts(configured_key: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in configured_key.split(",") if part.strip())


def _tool_update_has_pipeline_stage(event: ToolExecutionUpdateEvent) -> bool:
    if event.data is None:
        return False
    return any(key in event.data for key in ("memory_stage", "pipeline_stage", "stage"))


_CLIPBOARD_TEXT_COMMANDS: tuple[tuple[str, ...], ...] = (
    ("wl-paste", "--no-newline"),
    ("xclip", "-selection", "clipboard", "-o"),
    ("xsel", "--clipboard", "--output"),
)
type _ClipboardCommandRunner = Callable[[tuple[str, ...], str, float], bool]
type _ClipboardCommandExists = Callable[[str], str | None]
_SUPPORTED_CLIPBOARD_IMAGE_MIME_TYPES: tuple[str, ...] = (
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/gif",
)
_CLIPBOARD_IMAGE_EXTENSIONS: dict[str, str] = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/webp": "webp",
    "image/gif": "gif",
}


def _copy_text_with_platform_command(
    text: str,
    *,
    platform_name: str | None = None,
    env: Mapping[str, str] | None = None,
    command_exists: _ClipboardCommandExists | None = None,
    runner: _ClipboardCommandRunner | None = None,
    timeout_s: float = 5.0,
) -> bool:
    """Copy text with platform tools that retain clipboard ownership."""
    platform = sys.platform if platform_name is None else platform_name
    environment = os.environ if env is None else env
    exists = shutil.which if command_exists is None else command_exists
    run_command = _run_clipboard_write_command if runner is None else runner

    if platform == "darwin":
        return exists("pbcopy") is not None and run_command(("pbcopy",), text, timeout_s)
    if platform == "win32":
        return exists("clip") is not None and run_command(("clip",), text, timeout_s)

    if (
        environment.get("TERMUX_VERSION")
        and exists("termux-clipboard-set") is not None
        and run_command(("termux-clipboard-set",), text, timeout_s)
    ):
        return True

    has_x11_display = bool(environment.get("DISPLAY"))
    if environment.get("WAYLAND_DISPLAY") and exists("wl-copy") is not None:
        if run_command(("wl-copy",), text, timeout_s):
            return True
        if has_x11_display and _copy_text_with_x11_command(
            text,
            command_exists=exists,
            runner=run_command,
            timeout_s=timeout_s,
        ):
            return True

    return has_x11_display and _copy_text_with_x11_command(
        text,
        command_exists=exists,
        runner=run_command,
        timeout_s=timeout_s,
    )


def _copy_text_with_x11_command(
    text: str,
    *,
    command_exists: _ClipboardCommandExists,
    runner: _ClipboardCommandRunner,
    timeout_s: float,
) -> bool:
    x11_commands = (
        ("xclip", "-selection", "clipboard"),
        ("xsel", "--clipboard", "--input"),
    )
    for command in x11_commands:
        if command_exists(command[0]) is None:
            continue
        if runner(command, text, timeout_s):
            return True
    return False


def _run_clipboard_write_command(args: tuple[str, ...], text: str, timeout_s: float) -> bool:
    try:
        completed = subprocess.run(
            args,
            input=text.encode("utf-8"),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout_s,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return completed.returncode == 0


@dataclass(frozen=True, slots=True)
class _ClipboardImage:
    bytes: bytes
    mime_type: str


def _normalize_pasted_text(text: str) -> str:
    """Normalize clipboard text before inserting it into the prompt editor."""
    decoded = re.sub(
        r"\x1b\[(\d+);5u",
        lambda match: _decode_csi_u_control(match.group(1), match.group(0)),
        text,
    )
    normalized = decoded.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
    return "".join(char for char in normalized if char == "\n" or ord(char) >= 32)


def _find_word_delete_start(line: str, cursor_column: int) -> int:
    """Return the line column reached by a Pi-style backward word delete."""
    index = min(max(cursor_column, 0), len(line))
    while index > 0 and line[index - 1].isspace():
        index -= 1
    if index <= 0:
        return index
    previous = line[index - 1]
    if previous.isalnum() or previous == "_":
        while index > 0 and (line[index - 1].isalnum() or line[index - 1] == "_"):
            index -= 1
        return index
    while (
        index > 0
        and not line[index - 1].isspace()
        and not (line[index - 1].isalnum() or line[index - 1] == "_")
    ):
        index -= 1
    return index


def _find_word_delete_end(line: str, cursor_column: int) -> int:
    """Return the line column reached by a Pi-style forward word delete."""
    index = min(max(cursor_column, 0), len(line))
    while index < len(line) and line[index].isspace():
        index += 1
    if index >= len(line):
        return index
    current = line[index]
    if current.isalnum() or current == "_":
        while index < len(line) and (line[index].isalnum() or line[index] == "_"):
            index += 1
        return index
    while (
        index < len(line)
        and not line[index].isspace()
        and not (line[index].isalnum() or line[index] == "_")
    ):
        index += 1
    return index


def _jump_character_from_key(key: str) -> str | None:
    """Return a printable character for Pi-style jump mode key input."""
    if key == "space":
        return " "
    return key if len(key) == 1 and key.isprintable() else None


def _decode_csi_u_control(code: str, fallback: str) -> str:
    codepoint = int(code)
    if 97 <= codepoint <= 122:
        return chr(codepoint - 96)
    if 65 <= codepoint <= 90:
        return chr(codepoint - 64)
    return fallback


async def _read_clipboard_text(timeout_s: float = 0.75) -> str | None:
    """Return plain text from the system clipboard when a supported backend is available."""
    for args in _CLIPBOARD_TEXT_COMMANDS:
        stdout = await _run_clipboard_command(args, timeout_s=timeout_s)
        if stdout is None:
            continue
        text = stdout.decode("utf-8", errors="replace")
        if text:
            return text
    return None


async def _read_clipboard_image() -> _ClipboardImage | None:
    """Return image bytes from Wayland or X11 clipboards when available."""
    wayland = await _read_clipboard_image_via_wl_paste()
    if wayland is not None:
        return wayland
    return await _read_clipboard_image_via_xclip()


async def _read_clipboard_image_via_wl_paste() -> _ClipboardImage | None:
    targets = await _run_clipboard_command(("wl-paste", "--list-types"), timeout_s=1.0)
    if targets is None:
        return None
    mime_type = _select_preferred_image_mime_type(
        targets.decode("utf-8", errors="replace").splitlines()
    )
    if mime_type is None:
        return None
    data = await _run_clipboard_command(
        ("wl-paste", "--type", mime_type, "--no-newline"),
        timeout_s=3.0,
    )
    if not data:
        return None
    return _ClipboardImage(bytes=data, mime_type=_base_mime_type(mime_type))


async def _read_clipboard_image_via_xclip() -> _ClipboardImage | None:
    targets = await _run_clipboard_command(
        ("xclip", "-selection", "clipboard", "-t", "TARGETS", "-o"),
        timeout_s=1.0,
    )
    candidate_mime_types: list[str] = []
    if targets is not None:
        preferred = _select_preferred_image_mime_type(
            targets.decode("utf-8", errors="replace").splitlines()
        )
        if preferred is not None:
            candidate_mime_types.append(preferred)
    candidate_mime_types.extend(_SUPPORTED_CLIPBOARD_IMAGE_MIME_TYPES)
    for mime_type in dict.fromkeys(candidate_mime_types):
        data = await _run_clipboard_command(
            ("xclip", "-selection", "clipboard", "-t", mime_type, "-o"),
            timeout_s=3.0,
        )
        if data:
            return _ClipboardImage(bytes=data, mime_type=_base_mime_type(mime_type))
    return None


async def _run_clipboard_command(args: tuple[str, ...], *, timeout_s: float) -> bytes | None:
    if shutil.which(args[0]) is None:
        return None
    process = None
    try:
        process = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(process.communicate(), timeout=timeout_s)
    except (OSError, TimeoutError):
        if process is not None and process.returncode is None:
            process.kill()
            with suppress(ProcessLookupError):
                await process.wait()
        return None
    if process.returncode != 0:
        return None
    return stdout


def _write_clipboard_image_to_temp(image: _ClipboardImage) -> Path:
    ext = _CLIPBOARD_IMAGE_EXTENSIONS.get(_base_mime_type(image.mime_type), "png")
    with tempfile.NamedTemporaryFile(
        prefix="tau-clipboard-",
        suffix=f".{ext}",
        delete=False,
    ) as image_file:
        image_file.write(image.bytes)
        return Path(image_file.name)


def _select_preferred_image_mime_type(mime_types: Sequence[str]) -> str | None:
    normalized = [(raw.strip(), _base_mime_type(raw)) for raw in mime_types if raw.strip()]
    for preferred in _SUPPORTED_CLIPBOARD_IMAGE_MIME_TYPES:
        for raw, base in normalized:
            if base == preferred:
                return raw
    return None


def _base_mime_type(mime_type: str) -> str:
    return mime_type.split(";", maxsplit=1)[0].strip().lower()


def _external_editor_command(configured_command: str | None = None) -> str | None:
    """Return the configured external editor command, if any."""
    if configured_command is not None and configured_command.strip():
        return configured_command.strip()
    command = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if command is not None and command.strip():
        return command.strip()
    return None


async def _edit_text_with_external_editor(command: str, content: str) -> str | None:
    """Edit text in an external editor and return updated content on success."""
    with tempfile.TemporaryDirectory(prefix="tau-editor-") as temp_dir:
        prompt_path = Path(temp_dir) / "prompt.md"
        prompt_path.write_text(content, encoding="utf-8")
        args = [*shlex.split(command), str(prompt_path)]
        if len(args) == 1:
            return None
        process = await asyncio.create_subprocess_exec(*args)
        exit_code = await process.wait()
        if exit_code != 0:
            return None
        return prompt_path.read_text(encoding="utf-8").removesuffix("\n")


def _theme_css_variables(theme: TuiTheme) -> dict[str, str]:
    return {
        "tau-screen-background": theme.screen_background,
        "tau-screen-text": theme.screen_text,
        "tau-chrome-background": theme.chrome_background,
        "tau-chrome-text": theme.chrome_text,
        "tau-muted-text": theme.muted_text,
        "tau-sidebar-background": theme.sidebar_background,
        "tau-border": theme.border,
        "tau-transcript-background": theme.transcript_background,
        "tau-prompt-background": theme.prompt_background,
        "tau-prompt-text": theme.prompt_text,
        "tau-prompt-border": theme.prompt_border,
        "tau-autocomplete-background": theme.autocomplete_background,
        "tau-accent": theme.accent,
        "tau-tool-running": theme.role_styles["tool"].border,
        "tau-highlight-background": theme.highlight_background,
        "tau-highlight-text": theme.highlight_text,
        "tau-markdown-highlight": theme.markdown_heading,
        "tau-markdown-table-header": theme.markdown_table_header,
        "tau-markdown-table-border": theme.markdown_table_border,
        "tau-markdown-inline-code": theme.markdown_inline_code,
        "tau-markdown-code-block-background": theme.markdown_code_block_background,
        "tau-markdown-link": theme.markdown_link,
        "tau-markdown-bullet": theme.markdown_bullet,
        "footer-background": theme.chrome_background,
        "footer-foreground": theme.chrome_text,
        "footer-description-background": theme.chrome_background,
        "footer-description-foreground": theme.chrome_text,
        "footer-key-background": theme.chrome_background,
        "footer-key-foreground": theme.accent,
        "footer-item-background": theme.chrome_background,
    }


def _render_queued_messages(
    state: TuiState,
    *,
    theme: TuiTheme,
    keybindings: TuiKeybindings | None = None,
) -> Group:
    """Render queued prompts stacked above the prompt input."""
    keybindings = keybindings or TuiKeybindings()
    rows: list[Text] = []
    for message in state.queued_steering:
        row = Text("↪ steering · queued: ", style=theme.muted_text)
        row.append(_queued_message_preview(message), style=theme.prompt_text)
        rows.append(row)
    for message in state.queued_follow_up:
        row = Text("↳ follow-up · queued: ", style=theme.muted_text)
        row.append(_queued_message_preview(message), style=theme.prompt_text)
        rows.append(row)
    for item in state.pending_terminal_commands:
        row = Text("↯ terminal · pending: ", style=theme.muted_text)
        row.append(_queued_message_preview(item.text), style=theme.prompt_text)
        if item.tool_result_text:
            first_line = item.tool_result_text.splitlines()[0]
            row.append(f" · {first_line}", style=theme.muted_text)
        rows.append(row)
    if state.queued_steering or state.queued_follow_up:
        rows.append(
            Text(
                f"↳ {_key_hint(keybindings.dequeue_messages)} to edit all queued messages",
                style=theme.muted_text,
            )
        )
    return Group(*rows)


def _render_extension_statuses(statuses: dict[str, str]) -> str:
    """Render persistent extension status entries near the prompt."""
    return "  |  ".join(
        f"{key}: {_sanitize_extension_status_text(value)}"
        for key, value in sorted(statuses.items())
    )


def _sanitize_extension_status_text(text: str) -> str:
    normalized = text.replace("\r", " ").replace("\n", " ").replace("\t", " ")
    return re.sub(r" +", " ", normalized).strip()


def _render_extension_widgets(widgets: dict[str, tuple[str, ...]]) -> str:
    """Render extension-owned prompt-region widgets."""
    rendered: list[str] = []
    for key, lines in widgets.items():
        if len(lines) == 1:
            rendered.append(f"{key}: {lines[0]}")
        else:
            rendered.append("\n".join((f"{key}:", *(f"  {line}" for line in lines))))
    return "\n\n".join(rendered)


def _render_extension_footer(lines: tuple[str, ...] | None) -> str:
    """Render an extension-owned footer replacement."""
    if lines is None:
        return ""
    return "\n".join(lines)


def _render_extension_header(lines: tuple[str, ...] | None) -> str:
    """Render an extension-owned startup header replacement."""
    if lines is None:
        return ""
    return "\n".join(lines)


def _queued_message_preview(message: str) -> str:
    """Return the single-line preview shown above the prompt."""
    preview = next((line.strip() for line in message.splitlines() if line.strip()), "")
    if len(preview) <= QUEUED_MESSAGE_PREVIEW_CHARS:
        return preview
    return f"{preview[: QUEUED_MESSAGE_PREVIEW_CHARS - 3]}..."


def _last_assistant_text(state: TuiState) -> str | None:
    """Return the most recent assistant transcript text, if any."""
    for item in reversed(state.items):
        if item.role == "assistant" and item.text:
            return item.text
    return None


def _prompt_footer_mode(
    state: TuiState,
    completion_state: CompletionState,
) -> Literal["normal", "completion", "running"]:
    if completion_state.items:
        return "completion"
    if state.running:
        return "running"
    return "normal"


def _key_hint(key: str) -> str:
    return "/".join(
        "+".join(piece.capitalize() for piece in part.split("+"))
        for part in _configured_key_parts(key)
    )


def _key_hint_with_default(configured_key: str, default_key: str) -> str:
    active_key = configured_key if configured_key.strip() else default_key
    return _key_hint(active_key)


def _newline_key_hint(keybindings: TuiKeybindings) -> str:
    if keybindings.insert_newline == "shift+enter":
        return "Shift+Enter" if keybindings.command_palette == "ctrl+j" else "Shift+Enter/Ctrl+J"
    return _key_hint(keybindings.insert_newline)


def _prompt_placeholder(keybindings: TuiKeybindings) -> str:
    """Return the prompt placeholder using the active submit/newline keys."""
    return (
        f"Ask Tau…  {_key_hint(keybindings.submit_prompt)} submits, "
        f"{_newline_key_hint(keybindings)} inserts a newline"
    )


def _local_tui_command(
    text: str,
    keybindings: TuiKeybindings,
    session: CodingSession,
    settings: TuiSettings,
) -> CommandResult | None:
    command = text.strip().casefold()
    if command == "/hotkeys":
        return CommandResult(
            handled=True,
            message=_render_tui_hotkeys_message(keybindings, session),
        )
    if command == "/resources":
        return CommandResult(
            handled=True,
            message=_render_tui_resources_message(session),
        )
    if command == "/images":
        return CommandResult(handled=True, images_picker_requested=True)
    if command.startswith("/images "):
        image_value = _parse_show_images_command_value(command.removeprefix("/images "))
        if image_value is None:
            return CommandResult(handled=True, message="Usage: /images [on|off]")
        if image_value == settings.show_images:
            return CommandResult(
                handled=True,
                message=f"Show images: {'on' if image_value else 'off'}",
            )
        return CommandResult(handled=True, show_images=image_value)
    return None


def _parse_show_images_command_value(value: str) -> bool | None:
    normalized = value.strip().casefold()
    if normalized in {"on", "yes", "true", "show", "inline"}:
        return True
    if normalized in {"off", "no", "false", "hide", "placeholder"}:
        return False
    return None


def _render_tui_hotkeys_message(
    keybindings: TuiKeybindings,
    session: CodingSession | None = None,
) -> str:
    newline_hint = _newline_key_hint(keybindings)
    lines = [
        "# Keyboard Shortcuts",
        "",
        "| Key | Action |",
        "| --- | --- |",
        _markdown_table_row(_key_hint(keybindings.submit_prompt), "submit prompt"),
        _markdown_table_row(newline_hint, "insert newline"),
        _markdown_table_row(
            _key_hint(keybindings.command_palette),
            "open slash-command completions",
        ),
        _markdown_table_row(_key_hint(keybindings.session_picker), "open session picker"),
        _markdown_table_row(_key_hint(keybindings.model_picker), "open model picker"),
        _markdown_table_row(
            _key_hint(keybindings.toggle_tool_results),
            "collapse or expand tool output",
        ),
        _markdown_table_row(
            _key_hint(keybindings.dag_viewer_handoff),
            "open current DAG run in web viewer",
        ),
        _markdown_table_row(
            _key_hint(keybindings.paste_clipboard),
            "paste clipboard text or image",
        ),
        _markdown_table_row(
            _key_hint(keybindings.copy_last_message),
            "copy last assistant message",
        ),
        _markdown_table_row(
            "/artifacts",
            "browse image, graph, Markdown, JSON, and HTML artifacts",
        ),
        _markdown_table_row("drop files", "attach paths to the prompt"),
        "",
        "Navigation:",
        f"- {_key_hint(keybindings.editor_cursor_up)}/"
        f"{_key_hint(keybindings.editor_cursor_down)}/"
        f"{_key_hint(keybindings.editor_cursor_left)}/"
        f"{_key_hint(keybindings.editor_cursor_right)}: move cursor or browse prompt history",
        f"- {_key_hint(keybindings.completion_previous)}/"
        f"{_key_hint(keybindings.completion_next)}: move through completions",
        f"- {_key_hint(keybindings.editor_cursor_line_start)}/"
        f"{_key_hint(keybindings.editor_cursor_line_end)}: move to line start/end",
        f"- {_key_hint(keybindings.editor_page_up)}/"
        f"{_key_hint(keybindings.editor_page_down)}: scroll transcript by page",
        "",
        "Editing:",
        f"- {_key_hint(keybindings.submit_prompt)}: submit prompt",
        f"- {newline_hint}: insert newline",
        "- Shift+Space: insert a literal space",
        f"- {_key_hint(keybindings.editor_cursor_line_start)}/"
        f"{_key_hint(keybindings.editor_cursor_line_end)}: move to line start/end",
        f"- {_key_hint(keybindings.editor_cursor_left)}/"
        f"{_key_hint(keybindings.editor_cursor_right)}: move one character left/right",
        f"- {_key_hint(keybindings.editor_cursor_word_left)}: move word left",
        f"- {_key_hint(keybindings.editor_cursor_word_right)}: move word right",
        f"- {_key_hint(keybindings.editor_jump_forward)}/"
        f"{_key_hint(keybindings.editor_jump_backward)}: jump to next or previous character",
        f"- {_key_hint(keybindings.editor_delete_to_line_start)}: delete to line start",
        f"- {_key_hint(keybindings.editor_delete_to_line_end)}: "
        "delete to line end when not used for commands",
        f"- {_key_hint(keybindings.editor_delete_char_forward)}: delete next character; "
        f"{_key_hint(keybindings.quit)} quits when the editor is empty",
        f"- {_key_hint(keybindings.editor_delete_word_backward)}: delete previous word",
        f"- {_key_hint(keybindings.editor_delete_word_forward)}: delete next word",
        f"- {_key_hint(keybindings.editor_yank)}/{_key_hint(keybindings.editor_yank_pop)}: "
        "yank or cycle deleted text",
        f"- {_key_hint(keybindings.editor_undo)}: undo previous prompt edit",
        f"- {_key_hint(keybindings.accept_completion)}: accept autocomplete or path completion",
        f"- {_key_hint(keybindings.external_editor)}: edit prompt in external editor",
        f"- {_key_hint(keybindings.paste_clipboard)}: paste clipboard text or image",
        "- drop files: attach paths to the prompt",
        f"- {_key_hint(keybindings.copy_message)}: clear input; press twice to quit",
        "",
        "Agent:",
        f"- {_key_hint(keybindings.cancel)}: cancel autocomplete or active run",
        f"- {_key_hint(keybindings.queue_follow_up)}: queue follow-up while running",
        f"- {_key_hint(keybindings.dequeue_messages)}: restore queued messages",
        f"- {_key_hint(keybindings.toggle_tool_results)}: collapse or expand tool output",
        f"- {_key_hint(keybindings.dag_viewer_handoff)}: open current DAG run in web viewer",
        f"- {_key_hint(keybindings.toggle_thinking)}: toggle thinking tokens",
        f"- {_key_hint(keybindings.thinking_cycle)}: cycle thinking level",
        "",
        "Sessions and models:",
        f"- {_key_hint(keybindings.command_palette)}: open slash-command completions",
        f"- {_key_hint(keybindings.session_picker)}: open session picker",
        f"- {_key_hint(keybindings.model_cycle)}: cycle model forward",
        f"- {_key_hint(keybindings.model_cycle_previous)}: cycle model backward",
        f"- {_key_hint(keybindings.model_picker)}: open model picker",
        f"- {_key_hint(keybindings.copy_last_message)}: copy last assistant message",
        f"- {_key_hint(keybindings.suspend)}: suspend to background",
        f"- {_key_hint(keybindings.quit)}: quit when the editor is empty",
        "",
        "Session Picker:",
        f"- {_key_hint(keybindings.accept_completion)}: switch current/all sessions",
        f"- {_key_hint(keybindings.session_toggle_named_filter)}: toggle named-session filter",
        f"- {_key_hint(keybindings.session_toggle_path)}: toggle path display",
        f"- {_key_hint(keybindings.session_toggle_sort)}: cycle sort mode",
        f"- {_key_hint(keybindings.session_rename)}: rename highlighted session",
        f"- {_key_hint(keybindings.session_delete)}: delete highlighted session",
        f"- {_key_hint(keybindings.session_delete_noninvasive)}: delete when search is empty",
        "",
        "Tree Picker:",
        f"- {_key_hint(keybindings.tree_fold_or_up)}/"
        f"{_key_hint(keybindings.tree_unfold_or_down)}: fold or unfold branches",
        f"- {_key_hint(keybindings.tree_edit_label)}: edit tree label",
        f"- {_key_hint(keybindings.tree_toggle_label_timestamp)}: toggle label timestamps",
        f"- {_key_hint(keybindings.tree_filter_default)}/"
        f"{_key_hint(keybindings.tree_filter_no_tools)}/"
        f"{_key_hint(keybindings.tree_filter_user_only)}/"
        f"{_key_hint(keybindings.tree_filter_labeled_only)}/"
        f"{_key_hint(keybindings.tree_filter_all)}: choose tree filter",
        f"- {_key_hint(keybindings.tree_filter_cycle)}/"
        f"{_key_hint(keybindings.tree_filter_cycle_previous)}: cycle tree filters",
        "",
        "Scoped Model Picker:",
        f"- {_key_hint(keybindings.models_enable_all)}: enable all visible models",
        f"- {_key_hint(keybindings.models_clear_all)}: clear visible models",
        f"- {_key_hint(keybindings.models_toggle_provider)}: toggle highlighted provider",
        f"- {_key_hint(keybindings.models_reorder_up)}/"
        f"{_key_hint(keybindings.models_reorder_down)}: reorder scoped model",
        f"- {_key_hint(keybindings.models_save)}: save scoped model selection",
        "",
        "Slash and shell:",
        "- /: slash commands",
        "- /resources: show loaded context, skills, prompts, tools, and diagnostics",
        "- /artifacts: browse image, graph, Markdown, JSON, and HTML artifacts",
        "- /dag-viewer [run-dir]: open a DAG run in the web viewer",
        "- /decisions: show pending human approval decisions",
        "- !: run bash command and add output to context",
        "- !!: run bash command without adding output to context",
    ]
    optional_lines = [
        (keybindings.session_new, "start a new session"),
        (keybindings.session_tree, "open session tree"),
        (keybindings.session_fork, "fork from a previous message"),
        (keybindings.session_resume, "resume a previous session"),
    ]
    lines.extend(f"- {_key_hint(key)}: {description}" for key, description in optional_lines if key)
    if session is not None:
        extension_lines = _extension_shortcut_hotkey_lines(session, keybindings)
        if extension_lines:
            lines.extend(("", "Extensions:", *extension_lines))
    return "\n".join(lines)


def _markdown_table_row(key: str, action: str) -> str:
    return f"| {_escape_markdown_table_cell(key)} | {_escape_markdown_table_cell(action)} |"


def _escape_markdown_table_cell(value: str) -> str:
    return value.replace("\\", "\\\\").replace("|", "\\|")


def _extension_shortcut_hotkey_lines(
    session: CodingSession,
    keybindings: TuiKeybindings,
) -> list[str]:
    lines: list[str] = []
    shortcut_sources = getattr(session, "extension_shortcut_sources", {})
    if not isinstance(shortcut_sources, dict):
        return lines
    for key, (extension_name, description) in sorted(shortcut_sources.items()):
        if _extension_shortcut_conflicts_with_builtins(key, keybindings):
            lines.append(
                f"- {_key_hint(key)}: {description} "
                f"(extension:{extension_name}; disabled, conflicts with built-in key)"
            )
        else:
            lines.append(f"- {_key_hint(key)}: {description} (extension:{extension_name})")
    return lines


def _extension_shortcut_conflicts_with_builtins(
    key: str,
    keybindings: TuiKeybindings,
) -> bool:
    normalized = key.strip().lower()
    if not normalized:
        return True
    for keybinding_field in fields(TuiKeybindings):
        value = getattr(keybindings, keybinding_field.name)
        configured = {part.lower() for part in _configured_key_parts(value)}
        if normalized in configured:
            return True
    return False


def _render_tui_resources_message(session: CodingSession) -> str:
    sections = [
        ("Context", _resource_context_lines(session.context_files, cwd=session.cwd)),
        (
            "Skills",
            _resource_name_path_lines(
                session.skills,
                cwd=session.cwd,
                empty="No skills loaded",
            ),
        ),
        ("Prompts", _resource_prompt_lines(session.prompt_templates, cwd=session.cwd)),
        (
            "Extensions",
            _resource_name_path_lines(
                getattr(session, "extensions", ()),
                cwd=session.cwd,
                empty="No extensions loaded",
            ),
        ),
        (
            "Tools",
            _resource_name_path_lines(
                session.tools,
                cwd=session.cwd,
                empty="No tools available",
            ),
        ),
        (
            "Diagnostics",
            _resource_diagnostic_lines(
                getattr(session, "resource_diagnostics", ()),
                cwd=session.cwd,
            ),
        ),
    ]
    lines = ["Loaded Resources", ""]
    for title, entries in sections:
        lines.append(f"{title}:")
        lines.extend(f"- {entry}" for entry in entries)
        lines.append("")
    return "\n".join(lines).rstrip()


def _render_startup_resources_summary(
    session: CodingSession,
    *,
    keybindings: TuiKeybindings,
    expanded: bool,
    startup_notice: str | None = None,
) -> str:
    notice = startup_notice.strip() if startup_notice else ""
    startup_help = _render_startup_help_lines(keybindings, expanded=expanded)
    if expanded:
        lines: list[str] = []
        if notice:
            lines.extend(("Startup Notice", f"- {notice}", ""))
        lines.extend(("Startup Help", *startup_help, ""))
        lines.extend(
            (
                _render_tui_resources_message(session),
                "",
                f"{_key_hint(keybindings.toggle_tool_results)}: "
                "collapse startup resources and tool output",
            )
        )
        return "\n".join(lines)

    sections = [
        ("Context", _compact_context_labels(session.context_files, cwd=session.cwd)),
        ("Skills", _compact_named_resource_labels(session.skills)),
        ("Prompts", _compact_prompt_labels(session.prompt_templates)),
        ("Extensions", _compact_named_resource_labels(getattr(session, "extensions", ()))),
        (
            "Diagnostics",
            _compact_diagnostic_labels(getattr(session, "resource_diagnostics", ())),
        ),
    ]
    visible_sections = [f"[{title}] {', '.join(labels)}" for title, labels in sections if labels]
    if notice:
        visible_sections.insert(0, f"[Notice] {notice}")
    visible_sections.insert(0, startup_help[0])
    visible_sections.append(
        f"{_key_hint(keybindings.toggle_tool_results)} expands startup resources; "
        "/resources opens details; /hotkeys opens all shortcuts"
    )
    return "\n".join(visible_sections)


def _render_startup_help_lines(
    keybindings: TuiKeybindings,
    *,
    expanded: bool,
) -> list[str]:
    """Return Pi-style startup operating hints from the active keybindings."""
    interrupt = _key_hint(keybindings.cancel)
    clear = _key_hint(keybindings.copy_message)
    quit_key = _key_hint(keybindings.quit)
    tools = _key_hint(keybindings.toggle_tool_results)
    if not expanded:
        return [
            f"{interrupt} interrupt | {clear}/{quit_key} clear/exit | "
            f"/ commands | ! bash | {tools} more"
        ]
    return [
        f"- {interrupt}: interrupt active work",
        f"- {clear}: clear input; press twice to quit",
        f"- {quit_key}: quit when the editor is empty",
        f"- {_key_hint(keybindings.suspend)}: suspend to background",
        f"- {_key_hint(keybindings.thinking_cycle)}: cycle thinking level",
        f"- {_key_hint(keybindings.model_cycle)}/"
        f"{_key_hint(keybindings.model_cycle_previous)}: cycle models",
        f"- {_key_hint(keybindings.model_picker)}: select model",
        f"- {tools}: expand startup resources and tool output",
        f"- {_key_hint(keybindings.toggle_thinking)}: toggle thinking tokens",
        f"- {_key_hint(keybindings.external_editor)}: open external editor",
        f"- {_key_hint(keybindings.queue_follow_up)}: queue follow-up while running",
        f"- {_key_hint(keybindings.dequeue_messages)}: edit all queued messages",
        f"- {_key_hint(keybindings.paste_clipboard)}: paste clipboard text or image",
        "- /: slash commands",
        "- !: run bash command and add output to context",
        "- !!: run bash command without adding output to context",
        "- drop files: attach paths to the prompt",
    ]


def _compact_context_labels(
    context_files: Sequence[ProjectContextFile],
    *,
    cwd: Path,
) -> list[str]:
    return [
        _display_resource_path(Path(context_file.path), cwd=cwd) for context_file in context_files
    ]


def _compact_named_resource_labels(resources: Sequence[Any]) -> list[str]:
    return [str(getattr(resource, "name", "unknown")) for resource in resources]


def _compact_prompt_labels(prompt_templates: Sequence[Any]) -> list[str]:
    return [f"/{getattr(template, 'name', 'unknown')}" for template in prompt_templates]


def _compact_diagnostic_labels(diagnostics: Sequence[Any]) -> list[str]:
    if not diagnostics:
        return []
    counts: dict[str, int] = {}
    for diagnostic in diagnostics:
        severity = str(getattr(diagnostic, "severity", "warning"))
        counts[severity] = counts.get(severity, 0) + 1
    return [f"{severity}: {count}" for severity, count in sorted(counts.items())]


def _resource_context_lines(
    context_files: Sequence[ProjectContextFile],
    *,
    cwd: Path,
) -> list[str]:
    if not context_files:
        return ["No context files"]
    return [
        _format_scoped_resource_path(Path(context_file.path), cwd=cwd)
        for context_file in context_files
    ]


def _resource_prompt_lines(prompt_templates: Sequence[Any], *, cwd: Path) -> list[str]:
    if not prompt_templates:
        return ["No prompt templates"]
    lines: list[str] = []
    for template in prompt_templates:
        name = getattr(template, "name", "unknown")
        path = getattr(template, "path", None)
        if path is None:
            lines.append(f"/{name}")
        else:
            lines.append(f"/{name} ({_format_scoped_resource_path(Path(path), cwd=cwd)})")
    return lines


def _resource_name_path_lines(
    resources: Sequence[Any],
    *,
    cwd: Path,
    empty: str,
) -> list[str]:
    if not resources:
        return [empty]
    lines: list[str] = []
    for resource in resources:
        name = getattr(resource, "name", "unknown")
        path = getattr(resource, "path", None)
        if path is None:
            lines.append(name)
        else:
            scoped_path = _format_scoped_resource_path(Path(path), cwd=cwd)
            lines.append(f"{name} ({scoped_path})")
    return lines


def _resource_diagnostic_lines(diagnostics: Sequence[Any], *, cwd: Path) -> list[str]:
    if not diagnostics:
        return ["No resource diagnostics"]
    lines: list[str] = []
    for diagnostic in diagnostics:
        severity = str(getattr(diagnostic, "severity", "warning"))
        kind = str(getattr(diagnostic, "kind", "resource"))
        name = getattr(diagnostic, "name", None)
        message = str(getattr(diagnostic, "message", diagnostic))
        label_parts = [severity, kind]
        if name is not None:
            label_parts.append(str(name))
        path = getattr(diagnostic, "path", None)
        if path is None:
            lines.append(f"{' '.join(label_parts)}: {message}")
        else:
            lines.append(
                f"{' '.join(label_parts)}: {message} "
                f"({_format_scoped_resource_path(Path(path), cwd=cwd)})"
            )
    return lines


def _format_scoped_resource_path(path: Path, *, cwd: Path) -> str:
    return f"{_resource_scope_label(path, cwd=cwd)} {_display_resource_path(path, cwd=cwd)}"


def _resource_scope_label(path: Path, *, cwd: Path) -> str:
    resolved = path.expanduser()
    if resolved.is_absolute():
        with suppress(ValueError):
            resolved.resolve().relative_to(cwd.resolve())
            return "[project]"
        home = Path.home().resolve()
        with suppress(ValueError):
            home_relative = resolved.resolve().relative_to(home)
            if home_relative.parts[:1] == (".agents",):
                return "[user .agents]"
            if home_relative.parts[:1] == (".tau",):
                return "[user]"
        return "[path]"
    return "[project]"


def _display_resource_path(path: Path, *, cwd: Path) -> str:
    if not path.is_absolute():
        return str(path)
    with suppress(ValueError):
        return str(path.resolve().relative_to(cwd.resolve()))
    return str(path)


def _normalized_config_resource_path(path: Path) -> Path:
    return path.expanduser().resolve(strict=False)


def _config_map_items(
    session: CodingSession,
    settings: TuiSettings,
    *,
    project_settings: ProjectTuiSettings | None = None,
) -> tuple[ConfigMapItem, ...]:
    """Return real Tau config/resource rows for the interactive config map."""
    paths = TauPaths()
    resource_paths = TauResourcePaths(cwd=session.cwd, paths=paths)
    trust_path = ProjectTrustStore.from_resource_paths(resource_paths).trust_path
    loaded_extensions = getattr(session, "extensions", ())
    extension_count = len(loaded_extensions) if isinstance(loaded_extensions, Sequence) else 0
    project_settings = project_settings or ProjectTuiSettings()
    disabled_paths = {
        *(
            _normalized_config_resource_path(Path(path))
            for path in settings.disabled_resource_paths
        ),
        *(
            _normalized_config_resource_path(Path(path))
            for path in project_settings.disabled_resource_paths
        ),
    }

    items: list[ConfigMapItem] = []

    def add_command(command: str, description: str) -> None:
        items.append(
            ConfigMapItem(
                section="Commands",
                label=command,
                value=description,
                description=description,
                action="insert_command",
                action_value=command,
            )
        )

    def add_path(
        section: str,
        label: str,
        path: Path,
        description: str,
        *,
        scope: ConfigMapScope | None = None,
    ) -> None:
        items.append(
            ConfigMapItem(
                section=section,
                label=label,
                value=str(path),
                description=description,
                action="copy_path",
                action_value=str(path),
                scope=scope or _config_map_scope_for_path(path, cwd=session.cwd),
            )
        )

    def add_resource_toggle(section: str, label: str, path: Path, *, enabled: bool) -> None:
        action = "disable" if enabled else "enable"
        items.append(
            ConfigMapItem(
                section=section,
                label=label,
                value=_display_resource_path(path, cwd=session.cwd),
                description=f"{action.capitalize()} this resource path and reload resources.",
                action="toggle_resource",
                action_value=str(path),
                scope=_config_map_scope_for_path(path, cwd=session.cwd),
            )
        )

    add_command("/settings", "Edit durable TUI settings.")
    add_command("/resources", "Inspect loaded context, skills, prompts, tools, and diagnostics.")
    add_command("/reload", "Reload local resources and project context.")
    add_command("/trust", "Save project-local resource trust.")
    add_command("/login", "Manage saved provider credentials.")
    add_command("/logout", "Remove credentials saved by /login.")
    add_command("/model", "Choose the active provider model.")
    add_command("/scoped-models", "Configure the Ctrl+P model rotation scope.")
    add_command("/workflows", "Choose packaged canonical Tau DAG workflows.")

    add_path(
        "Config files",
        "TUI settings",
        paths.home / "tui.json",
        "Durable TUI settings file.",
        scope="user",
    )
    add_path(
        "Config files",
        "Provider settings",
        provider_settings_path(paths),
        "Saved provider and model configuration.",
        scope="user",
    )
    add_path(
        "Config files",
        "Provider credentials",
        credentials_path(paths),
        "Credentials saved by /login.",
        scope="user",
    )
    add_path(
        "Config files",
        "Project trust",
        trust_path,
        "Project-local resource trust decisions.",
        scope="project",
    )
    add_path(
        "Config files",
        "Project TUI settings",
        project_tui_settings_path(session.cwd, paths),
        "Project-local TUI resource overrides.",
        scope="project",
    )

    for path in resource_paths.skills_dirs:
        add_path("Resource dirs", "Skills", path, "Loaded in increasing precedence order.")
    for path in resource_paths.prompts_dirs:
        add_path("Resource dirs", "Prompts", path, "Prompt templates loaded from this directory.")
    for path in resource_paths.themes_dirs:
        add_path("Resource dirs", "Themes", path, "Custom TUI themes loaded from this directory.")
    add_path(
        "Resource dirs",
        "Extensions",
        resource_paths.extensions_dir,
        "User extension directory.",
    )
    add_path(
        "Resource dirs",
        "Project extensions",
        paths.project_tau_dir(session.cwd) / "extensions",
        "Project-local extension directory.",
    )

    items.extend(
        (
            ConfigMapItem(
                "Loaded resources",
                "Context files",
                str(len(session.context_files)),
                "Active context files loaded into the session.",
            ),
            ConfigMapItem(
                "Loaded resources",
                "Skills",
                str(len(session.skills)),
                "Loaded Tau and .agents skills.",
            ),
            ConfigMapItem(
                "Loaded resources",
                "Prompt templates",
                str(len(session.prompt_templates)),
                "Loaded slash prompt templates.",
            ),
            ConfigMapItem(
                "Loaded resources",
                "Extensions",
                str(extension_count),
                "Loaded Tau extensions.",
            ),
            ConfigMapItem(
                "Loaded resources",
                "Diagnostics",
                str(len(session.resource_diagnostics)),
                "Non-fatal resource discovery diagnostics.",
            ),
        )
    )

    for skill in session.skills:
        if _normalized_config_resource_path(skill.path) not in disabled_paths:
            add_resource_toggle("Loaded skills", skill.name, skill.path, enabled=True)
    for template in session.prompt_templates:
        if _normalized_config_resource_path(template.path) not in disabled_paths:
            add_resource_toggle(
                "Loaded prompts",
                template.name,
                template.path,
                enabled=True,
            )
    if isinstance(loaded_extensions, Sequence):
        for extension in loaded_extensions:
            add_resource_toggle(
                "Loaded extensions",
                extension.name,
                extension.path,
                enabled=True,
            )
    for disabled_path in sorted(disabled_paths, key=lambda item: str(item)):
        add_resource_toggle("Disabled resources", disabled_path.name, disabled_path, enabled=False)

    for diagnostic in session.resource_diagnostics:
        path = getattr(diagnostic, "path", None)
        label = str(getattr(diagnostic, "name", None) or getattr(diagnostic, "kind", "resource"))
        items.append(
            ConfigMapItem(
                section="Diagnostics",
                label=label,
                value=str(getattr(diagnostic, "message", "")),
                description=diagnostic.format(),
                action="copy_path" if isinstance(path, Path) else None,
                action_value=str(path) if isinstance(path, Path) else None,
                scope=(
                    _config_map_scope_for_path(path, cwd=session.cwd)
                    if isinstance(path, Path)
                    else "all"
                ),
            )
        )

    return tuple(items)


def _config_map_scope_for_path(path: Path, *, cwd: Path) -> ConfigMapScope:
    """Classify config-map rows for Pi-style user/project scope tabs."""
    normalized_path = _normalized_config_resource_path(path)
    normalized_cwd = _normalized_config_resource_path(cwd)
    try:
        normalized_path.relative_to(normalized_cwd)
    except ValueError:
        return "user"
    return "project"


def _config_map_scope_tabs(scope: ConfigMapScope) -> str:
    labels: tuple[tuple[ConfigMapScope, str], ...] = (
        ("all", "All"),
        ("project", "Project"),
        ("user", "User"),
    )
    return "Tabs: " + "  ".join(
        f"{'●' if key == scope else '○'} {label}" for key, label in labels
    )


def _filter_config_map_items(
    items: Sequence[ConfigMapItem],
    query: str,
    *,
    scope: ConfigMapScope = "all",
) -> tuple[ConfigMapItem, ...]:
    tokens = _query_tokens(query)
    scoped_items = tuple(
        item for item in items if scope == "all" or item.scope in {"all", scope}
    )
    if not tokens:
        return scoped_items
    return tuple(
        item
        for item in scoped_items
        if _query_tokens_match(
            tokens,
            f"{item.section} {item.label} {item.value} {item.description} {item.action or ''}",
        )
    )


def _config_map_item_label(item: ConfigMapItem) -> str:
    action = ""
    if item.action == "insert_command":
        action = " [insert]"
    elif item.action == "copy_path":
        action = " [copy]"
    elif item.action == "toggle_resource":
        scope, state, next_action = _config_map_resource_state(item)
        write_scope = scope if scope in {"project", "user"} else "user"
        action = f" [{scope} {state}] [{write_scope} {next_action}]"
    return f"{item.section}: {item.label} - {item.value}{action}"


def _config_map_write_target_label(cwd: Path) -> str:
    user_path = tui_settings_path()
    project_path = project_tui_settings_path(cwd)
    return (
        "Write targets: "
        f"project resources ({_format_scoped_resource_path(project_path, cwd=cwd)}); "
        f"user resources ({_format_scoped_resource_path(user_path, cwd=cwd)})"
    )


def _effective_disabled_resource_paths(
    settings: TuiSettings,
    project_settings: ProjectTuiSettings,
) -> tuple[Path, ...]:
    paths = [
        *(Path(path) for path in settings.disabled_resource_paths),
        *(Path(path) for path in project_settings.disabled_resource_paths),
    ]
    return tuple(dict.fromkeys(_normalized_config_resource_path(path) for path in paths))


def _config_map_empty_label(screen: ConfigMapScreen) -> str:
    if screen.search_value:
        return f'No config rows match "{screen.search_value}"'
    return "No config rows available"


def _config_map_resource_state(item: ConfigMapItem) -> tuple[str, str, str]:
    """Return human-facing scope/state/action labels for a resource row."""
    scope = item.scope if item.scope != "all" else "resource"
    if item.section == "Disabled resources":
        return scope, "disabled", "enable"
    return scope, "enabled", "disable"


def _query_tokens(query: str) -> tuple[str, ...]:
    """Return Pi-style whitespace-or-slash search tokens."""
    return tuple(token for token in re.split(r"[\s/]+", query.casefold().strip()) if token)


def _query_tokens_match(tokens: Sequence[str], text: str) -> bool:
    if not tokens:
        return True
    searchable = text.casefold()
    return all(token in searchable for token in tokens)


def _app_bindings(keybindings: TuiKeybindings) -> list[Binding]:
    bindings = [
        Binding(keybindings.cancel, "cancel", "Cancel"),
        Binding(keybindings.command_palette, "open_command_palette", "Commands"),
        Binding(keybindings.session_picker, "open_session_picker", "Sessions"),
        *_optional_bindings(
            (
                (keybindings.session_new, "new_session", "New session"),
                (keybindings.session_tree, "open_tree_picker", "Tree"),
                (keybindings.session_fork, "open_fork_picker", "Fork"),
                (keybindings.session_resume, "open_session_picker", "Resume"),
            )
        ),
        Binding(keybindings.thinking_cycle, "cycle_thinking", "Thinking"),
        Binding(keybindings.model_cycle, "cycle_model", "Model"),
        Binding(keybindings.model_picker, "open_model_picker", "Model picker"),
        Binding(
            keybindings.accept_completion,
            "accept_completion",
            "Complete",
            priority=True,
        ),
        Binding(
            keybindings.queue_follow_up,
            "submit_follow_up",
            "Follow-up",
            priority=True,
        ),
        Binding(
            keybindings.completion_next,
            "completion_next",
            "Next completion",
            priority=True,
        ),
        Binding(
            keybindings.completion_previous,
            "completion_previous",
            "Previous completion",
            priority=True,
        ),
        Binding(keybindings.toggle_tool_results, "toggle_tool_results", "Tool results"),
        Binding(
            keybindings.dag_viewer_handoff,
            "open_dag_viewer_handoff",
            "DAG viewer",
            show=False,
        ),
        Binding(keybindings.toggle_thinking, "toggle_thinking", "Thinking tokens"),
        Binding(keybindings.external_editor, "open_external_editor", "Editor"),
        Binding(keybindings.paste_clipboard, "paste_clipboard", "Paste"),
        Binding(keybindings.dequeue_messages, "dequeue_messages", "Restore queued"),
        Binding(keybindings.copy_last_message, "copy_last_message", "Copy last message"),
        Binding(keybindings.copy_message, "clear_prompt", "Clear input"),
        Binding(keybindings.suspend, "suspend_process", "Suspend"),
        Binding(keybindings.quit, "quit", "Quit"),
    ]
    return bindings


def _prompt_bindings(
    keybindings: TuiKeybindings,
    *,
    mode: Literal["normal", "completion", "running"],
    dag_viewer_handoff_available: bool = False,
) -> list[Binding]:
    if mode == "completion":
        bindings = [
            Binding(
                keybindings.accept_completion,
                "accept_completion",
                "Complete",
                key_display=f"{_key_hint(keybindings.accept_completion)}/Enter",
                priority=True,
            ),
            Binding(
                keybindings.completion_next,
                "completion_next",
                "Choose",
                key_display=(
                    f"{_key_hint(keybindings.completion_previous)}/"
                    f"{_key_hint(keybindings.completion_next)}"
                ),
                priority=True,
            ),
            Binding(keybindings.cancel, "cancel", "Close", priority=True),
        ]
        return bindings + _hidden_prompt_bindings(keybindings, visible_bindings=bindings)
    if mode == "running":
        bindings = [
            Binding(keybindings.submit_prompt, "submit_prompt", "Steer", priority=True),
            Binding(keybindings.queue_follow_up, "submit_follow_up", "Follow-up", priority=True),
            Binding(keybindings.dequeue_messages, "dequeue_messages", "Restore", priority=True),
            Binding(keybindings.cancel, "cancel", "Cancel", priority=True),
            Binding(
                keybindings.toggle_thinking,
                "toggle_thinking",
                "Thinking",
                priority=True,
            ),
            Binding(
                keybindings.toggle_tool_results,
                "toggle_tool_results",
                "Tools",
                priority=True,
            ),
        ]
        return bindings + _hidden_prompt_bindings(keybindings, visible_bindings=bindings)
    bindings = [
        Binding(keybindings.submit_prompt, "submit_prompt", "Submit", priority=True),
        Binding(keybindings.insert_newline, "insert_newline", "Newline", priority=True),
        Binding(
            keybindings.command_palette,
            (
                "command_palette_or_delete_to_line_end"
                if keybindings.command_palette == "ctrl+k"
                else "open_command_palette"
            ),
            "Commands",
            priority=True,
        ),
        Binding(keybindings.session_picker, "open_session_picker", "Sessions", priority=True),
        *_optional_bindings(
            (
                (
                    keybindings.session_new,
                    "new_session",
                    "New",
                ),
                (keybindings.session_tree, "open_tree_picker", "Tree"),
                (keybindings.session_fork, "open_fork_picker", "Fork"),
                (keybindings.session_resume, "open_session_picker", "Resume"),
            ),
            priority=True,
        ),
        Binding(keybindings.external_editor, "open_external_editor", "Editor", priority=True),
        Binding(keybindings.paste_clipboard, "paste_clipboard", "Paste", priority=True),
        Binding(keybindings.thinking_cycle, "cycle_thinking", "Thinking", priority=True),
        Binding(keybindings.model_cycle, "cycle_model", "Model", priority=True),
        Binding(keybindings.model_picker, "open_model_picker", "Models", priority=True),
        *(
            [
                Binding(
                    keybindings.dag_viewer_handoff,
                    "open_dag_viewer_handoff",
                    "DAG viewer",
                    priority=True,
                )
            ]
            if dag_viewer_handoff_available
            else []
        ),
        Binding(
            keybindings.copy_message,
            "clear_prompt",
            "Clear",
            priority=True,
        ),
        Binding(keybindings.suspend, "suspend_process", "Suspend", priority=True),
        Binding(keybindings.quit, "quit", "Quit", priority=True),
    ]
    return bindings + _hidden_prompt_bindings(keybindings, visible_bindings=bindings)


type TmuxShowRunner = Callable[[str], str | None]


def _tmux_keyboard_setup_warning(
    env: Mapping[str, str],
    *,
    run_tmux_show: TmuxShowRunner | None = None,
) -> str | None:
    """Return a startup warning when tmux extended-key settings are unsuitable."""
    if not env.get("TMUX"):
        return None
    show = run_tmux_show or _run_tmux_show_option
    extended_keys = show("extended-keys")
    if extended_keys is None:
        return None
    if extended_keys not in {"on", "always"}:
        return (
            "tmux extended-keys is off. Modified Enter keys may not work. "
            "Add `set -g extended-keys on` to ~/.tmux.conf and restart tmux."
        )
    extended_keys_format = show("extended-keys-format")
    if extended_keys_format == "xterm":
        return (
            "tmux extended-keys-format is xterm. Tau works best with csi-u. "
            "Add `set -g extended-keys-format csi-u` to ~/.tmux.conf and restart tmux."
        )
    return None


def _run_tmux_show_option(option: str) -> str | None:
    try:
        completed = subprocess.run(
            ["tmux", "show", "-gv", option],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if completed.returncode != 0:
        return None
    return completed.stdout.strip()


def _hidden_prompt_bindings(
    keybindings: TuiKeybindings,
    *,
    visible_bindings: Sequence[Binding],
) -> list[Binding]:
    visible_keys = {key for binding in visible_bindings for key in binding.key.split(",")}
    candidates = (
        (keybindings.command_palette, "open_command_palette"),
        (keybindings.session_picker, "open_session_picker"),
        (keybindings.session_new, "new_session"),
        (keybindings.session_tree, "open_tree_picker"),
        (keybindings.session_fork, "open_fork_picker"),
        (keybindings.session_resume, "open_session_picker"),
        (keybindings.queue_follow_up, "submit_follow_up"),
        (keybindings.dequeue_messages, "dequeue_messages"),
        (keybindings.thinking_cycle, "cycle_thinking"),
        (keybindings.model_cycle, "cycle_model"),
        (keybindings.model_cycle_previous, "cycle_model_previous"),
        (keybindings.model_picker, "open_model_picker"),
        (keybindings.external_editor, "open_external_editor"),
        (keybindings.paste_clipboard, "paste_clipboard"),
        (keybindings.copy_last_message, "copy_last_message"),
        (keybindings.toggle_tool_results, "toggle_tool_results"),
        (keybindings.dag_viewer_handoff, "open_dag_viewer_handoff"),
        (keybindings.toggle_thinking, "toggle_thinking"),
        (keybindings.copy_message, "clear_prompt"),
        (keybindings.suspend, "suspend_process"),
        (keybindings.accept_completion, "accept_completion"),
        (keybindings.completion_next, "completion_next"),
        (keybindings.completion_previous, "completion_previous"),
        (keybindings.quit, "quit"),
    )
    return [
        Binding(key, action, show=False, priority=True)
        for key, action in candidates
        if key and key not in visible_keys
    ]


def _optional_bindings(
    entries: Sequence[tuple[str, str, str]],
    *,
    priority: bool = False,
) -> list[Binding]:
    return [
        Binding(key, action, description, priority=priority)
        for key, action, description in entries
        if key
    ]


def _text_end_location(text: str) -> tuple[int, int]:
    """Return the TextArea cursor location at the end of text."""
    line, _, column_text = text.rpartition("\n")
    return (line.count("\n") + 1 if line else 0, len(column_text))


def _format_prompt_error(exc: BaseException, session: CodingSession) -> str:
    detail = str(exc) or type(exc).__name__
    message = f"Error: {detail}"
    log_path = getattr(session, "last_diagnostic_log_path", None)
    if isinstance(log_path, Path):
        return f"{message}\nLog: {log_path}"
    return message


def _attach_diagnostic_log_path_to_error(state: TuiState, session: CodingSession) -> None:
    log_path = getattr(session, "last_diagnostic_log_path", None)
    if not isinstance(log_path, Path) or state.error is None:
        return
    message = f"Error: {state.error}\nLog: {log_path}"
    state.error = message
    for item in reversed(state.items):
        if item.role == "error":
            item.text = message
            return
    state.add_item("error", message)


def _explicit_resume_record(
    manager: SessionManager,
    *,
    session_id: str | None,
) -> CodingSessionRecord | None:
    if session_id is None:
        return None
    record = manager.get_session(session_id)
    if record is None:
        raise RuntimeError(f"Unknown session: {session_id}")
    return record


def _latest_cwd_session_record(
    manager: SessionManager,
    *,
    cwd: Path,
) -> CodingSessionRecord:
    record = manager.latest_session_for_cwd(cwd)
    if record is None:
        raise RuntimeError(
            "No previous session found for this cwd; start one with `tau --new-session`."
        )
    return record


class _EphemeralSessionStorage:
    """Append-only in-memory storage for --no-session TUI runs."""

    def __init__(self) -> None:
        self.entries: list[Any] = []

    async def append(self, entry: Any) -> None:
        self.entries.append(entry)

    async def read_all(self) -> list[Any]:
        return list(self.entries)


def _create_startup_session_record(
    manager: SessionManager,
    *,
    cwd: Path,
    selection: ProviderSelection,
    title: str | None = None,
    session_id: str | None = None,
) -> CodingSessionRecord:
    if session_id is not None:
        return manager.create_session(
            cwd=cwd,
            model=selection.model,
            provider_name=selection.provider.name,
            title=title,
            session_id=session_id,
        )
    try:
        return manager.create_session(
            cwd=cwd,
            model=selection.model,
            provider_name=selection.provider.name,
            title=title,
        )
    except TypeError:
        try:
            return manager.create_session(
                cwd=cwd,
                model=selection.model,
                provider_name=selection.provider.name,
            )
        except TypeError:
            return manager.create_session(cwd=cwd, model=selection.model)


def _truthy_env(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


def _resolve_tui_startup_selection(
    settings: Any,
    *,
    record: Any | None,
    provider_name: str | None,
    model: str | None,
    explicit_resume: bool,
) -> ProviderSelection:
    if provider_name is not None or model is not None:
        return resolve_provider_selection(settings, provider_name=provider_name, model=model)

    if explicit_resume:
        record_selection = _selection_from_session_record(settings, record)
        if record_selection is not None:
            return record_selection

    default_selection = resolve_provider_selection(settings)
    if provider_has_usable_credentials(
        default_selection.provider,
        credential_reader=FileCredentialStore(),
    ):
        return default_selection

    fallback_selection = _first_usable_startup_selection(settings)
    return fallback_selection or default_selection


def _first_usable_startup_selection(settings: Any) -> ProviderSelection | None:
    credential_store = FileCredentialStore()
    for provider in settings.providers:
        if provider_has_usable_credentials(provider, credential_reader=credential_store):
            return ProviderSelection(provider=provider, model=provider.default_model)
    return None


def _selection_from_session_record(settings: Any, record: Any | None) -> ProviderSelection | None:
    if record is None:
        return None
    record_model = getattr(record, "model", None)
    if not isinstance(record_model, str) or not record_model:
        return None

    record_provider = getattr(record, "provider_name", None)
    if isinstance(record_provider, str) and record_provider:
        try:
            return resolve_provider_selection(
                settings,
                provider_name=record_provider,
                model=record_model,
            )
        except Exception:
            return None

    for choice in _usable_scoped_startup_choices(settings):
        if choice.model == record_model:
            return resolve_provider_selection(
                settings,
                provider_name=choice.provider_name,
                model=choice.model,
            )

    for provider in settings.providers:
        if record_model in provider.models:
            return ProviderSelection(provider=provider, model=record_model)
    return None


def _usable_scoped_startup_choices(settings: Any) -> tuple[ModelChoice, ...]:
    credential_store = FileCredentialStore()
    choices: list[ModelChoice] = []
    for item in settings.scoped_models:
        try:
            provider = settings.get_provider(item.provider)
        except Exception:
            continue
        if item.model not in provider.models:
            continue
        if not provider_has_usable_credentials(provider, credential_reader=credential_store):
            continue
        choices.append(ModelChoice(provider_name=item.provider, model=item.model))
    return tuple(choices)


async def run_tui_app(
    *,
    model: str | None,
    cwd: Path,
    session_id: str | None = None,
    new_session: bool = False,
    provider_name: str | None = None,
    auto_compact_token_threshold: int | None = None,
    thinking_level: ThinkingLevel | None = None,
    custom_system_prompt: str | None = None,
    append_system_prompt: str | None = None,
    initial_prompt: str | None = None,
    session_name: str | None = None,
    continue_session: bool = False,
    resume_picker: bool = False,
    no_session: bool = False,
    exact_session_id: str | None = None,
    session_manager: SessionManager | None = None,
    provider_settings: ProviderSettings | None = None,
    default_project_trust: DefaultProjectTrust | None = None,
    no_context_files: bool = False,
    tool_allowlist: tuple[str, ...] | None = None,
    tool_denylist: tuple[str, ...] = (),
    no_tools: bool = False,
    no_builtin_tools: bool = False,
    no_skills: bool = False,
    no_prompt_templates: bool = False,
    no_themes: bool = False,
    no_extensions: bool = False,
    skill_paths: tuple[Path, ...] = (),
    prompt_template_paths: tuple[Path, ...] = (),
    theme_paths: tuple[Path, ...] = (),
    extension_paths: tuple[Path, ...] = (),
    extension_flag_values: Mapping[str, bool | str] | None = None,
) -> str | None:
    """Create the default provider/session, run the Textual app, and return the session id."""
    if new_session and session_id is not None:
        raise RuntimeError("--session and --new-session cannot be used together")
    if exact_session_id is not None and session_id is not None:
        raise RuntimeError("--session-id and --session cannot be used together")
    if continue_session and session_id is not None:
        raise RuntimeError("--continue and --session cannot be used together")
    if continue_session and exact_session_id is not None:
        raise RuntimeError("--session-id and --continue cannot be used together")
    if resume_picker and session_id is not None:
        raise RuntimeError("--resume and --session cannot be used together")
    if resume_picker and exact_session_id is not None:
        raise RuntimeError("--session-id and --resume cannot be used together")
    if continue_session and new_session:
        raise RuntimeError("--continue and --new-session cannot be used together")
    if resume_picker and continue_session:
        raise RuntimeError("--resume and --continue cannot be used together")
    if resume_picker and new_session:
        raise RuntimeError("--resume and --new-session cannot be used together")
    if continue_session and session_name is not None:
        raise RuntimeError("--continue and --name cannot be used together")
    if resume_picker and session_name is not None:
        raise RuntimeError("--resume and --name cannot be used together")
    if no_session and session_id is not None:
        raise RuntimeError("--no-session and --session cannot be used together")
    if no_session and exact_session_id is not None:
        raise RuntimeError("--session-id and --no-session cannot be used together")
    if no_session and resume_picker:
        raise RuntimeError("--no-session and --resume cannot be used together")
    if no_session and continue_session:
        raise RuntimeError("--no-session and --continue cannot be used together")
    if no_session and new_session:
        raise RuntimeError("--no-session and --new-session cannot be used together")
    if no_session and session_name is not None:
        raise RuntimeError("--no-session and --name cannot be used together")

    provider_settings = provider_settings or load_provider_settings()
    first_time_setup = _should_show_first_time_setup()
    tui_settings = load_tui_settings()
    if _truthy_env("TAU_VERBOSE_STARTUP"):
        tui_settings = replace(tui_settings, quiet_startup=False)
    startup_thinking_level = thinking_level or tui_settings.thinking_level
    manager = None if no_session else session_manager or SessionManager()
    if no_session or resume_picker:
        record = None
    elif continue_session:
        assert manager is not None
        record = _latest_cwd_session_record(manager, cwd=cwd)
    elif exact_session_id is not None:
        assert manager is not None
        record = manager.get_session(exact_session_id)
    else:
        assert manager is not None
        record = _explicit_resume_record(
            manager,
            session_id=session_id,
        )
    selection = _resolve_tui_startup_selection(
        provider_settings,
        record=record,
        provider_name=provider_name,
        model=model,
        explicit_resume=session_id is not None or continue_session or record is not None,
    )
    startup_message: str | None = None
    runtime_provider_config: ProviderConfig | None = selection.provider
    try:
        provider = create_model_provider(
            selection.provider,
            model=selection.model,
            thinking_level=startup_thinking_level,
        )
    except RuntimeError:
        startup_message = (
            "Login required. Run /login to choose a provider, "
            f"or /login {selection.provider.name} to continue with the current provider."
        )
        provider = LoginRequiredProvider(startup_message)
        runtime_provider_config = None
    session: CodingSession | None = None
    try:
        if record is None:
            if no_session or resume_picker:
                storage = _EphemeralSessionStorage()
                startup_session_id = None
                startup_session_manager = manager if resume_picker else None
                startup_cwd = cwd
                startup_model = selection.model
            else:
                assert manager is not None
                record = _create_startup_session_record(
                    manager,
                    cwd=cwd,
                    selection=selection,
                    title=session_name,
                    session_id=exact_session_id,
                )
                storage = jsonl_session_storage(record.path)
                startup_session_id = record.id
                startup_session_manager = manager
                startup_cwd = record.cwd
                startup_model = record.model or selection.model
        else:
            storage = jsonl_session_storage(record.path)
            startup_session_id = record.id
            startup_session_manager = manager
            startup_cwd = record.cwd
            startup_model = record.model or selection.model

        project_tui_settings = load_project_tui_settings(startup_cwd)
        session = await CodingSession.load(
            CodingSessionConfig(
                provider=provider,
                model=startup_model,
                cwd=startup_cwd,
                storage=storage,
                session_id=startup_session_id,
                session_manager=startup_session_manager,
                provider_name=selection.provider.name,
                provider_settings=provider_settings,
                runtime_provider_config=runtime_provider_config,
                custom_system_prompt=custom_system_prompt,
                append_system_prompt=append_system_prompt,
                auto_compact_token_threshold=auto_compact_token_threshold,
                auto_compact_enabled=tui_settings.auto_compact,
                steering_queue_mode=_agent_queue_mode_from_tui(tui_settings.steering_mode),
                follow_up_queue_mode=_agent_queue_mode_from_tui(tui_settings.follow_up_mode),
                default_project_trust=default_project_trust or tui_settings.default_project_trust,
                thinking_level=startup_thinking_level,
                shell_path=tui_settings.shell_path,
                shell_command_prefix=tui_settings.shell_command_prefix,
                auto_resize_images=tui_settings.auto_resize_images,
                disabled_resource_paths=_effective_disabled_resource_paths(
                    tui_settings,
                    project_tui_settings,
                ),
                discover_context_files=not no_context_files,
                tool_allowlist=tool_allowlist,
                tool_denylist=tool_denylist,
                no_tools=no_tools,
                no_builtin_tools=no_builtin_tools,
                discover_skills=not no_skills,
                discover_prompt_templates=not no_prompt_templates,
                discover_themes=not no_themes,
                discover_extensions=not no_extensions,
                skill_paths=skill_paths,
                prompt_template_paths=prompt_template_paths,
                theme_paths=theme_paths,
                extension_paths=extension_paths,
                extension_flag_values=extension_flag_values or {},
            )
        )
        set_provider_timeout = getattr(session, "set_provider_timeout_seconds", None)
        if callable(set_provider_timeout):
            set_provider_timeout(
                _provider_timeout_seconds_from_http_idle_timeout_ms(
                    tui_settings.http_idle_timeout_ms
                )
            )
        app = TauTuiApp(
            session,
            tui_settings=tui_settings,
            project_tui_settings=project_tui_settings,
            startup_message=startup_message,
            initial_prompt=initial_prompt,
            startup_resume_picker=resume_picker,
            show_first_time_setup=first_time_setup,
        )
        await app.run_async()
        return getattr(session, "session_id", None) or startup_session_id
    finally:
        if session is not None:
            close_session = getattr(session, "aclose", None)
            if close_session is not None:
                await close_session()
        await provider.aclose()


def _should_show_first_time_setup(settings_path: Path | None = None) -> bool:
    """Return whether Tau should show Pi-style first-run setup."""
    path = settings_path or tui_settings_path()
    return not path.exists()


def _extension_terminal_input_result(result: object) -> str | None:
    """Normalize Pi-style terminal input listener results."""
    if result is None:
        return None
    if isinstance(result, str):
        return result
    if isinstance(result, Mapping):
        data = result.get("data")
        if data is not None:
            return str(data)
        if bool(result.get("consume", False)):
            return ""
    return None


class _TauAutocompleteProvider:
    """Small provider object passed through Pi-style autocomplete factories."""

    def __init__(self, state: CompletionState) -> None:
        self._state = state

    def get_completions(
        self,
        text: str,
        cursor_position: int | None = None,
    ) -> CompletionState:
        del text, cursor_position
        return self._state

    def getSuggestions(  # noqa: N802 - Pi-compatible method name
        self,
        lines: Sequence[str],
        cursor_line: int,
        cursor_col: int,
        options: object | None = None,
    ) -> dict[str, object] | None:
        del lines, cursor_line, cursor_col, options
        if not self._state.items:
            return None
        return {
            "items": [
                {
                    "value": item.replacement,
                    "label": item.display,
                    "description": item.description,
                }
                for item in self._state.items
            ],
            "prefix": "",
        }


def _extension_autocomplete_completion_state(
    text: str,
    *,
    cursor_position: int | None,
    base_state: CompletionState,
    providers: Sequence[tuple[str, Callable[[object], object]]],
    notify: Callable[[str], None],
) -> CompletionState:
    provider: object = _TauAutocompleteProvider(base_state)
    for extension_name, factory in providers:
        try:
            provider = factory(provider)
        except Exception as exc:  # noqa: BLE001 - extension failures should surface, not crash
            notify(f"Extension autocomplete provider error ({extension_name}): {exc}")
            continue
    state = _extension_autocomplete_provider_state(
        provider,
        text=text,
        cursor_position=cursor_position,
    )
    return state if state is not None else base_state


async def _extension_autocomplete_completion_state_async(
    text: str,
    *,
    cursor_position: int | None,
    base_state: CompletionState,
    providers: Sequence[tuple[str, Callable[[object], object]]],
    notify: Callable[[str], None],
) -> CompletionState:
    provider: object = _TauAutocompleteProvider(base_state)
    for extension_name, factory in providers:
        try:
            provider = factory(provider)
            if isawaitable(provider):
                provider = await provider
        except Exception as exc:  # noqa: BLE001 - extension failures should surface, not crash
            notify(f"Extension autocomplete provider error ({extension_name}): {exc}")
            continue
    state = await _extension_autocomplete_provider_state_async(
        provider,
        text=text,
        cursor_position=cursor_position,
    )
    return state if state is not None else base_state


def _extension_autocomplete_provider_state(
    provider: object,
    *,
    text: str,
    cursor_position: int | None,
) -> CompletionState | None:
    get_completions = getattr(provider, "get_completions", None)
    if callable(get_completions):
        result = get_completions(text, cursor_position)
        return _extension_autocomplete_result_state(
            result,
            text=text,
            cursor_position=cursor_position,
        )
    get_suggestions = getattr(provider, "getSuggestions", None)
    if callable(get_suggestions):
        cursor = len(text) if cursor_position is None else max(0, min(cursor_position, len(text)))
        lines = text.splitlines() or [""]
        cursor_line, cursor_col = _line_col_from_position(text, cursor)
        result = get_suggestions(lines, cursor_line, cursor_col, {"force": False})
        return _extension_autocomplete_result_state(
            result,
            text=text,
            cursor_position=cursor,
        )
    if callable(provider):
        result = provider(text, cursor_position)
        return _extension_autocomplete_result_state(
            result,
            text=text,
            cursor_position=cursor_position,
        )
    return _extension_autocomplete_result_state(
        provider,
        text=text,
        cursor_position=cursor_position,
    )


async def _extension_autocomplete_provider_state_async(
    provider: object,
    *,
    text: str,
    cursor_position: int | None,
) -> CompletionState | None:
    get_completions = getattr(provider, "get_completions", None)
    if callable(get_completions):
        result = get_completions(text, cursor_position)
        if isawaitable(result):
            result = await result
        return _extension_autocomplete_result_state(
            result,
            text=text,
            cursor_position=cursor_position,
        )
    get_suggestions = getattr(provider, "getSuggestions", None)
    if callable(get_suggestions):
        cursor = len(text) if cursor_position is None else max(0, min(cursor_position, len(text)))
        lines = text.splitlines() or [""]
        cursor_line, cursor_col = _line_col_from_position(text, cursor)
        result = get_suggestions(lines, cursor_line, cursor_col, {"force": False})
        if isawaitable(result):
            result = await result
        return _extension_autocomplete_result_state(
            result,
            text=text,
            cursor_position=cursor,
        )
    if callable(provider):
        result = provider(text, cursor_position)
        if isawaitable(result):
            result = await result
        return _extension_autocomplete_result_state(
            result,
            text=text,
            cursor_position=cursor_position,
        )
    return _extension_autocomplete_result_state(
        provider,
        text=text,
        cursor_position=cursor_position,
    )


def _extension_autocomplete_result_state(
    result: object,
    *,
    text: str,
    cursor_position: int | None,
) -> CompletionState | None:
    cursor = len(text) if cursor_position is None else max(0, min(cursor_position, len(text)))
    if result is None:
        return None
    if isinstance(result, CompletionState):
        return result
    if isinstance(result, CompletionItem):
        return CompletionState((result,))
    if isinstance(result, Mapping):
        items = result.get("items")
        if items is None:
            item = _extension_autocomplete_item(result, cursor=cursor)
            return CompletionState((item,)) if item is not None else None
        prefix = str(result.get("prefix", ""))
        start = max(0, cursor - len(prefix))
        completions = tuple(
            item
            for raw in _extension_autocomplete_iter_items(items)
            if (item := _extension_autocomplete_item(raw, cursor=cursor, start=start)) is not None
        )
        return CompletionState(completions)
    if isinstance(result, str):
        return CompletionState(
            (
                CompletionItem(
                    display=result,
                    replacement=result,
                    start=cursor,
                    end=cursor,
                    category="extension",
                ),
            )
        )
    if isinstance(result, Sequence):
        completions = tuple(
            item
            for raw in result
            if (item := _extension_autocomplete_item(raw, cursor=cursor)) is not None
        )
        return CompletionState(completions)
    return None


def _extension_autocomplete_iter_items(items: object) -> tuple[object, ...]:
    if isinstance(items, Sequence) and not isinstance(items, str):
        return tuple(items)
    return ()


def _extension_autocomplete_item(
    raw: object,
    *,
    cursor: int,
    start: int | None = None,
) -> CompletionItem | None:
    resolved_start = cursor if start is None else start
    if isinstance(raw, CompletionItem):
        return raw
    if isinstance(raw, str):
        return CompletionItem(
            display=raw,
            replacement=raw,
            start=resolved_start,
            end=cursor,
            category="extension",
        )
    if not isinstance(raw, Mapping):
        return None
    value = raw.get("replacement", raw.get("value", raw.get("label")))
    if value is None:
        return None
    display = str(raw.get("display", raw.get("label", value)))
    item_start = raw.get("start", resolved_start)
    item_end = raw.get("end", cursor)
    try:
        normalized_start = int(item_start)
        normalized_end = int(item_end)
    except (TypeError, ValueError):
        normalized_start = resolved_start
        normalized_end = cursor
    return CompletionItem(
        display=display,
        replacement=str(value),
        start=max(0, normalized_start),
        end=max(0, normalized_end),
        description=(
            None if raw.get("description") is None else str(raw.get("description"))
        ),
        category=None if raw.get("category") is None else str(raw.get("category")),
        argument_hint=None if raw.get("argument_hint") is None else str(raw.get("argument_hint")),
    )


def _line_col_from_position(text: str, position: int) -> tuple[int, int]:
    before = text[:position]
    line = before.count("\n")
    last_newline = before.rfind("\n")
    col = position if last_newline == -1 else position - last_newline - 1
    return line, col


def _terminal_input_event_data(event: Key) -> str:
    """Return the terminal input payload seen by extension listeners."""
    character = getattr(event, "character", None)
    if character is not None:
        return str(character)
    return event.key


def _extension_custom_content_text(content: object) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, Sequence) and not isinstance(content, str):
        return "\n".join(str(line) for line in content)
    return str(content)


def _extension_component_widget(content: object) -> Widget:
    if isinstance(content, Widget):
        return content
    return Static(_extension_custom_content_text(content))


def _dispose_extension_component_children(container: Widget) -> None:
    for child in tuple(container.children):
        if getattr(child, "_tau_extension_disposed", False):
            continue
        dispose = getattr(child, "dispose", None)
        if callable(dispose):
            child._tau_extension_disposed = True
            dispose()


class _TauFooterDataProvider:
    """Readonly footer data exposed to Pi-style extension footer factories."""

    def __init__(self, app: TauTuiApp) -> None:
        self._app = app

    def getGitBranch(self) -> str | None:  # noqa: N802
        """Return the current git branch for the session cwd."""
        return _git_branch(self._app.session.cwd)

    def getExtensionStatuses(self) -> Mapping[str, str]:  # noqa: N802
        """Return extension status texts set through ctx.ui.setStatus."""
        return dict(self._app._extension_statuses)

    def getAvailableProviderCount(self) -> int:  # noqa: N802
        """Return how many providers the active session exposes."""
        return len(getattr(self._app.session, "available_providers", ()))

    def onBranchChange(self, callback: Callable[[], object]) -> Callable[[], None]:  # noqa: N802
        """Subscribe to git branch notifications and return an unsubscribe hook."""
        return self._app._register_extension_footer_branch_listener(callback)


class _PtyProofRealAppSessionState:
    thinking_level = "medium"
    loop_monitor_status = None


class _PtyProofRealAppSession:
    """Minimal session for PTY proof mode that still runs ``TauTuiApp``."""

    def __init__(self, *, cwd: Path) -> None:
        self.cwd = cwd
        self.provider_name = "pty-proof"
        self.model = "real-tau-tui-app"
        self.available_models = ("real-tau-tui-app",)
        self.available_model_choices = (
            ModelChoice(provider_name="pty-proof", model="real-tau-tui-app"),
        )
        self.scoped_model_choices: tuple[ModelChoice, ...] = ()
        self.available_providers = ("pty-proof",)
        self.tools: tuple[AgentTool, ...] = ()
        self.skills: tuple[object, ...] = ()
        self.prompt_templates: tuple[object, ...] = ()
        self.context_files = (
            ProjectContextFile(path=str(cwd / "AGENTS.md"), content="PTY proof mode."),
        )
        self.context_token_estimate = 0
        self.auto_compact_token_threshold = 200000
        self.context_window_tokens = 216384
        self.thinking_level = "medium"
        self.available_thinking_levels = ("off", "minimal", "low", "medium", "high")
        self.resource_diagnostics: tuple[object, ...] = ()
        self.session_manager = None
        self.state = _PtyProofRealAppSessionState()
        self.messages: tuple[AgentMessage, ...] = ()

    def handle_command(self, text: str) -> CommandResult:
        del text
        return CommandResult(handled=False)

    def queue_update_event(self) -> QueueUpdateEvent:
        return QueueUpdateEvent(steering=(), follow_up=())

    async def prompt(
        self,
        text: str,
        *,
        streaming_behavior: str | None = None,
    ) -> AsyncIterator[AgentEvent]:
        del text, streaming_behavior
        if False:
            yield AgentStartEvent()


def run_pty_proof_real_app() -> None:
    """Run the real ``TauTuiApp`` class in deterministic PTY proof mode."""

    os.environ.setdefault("TAU_TUI_PTY_PROOF", "1")
    cwd = Path.cwd()
    app = TauTuiApp(cast(CodingSession, _PtyProofRealAppSession(cwd=cwd)))
    app.run()


def main() -> None:
    """Run module entrypoints for ``python -m tau_coding.tui.app``."""

    if "--pty-proof-real-app" in sys.argv[1:]:
        run_pty_proof_real_app()
        return
    raise SystemExit("Usage: python -m tau_coding.tui.app --pty-proof-real-app")


if __name__ == "__main__":
    main()
