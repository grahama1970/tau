"""Execution boundary for Tau's packaged workflows."""

from __future__ import annotations

import hashlib
import json
import sys
import threading
import time
import webbrowser
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from tau_coding.approval_gate import evaluate_approval_gate
from tau_coding.dag_runtime.run_store import DagRunStoreError
from tau_coding.dag_viewer.server import RunningDagViewerServer, create_dag_viewer_server
from tau_coding.generic_dag import run_generic_dag
from tau_coding.workflows.catalog import get_workflow
from tau_coding.workflows.contracts import WORKFLOW_RUN_RECEIPT_SCHEMA
from tau_coding.workflows.materialize import (
    MaterializedWorkflow,
    materialize_approved_release_bundle,
    materialize_durable_repository_qualification,
    materialize_repository_evidence_map,
    materialize_repository_readiness,
    materialize_tau_operator_reference,
)


def run_durable_repository_qualification_workflow(
    *,
    repo_path: Path,
    human_goal: str,
    publish_path: Path,
    run_dir: Path,
    open_viewer: bool,
    browser_open: bool,
    viewer_hold_seconds: float | None,
    inject_test_branch_failure: bool = False,
    crash_after_staged_node_id: str | None = None,
    step_delay_seconds: float = 0.0,
) -> dict[str, object]:
    materialized = materialize_durable_repository_qualification(
        definition=get_workflow("durable-repository-qualification"),
        repo_path=repo_path,
        human_goal=human_goal,
        publish_path=publish_path,
        run_dir=run_dir,
        inject_test_branch_failure=inject_test_branch_failure,
        step_delay_seconds=step_delay_seconds,
    )
    fault_injector: Callable[[str, Mapping[str, Any]], None] | None = None
    if crash_after_staged_node_id is not None:
        valid_node_ids = {
            "capture-repository",
            "qualify-documentation",
            "qualify-tests",
            "qualify-package",
            "reconcile-qualification",
        }
        if crash_after_staged_node_id not in valid_node_ids:
            raise RuntimeError("diagnostic crash node is invalid")

        def inject(point: str, context: Mapping[str, Any]) -> None:
            if (
                point == "after_result_staged"
                and context.get("node_id") == crash_after_staged_node_id
            ):
                raise RuntimeError(
                    f"diagnostic_injected_crash_after_staged:{crash_after_staged_node_id}"
                )

        fault_injector = inject
    return _run_materialized_workflow(
        materialized=materialized,
        result_filename="durable-repository-qualification.json",
        open_viewer=open_viewer,
        browser_open=browser_open,
        viewer_hold_seconds=viewer_hold_seconds,
        fault_injector=fault_injector,
    )


def repair_durable_repository_qualification(
    *,
    run_dir: Path,
    node_id: str,
    approval_packet: Path | None = None,
) -> dict[str, object]:
    resolved = run_dir.expanduser().resolve()
    if node_id != "qualify-tests":
        raise RuntimeError("only qualify-tests is repairable in this workflow")
    request = _read_object(
        resolved / "input" / "durable-qualification-request.json",
        "durable qualification request",
    )
    receipt = _read_object(resolved / "receipts" / f"{node_id}.json", "blocked receipt")
    if receipt.get("status") != "BLOCKED" or receipt.get("errors") != ["targeted_repair_required"]:
        raise RuntimeError("qualify-tests is not blocked on targeted_repair_required")
    goal = request.get("goal")
    if not isinstance(goal, dict) or receipt.get("goal_hash") != goal.get("goal_hash"):
        raise RuntimeError("blocked receipt goal hash does not match the active goal")
    target = {
        "id": f"durable-repository-qualification:{node_id}:{goal['goal_hash']}",
        "workflow_id": "durable-repository-qualification",
        "node_id": node_id,
        "goal_hash": str(goal["goal_hash"]),
    }
    approval_receipt_path = resolved / "transactions" / node_id / "repair-approval-gate.json"
    if approval_packet is None:
        return _write_workflow_repair_receipt(
            run_dir=resolved,
            status="BLOCKED",
            ok=False,
            node_id=node_id,
            goal_hash=str(goal["goal_hash"]),
            repair_packet_path=None,
            approval_packet_path=None,
            approval_gate_receipt_path=approval_receipt_path,
            errors=["approval_packet_required"],
        )
    source_packet_path = approval_packet.expanduser().resolve()
    approval_receipt = evaluate_approval_gate(
        approval_packet=source_packet_path,
        requested_action="workflow_repair",
        run_dir=approval_receipt_path.parent,
        output=approval_receipt_path,
        expected_target=target,
    )
    if approval_receipt.get("status") != "PASS":
        return _write_workflow_repair_receipt(
            run_dir=resolved,
            status="BLOCKED",
            ok=False,
            node_id=node_id,
            goal_hash=str(goal["goal_hash"]),
            repair_packet_path=None,
            approval_packet_path=source_packet_path,
            approval_gate_receipt_path=approval_receipt_path,
            errors=[
                str(error) for error in approval_receipt.get("errors", []) if isinstance(error, str)
            ],
        )
    packet = {
        "schema": "tau.workflow_repair_packet.v1",
        "authorized": True,
        "origin": "machine",
        "actor": {"id": "tau:workflow-repair", "auth_method": "approval-gate-receipt"},
        "authorization": {
            "schema": "tau.approval_gate_receipt.v1",
            "path": str(approval_receipt_path),
            "sha256": _file_sha256(approval_receipt_path),
        },
        "node_id": node_id,
        "goal_hash": goal["goal_hash"],
        "request_sha256": request["request_sha256"],
        "reason": "Repair only the blocked test qualification branch.",
        "evidence": [str(resolved / "receipts" / f"{node_id}.json")],
    }
    packet_path = resolved / "input" / "repair-qualify-tests.json"
    packet_path.write_text(json.dumps(packet, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return _write_workflow_repair_receipt(
        run_dir=resolved,
        status="PASS",
        ok=True,
        node_id=node_id,
        goal_hash=str(goal["goal_hash"]),
        repair_packet_path=packet_path,
        approval_packet_path=source_packet_path,
        approval_gate_receipt_path=approval_receipt_path,
        errors=[],
    )


def approve_packaged_workflow(
    *, run_dir: Path, approval_packet: Path | None = None
) -> dict[str, object]:
    resolved = run_dir.expanduser().resolve()
    if (resolved / "input" / "durable-qualification-request.json").is_file():
        return _approve_transaction(
            run_dir=resolved,
            workflow_id="durable-repository-qualification",
            transaction_node_id="publish-qualification",
            reason="Human approved the exact accepted repository qualification.",
            approval_packet=approval_packet,
        )
    return approve_approved_release_bundle(
        run_dir=resolved,
        approval_packet=approval_packet,
    )


def resume_packaged_workflow(*, run_dir: Path) -> dict[str, object]:
    resolved = run_dir.expanduser().resolve()
    request_path = resolved / "input" / "durable-qualification-request.json"
    if not request_path.is_file():
        return resume_approved_release_bundle(run_dir=resolved)
    request = _read_object(request_path, "durable qualification request")
    goal = request.get("goal")
    if not isinstance(goal, dict):
        raise RuntimeError("durable qualification request goal is missing")
    definition = get_workflow("durable-repository-qualification")
    materialized = MaterializedWorkflow(
        definition=definition,
        request_path=request_path,
        source_dag_path=resolved / "workflow" / "dag.json",
        run_dir=resolved,
        run_id=str(_read_object(resolved / "workflow" / "dag.json", "workflow DAG")["run_id"]),
        goal=goal,
    )
    dag_receipt = _resume_durable_after_fencing(materialized.source_dag_path)
    return _write_workflow_receipt(
        materialized,
        dag_receipt,
        result_filename="durable-repository-qualification.json",
        viewer=None,
    )


def _resume_durable_after_fencing(spec_path: Path) -> dict[str, Any]:
    try:
        return run_generic_dag(spec_path=spec_path, resume=True)
    except DagRunStoreError as exc:
        if exc.code != "dag_run_lease_held":
            raise
    time.sleep(15.25)
    return run_generic_dag(spec_path=spec_path, resume=True)


def _approve_transaction(
    *,
    run_dir: Path,
    workflow_id: str,
    transaction_node_id: str,
    reason: str,
    approval_packet: Path | None,
) -> dict[str, object]:
    gate_path = run_dir / "transactions" / transaction_node_id / "approval-gate-receipt.json"
    gate = _read_object(gate_path, "approval gate receipt")
    target = gate.get("expected_target")
    if not isinstance(target, dict):
        raise RuntimeError("approval gate receipt has no exact expected_target")
    packet_path = run_dir / "input" / "approval.json"
    if approval_packet is None:
        return _write_workflow_approval_receipt(
            run_dir=run_dir,
            workflow_id=workflow_id,
            status="BLOCKED",
            ok=False,
            approval_packet_path=None,
            target=target,
            errors=["approval_packet_required"],
        )

    source_packet_path = approval_packet.expanduser().resolve()
    validation_receipt = evaluate_approval_gate(
        approval_packet=source_packet_path,
        requested_action="generic_dag_transaction_continue",
        run_dir=gate_path.parent,
        output=gate_path,
        expected_target={str(key): str(value) for key, value in target.items()},
    )
    if validation_receipt.get("status") != "PASS":
        return _write_workflow_approval_receipt(
            run_dir=run_dir,
            workflow_id=workflow_id,
            status="BLOCKED",
            ok=False,
            approval_packet_path=source_packet_path,
            target=target,
            errors=[
                str(error)
                for error in validation_receipt.get("errors", [])
                if isinstance(error, str)
            ],
        )
    if source_packet_path != packet_path.resolve():
        packet_path.write_bytes(source_packet_path.read_bytes())
    final_gate_receipt = evaluate_approval_gate(
        approval_packet=packet_path,
        requested_action="generic_dag_transaction_continue",
        run_dir=gate_path.parent,
        output=gate_path,
        expected_target={str(key): str(value) for key, value in target.items()},
    )
    return _write_workflow_approval_receipt(
        run_dir=run_dir,
        workflow_id=workflow_id,
        status="PASS" if final_gate_receipt.get("status") == "PASS" else "BLOCKED",
        ok=final_gate_receipt.get("status") == "PASS",
        approval_packet_path=packet_path,
        target=target,
        errors=[
            str(error) for error in final_gate_receipt.get("errors", []) if isinstance(error, str)
        ],
    )


def _write_workflow_approval_receipt(
    *,
    run_dir: Path,
    workflow_id: str,
    status: str,
    ok: bool,
    approval_packet_path: Path | None,
    target: dict[str, object],
    errors: list[str],
) -> dict[str, object]:
    receipt = {
        "schema": "tau.workflow_approval_receipt.v1",
        "status": status,
        "ok": ok,
        "workflow_id": workflow_id,
        "run_dir": str(run_dir),
        "approval_packet_path": str(approval_packet_path) if approval_packet_path else None,
        "target": target,
        "errors": errors,
    }
    receipt_path = run_dir / "receipts" / "workflow-approval.json"
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    receipt_path.write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return {**receipt, "receipt_path": str(receipt_path)}


def run_approved_release_bundle_workflow(
    *,
    repo_path: Path,
    human_goal: str,
    publish_path: Path,
    run_dir: Path,
    open_viewer: bool,
    browser_open: bool,
    viewer_hold_seconds: float | None,
    force_terminal_failure: bool = False,
    simulate_publish_verification_failure: bool = False,
    step_delay_seconds: float = 0.0,
) -> dict[str, object]:
    materialized = materialize_approved_release_bundle(
        definition=get_workflow("approved-release-bundle"),
        repo_path=repo_path,
        human_goal=human_goal,
        publish_path=publish_path,
        run_dir=run_dir,
        force_terminal_failure=force_terminal_failure,
        simulate_publish_verification_failure=simulate_publish_verification_failure,
        step_delay_seconds=step_delay_seconds,
    )
    return _run_materialized_workflow(
        materialized=materialized,
        result_filename="approved-release-bundle.json",
        open_viewer=open_viewer,
        browser_open=browser_open,
        viewer_hold_seconds=viewer_hold_seconds,
    )


def approve_approved_release_bundle(
    *, run_dir: Path, approval_packet: Path | None = None
) -> dict[str, object]:
    return _approve_transaction(
        run_dir=run_dir.expanduser().resolve(),
        workflow_id="approved-release-bundle",
        transaction_node_id="publish-approved-release",
        reason="Human approved the exact accepted release bundle for publication.",
        approval_packet=approval_packet,
    )


def resume_approved_release_bundle(*, run_dir: Path) -> dict[str, object]:
    resolved = run_dir.expanduser().resolve()
    request_path = resolved / "input" / "approved-release-request.json"
    request = _read_object(request_path, "approved release request")
    goal = request.get("goal")
    if not isinstance(goal, dict):
        raise RuntimeError("approved release request goal is missing")
    definition = get_workflow("approved-release-bundle")
    materialized = MaterializedWorkflow(
        definition=definition,
        request_path=request_path,
        source_dag_path=resolved / "workflow" / "dag.json",
        run_dir=resolved,
        run_id=str(_read_object(resolved / "workflow" / "dag.json", "workflow DAG")["run_id"]),
        goal=goal,
    )
    dag_receipt = run_generic_dag(spec_path=materialized.source_dag_path, resume=True)
    return _write_workflow_receipt(
        materialized,
        dag_receipt,
        result_filename="approved-release-bundle.json",
        viewer=None,
    )


def run_repository_evidence_map_workflow(
    *,
    repo_path: Path,
    human_goal: str,
    require_tests: bool,
    run_dir: Path,
    open_viewer: bool,
    browser_open: bool,
    viewer_hold_seconds: float | None,
    step_delay_seconds: float = 0.0,
) -> dict[str, object]:
    materialized = materialize_repository_evidence_map(
        definition=get_workflow("repository-evidence-map"),
        repo_path=repo_path,
        human_goal=human_goal,
        require_tests=require_tests,
        run_dir=run_dir,
        step_delay_seconds=step_delay_seconds,
    )
    return _run_materialized_workflow(
        materialized=materialized,
        result_filename="repository-evidence-map.json",
        open_viewer=open_viewer,
        browser_open=browser_open,
        viewer_hold_seconds=viewer_hold_seconds,
    )


def run_repository_readiness_workflow(
    *,
    repo_path: Path,
    human_goal: str,
    require_clean: bool,
    run_dir: Path,
    open_viewer: bool,
    browser_open: bool,
    viewer_hold_seconds: float | None,
    step_delay_seconds: float = 0.0,
) -> dict[str, object]:
    definition = get_workflow("repository-readiness")
    materialized = materialize_repository_readiness(
        definition=definition,
        repo_path=repo_path,
        human_goal=human_goal,
        require_clean=require_clean,
        run_dir=run_dir,
        step_delay_seconds=step_delay_seconds,
    )
    return _run_materialized_workflow(
        materialized=materialized,
        result_filename="repository-readiness.json",
        open_viewer=open_viewer,
        browser_open=browser_open,
        viewer_hold_seconds=viewer_hold_seconds,
    )


def run_tau_operator_reference_workflow(
    *,
    repo_path: Path,
    required_workflow: str,
    run_dir: Path,
    open_viewer: bool,
    browser_open: bool,
    viewer_hold_seconds: float | None,
    step_delay_seconds: float = 0.0,
) -> dict[str, object]:
    definition = get_workflow("tau-operator-reference")
    materialized = materialize_tau_operator_reference(
        definition=definition,
        repo_path=repo_path,
        required_workflow=required_workflow,
        run_dir=run_dir,
        step_delay_seconds=step_delay_seconds,
    )
    return _run_materialized_workflow(
        materialized=materialized,
        result_filename="tau-operator-reference.json",
        open_viewer=open_viewer,
        browser_open=browser_open,
        viewer_hold_seconds=viewer_hold_seconds,
    )


def _run_materialized_workflow(
    *,
    materialized: MaterializedWorkflow,
    result_filename: str,
    open_viewer: bool,
    browser_open: bool,
    viewer_hold_seconds: float | None,
    fault_injector: Callable[[str, Mapping[str, Any]], None] | None = None,
) -> dict[str, object]:
    if not open_viewer:
        dag_receipt = run_generic_dag(
            spec_path=materialized.source_dag_path,
            diagnostic_fault_injector=fault_injector,
        )
        return _write_workflow_receipt(
            materialized,
            dag_receipt,
            result_filename=result_filename,
            viewer=None,
        )

    outcome: dict[str, Any] = {}
    failure: list[BaseException] = []

    def run_workflow() -> None:
        try:
            outcome.update(
                run_generic_dag(
                    spec_path=materialized.source_dag_path,
                    diagnostic_fault_injector=fault_injector,
                )
            )
        except BaseException as exc:  # pragma: no cover - forwarded across thread boundary
            failure.append(exc)

    workflow_thread = threading.Thread(target=run_workflow, name="tau-workflow", daemon=True)
    workflow_thread.start()
    viewer = _wait_for_viewer(materialized.run_dir, workflow_thread, failure)
    viewer_thread = threading.Thread(target=viewer.serve_forever, name="tau-viewer", daemon=True)
    viewer_thread.start()
    if browser_open:
        webbrowser.open(viewer.url)
    workflow_thread.join()
    if failure:
        viewer.shutdown()
        viewer_thread.join(timeout=5)
        raise RuntimeError(f"{materialized.definition.workflow_id} workflow failed: {failure[0]}")
    receipt = _write_workflow_receipt(
        materialized,
        outcome,
        result_filename=result_filename,
        viewer=viewer,
    )
    try:
        if viewer_hold_seconds is not None:
            if viewer_hold_seconds < 0:
                raise RuntimeError("viewer_hold_seconds must be non-negative")
            time.sleep(viewer_hold_seconds)
        elif sys.stdin.isatty():
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        viewer.shutdown()
        viewer_thread.join(timeout=5)
    return receipt


def _write_workflow_repair_receipt(
    *,
    run_dir: Path,
    status: str,
    ok: bool,
    node_id: str,
    goal_hash: str,
    repair_packet_path: Path | None,
    approval_packet_path: Path | None,
    approval_gate_receipt_path: Path,
    errors: list[str],
) -> dict[str, object]:
    receipt = {
        "schema": "tau.workflow_repair_receipt.v1",
        "status": status,
        "ok": ok,
        "workflow_id": "durable-repository-qualification",
        "run_dir": str(run_dir),
        "node_id": node_id,
        "repair_packet_path": str(repair_packet_path) if repair_packet_path is not None else None,
        "approval_packet_path": (
            str(approval_packet_path) if approval_packet_path is not None else None
        ),
        "approval_gate_receipt_path": str(approval_gate_receipt_path),
        "goal_hash": goal_hash,
        "errors": errors,
    }
    output_path = run_dir / "input" / f"repair-{node_id}-receipt.json"
    _write_json(output_path, receipt)
    return receipt


def _wait_for_viewer(
    run_dir: Path,
    workflow_thread: threading.Thread,
    failure: list[BaseException],
) -> RunningDagViewerServer:
    deadline = time.monotonic() + 10
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        if failure:
            raise RuntimeError(f"packaged workflow failed: {failure[0]}")
        try:
            return create_dag_viewer_server(run_dir=run_dir, host="127.0.0.1", port=0)
        except (OSError, RuntimeError) as exc:
            last_error = exc
            time.sleep(0.05)
    raise RuntimeError(f"packaged workflow viewer did not become ready: {last_error}")


def _write_workflow_receipt(
    materialized: MaterializedWorkflow,
    dag_receipt: dict[str, Any],
    *,
    result_filename: str,
    viewer: RunningDagViewerServer | None,
) -> dict[str, object]:
    result_path = materialized.run_dir / "results" / result_filename
    result: dict[str, Any] | None = None
    if result_path.is_file():
        payload = json.loads(result_path.read_text(encoding="utf-8"))
        result = payload if isinstance(payload, dict) else None
    ok = dag_receipt.get("ok") is True and result is not None
    receipt: dict[str, object] = {
        "schema": WORKFLOW_RUN_RECEIPT_SCHEMA,
        "status": "PASS" if ok else "BLOCKED",
        "ok": ok,
        "mocked": dag_receipt.get("mocked") is True,
        "live": dag_receipt.get("live") is True,
        "provider_live": dag_receipt.get("provider_live") is True,
        "workflow_id": materialized.definition.workflow_id,
        "workflow_version": materialized.definition.workflow_version,
        "goal": materialized.goal,
        "source_dag_path": str(materialized.source_dag_path),
        "run_dir": str(materialized.run_dir),
        "run_receipt_path": str(materialized.run_dir / "run-receipt.json"),
        "cost_accounting": dag_receipt.get("cost_accounting")
        if isinstance(dag_receipt.get("cost_accounting"), dict)
        else None,
        "result": result,
        "viewer": {
            "command": ["tau", "dag-view", "--run-dir", str(materialized.run_dir)],
            "url": viewer.url if viewer is not None else None,
        },
        "proof_scope": {
            "proves": [
                f"Tau executed the packaged {materialized.definition.workflow_id} workflow.",
                "The requested repository inputs and goal are bound into the materialized DAG.",
            ],
            "does_not_prove": [
                "The repository test suite passes.",
                "Provider or model quality.",
                "Production deployment readiness.",
            ],
        },
    }
    path = materialized.run_dir / "workflow-receipt.json"
    path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return receipt


def _read_object(path: Path, label: str) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"{label} is unavailable: {exc}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError(f"{label} must be an object")
    return payload


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
