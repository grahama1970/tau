"""Tau coding-agent application package."""

from typing import TYPE_CHECKING, Any

from tau_coding.commands import (
    CommandRegistry,
    CommandResult,
    SlashCommand,
    create_default_command_registry,
)
from tau_coding.context import (
    discover_project_context,
    discover_project_context_with_diagnostics,
)
from tau_coding.context_window import (
    DEFAULT_COMPACTION_KEEP_RECENT_TOKENS,
    DEFAULT_COMPACTION_RESERVE_TOKENS,
    DEFAULT_CONTEXT_WINDOW_TOKENS,
    CONTEXT_MANIFEST_PREFIX,
    CONTEXT_MANIFEST_SCHEMA,
    GraphContextAssembly,
    MemoryContextOptions,
    PinnedContext,
    assemble_graph_context,
    SUMMARIZATION_SYSTEM_PROMPT,
    auto_compaction_threshold_for_context_window,
    build_compaction_summary_prompt,
    build_graph_context_compaction_summary,
    context_manifest_from_summary,
    context_messages_from_compaction_summary,
    estimate_context_tokens,
    estimate_message_tokens,
    estimate_text_tokens,
    estimate_tool_tokens,
    serialize_messages_for_compaction,
    summarize_messages_for_compaction,
)
from tau_coding.credentials import (
    CredentialStoreError,
    FileCredentialStore,
    OAuthCredential,
    credentials_path,
)
from tau_coding.loop_monitor import (
    LoopReceiptMonitorCheckResult,
    LoopReceiptMonitorResponse,
    LoopReceiptMonitorStream,
    check_loop_receipt_monitor_contract,
    create_loop_receipt_monitor_server,
    loop_receipt_monitor_response,
    loop_receipt_monitor_stream,
)
from tau_coding.loop_receipt import (
    LOOP2_EVENT_SCHEMA,
    LOOP_RECEIPT_CONTRACT_SCHEMA,
    LOOP_RECEIPT_CURRENT_STATE_SCHEMA,
    LOOP_RECEIPT_EVENTS_SCHEMA,
    LOOP_RECEIPT_FINAL_RECEIPT_SCHEMA,
    LOOP_RECEIPT_NODE_RESULT_SCHEMA,
    LOOP_RECEIPT_TRANSPORT_DAG_EVIDENCE_SCHEMA,
    LoopReceiptConfig,
    LoopReceiptRecorder,
    LoopReceiptRun,
    backfill_loop_receipt_artifact_index,
    loop_receipt_loop2_events,
    loop_receipt_summary,
    new_loop_receipt_run_id,
)
from tau_coding.loop_sanity import run_loop2_sanity
from tau_coding.loop_validation import (
    LoopReceiptValidationResult,
    validate_loop2_contract_file,
    validate_loop_receipt_with_loop2_contracts,
    validate_native_loop2_run_with_contracts,
)
from tau_coding.paths import TauPaths
from tau_coding.prompt_templates import (
    PromptTemplate,
    expand_prompt_template_command,
    load_prompt_templates,
    load_prompt_templates_with_diagnostics,
    render_prompt_template,
)
from tau_coding.provider_catalog import (
    BUILTIN_PROVIDER_CATALOG,
    ProviderCatalogEntry,
    builtin_provider_entry,
)
from tau_coding.provider_config import (
    DEFAULT_MODEL,
    DEFAULT_PROVIDER_NAME,
    AnthropicProviderConfig,
    OpenAICodexProviderConfig,
    OpenAICompatibleProviderConfig,
    ProviderConfig,
    ProviderConfigError,
    ProviderSelection,
    ProviderSettings,
    ScopedModelConfig,
    anthropic_config_from_provider,
    builtin_provider_configs,
    default_openai_provider_config,
    load_provider_settings,
    openai_compatible_config_from_provider,
    provider_config_from_catalog_entry,
    provider_default_thinking_level,
    provider_has_usable_credentials,
    provider_kind,
    provider_settings_path,
    provider_thinking_levels,
    provider_thinking_unavailable_reason,
    resolve_provider_selection,
    save_default_provider_model,
    save_provider_settings,
    toggle_saved_scoped_model,
    upsert_openai_compatible_provider,
    upsert_provider,
    upsert_saved_provider,
)
from tau_coding.resources import ResourceDiagnostic, ResourceError, TauResourcePaths
from tau_coding.session_export import (
    SessionExportError,
    default_session_export_path,
    export_session_html,
    render_session_html,
)
from tau_coding.session_manager import CodingSessionRecord, SessionManager
from tau_coding.skills import (
    Skill,
    build_skill_index,
    expand_skill_command,
    format_skill_invocation,
    load_skills,
    load_skills_with_diagnostics,
    parse_skill_invocation,
)
from tau_coding.system_prompt import (
    BuildSystemPromptOptions,
    ProjectContextFile,
    build_system_prompt,
    collect_prompt_guidelines,
    format_available_tools,
    format_guidelines,
    format_project_context,
    format_skills_for_prompt,
)
from tau_coding.thinking import (
    DEFAULT_THINKING_LEVEL,
    THINKING_LEVELS,
    ReasoningEffort,
    ThinkingLevel,
    ThinkingParameter,
    normalize_thinking_levels,
    reasoning_effort_for_level,
)
from tau_coding.tools import (
    ToolDefinition,
    create_bash_tool,
    create_bash_tool_definition,
    create_coding_tools,
    create_edit_tool,
    create_edit_tool_definition,
    create_find_tool,
    create_find_tool_definition,
    create_grep_tool,
    create_grep_tool_definition,
    create_ls_tool,
    create_ls_tool_definition,
    create_read_tool,
    create_read_tool_definition,
    create_write_tool,
    create_write_tool_definition,
)

try:
    from tau_coding.rendering import (
        EventRenderer,
        FinalTextRenderer,
        JsonEventRenderer,
        PrintOutputMode,
        TranscriptRenderer,
        create_event_renderer,
    )
except ModuleNotFoundError as exc:
    if exc.name != "textual":
        raise

    _rendering_import_error = exc
    EventRenderer = None  # type: ignore[assignment]
    FinalTextRenderer = None  # type: ignore[assignment]
    JsonEventRenderer = None  # type: ignore[assignment]
    PrintOutputMode = None  # type: ignore[assignment]
    TranscriptRenderer = None  # type: ignore[assignment]

    def create_event_renderer(*args: object, **kwargs: object) -> object:
        del args, kwargs
        raise RuntimeError(
            "Tau rendering requires the optional textual dependency"
        ) from _rendering_import_error

if TYPE_CHECKING:
    from tau_coding.session import (
        CodingSession,
        CodingSessionConfig,
        ModelChoice,
        SessionTreeBranchResult,
        SessionTreeChoice,
        default_session_path,
        jsonl_session_storage,
    )


_SESSION_EXPORT_NAMES = {
    "CodingSession",
    "CodingSessionConfig",
    "ModelChoice",
    "SessionTreeBranchResult",
    "SessionTreeChoice",
    "default_session_path",
    "jsonl_session_storage",
}


def __getattr__(name: str) -> Any:
    if name in _SESSION_EXPORT_NAMES:
        from tau_coding import session

        return getattr(session, name)
    raise AttributeError(f"module 'tau_coding' has no attribute {name!r}")


__version__ = "0.1.0"

__all__ = [
    "__version__",
    "CodingSession",
    "CodingSessionConfig",
    "CodingSessionRecord",
    "CommandRegistry",
    "CommandResult",
    "DEFAULT_MODEL",
    "DEFAULT_PROVIDER_NAME",
    "DEFAULT_THINKING_LEVEL",
    "BuildSystemPromptOptions",
    "BUILTIN_PROVIDER_CATALOG",
    "EventRenderer",
    "FinalTextRenderer",
    "JsonEventRenderer",
    "LOOP_RECEIPT_CONTRACT_SCHEMA",
    "LOOP_RECEIPT_CURRENT_STATE_SCHEMA",
    "LOOP_RECEIPT_EVENTS_SCHEMA",
    "LOOP_RECEIPT_FINAL_RECEIPT_SCHEMA",
    "LOOP_RECEIPT_NODE_RESULT_SCHEMA",
    "LOOP_RECEIPT_TRANSPORT_DAG_EVIDENCE_SCHEMA",
    "LOOP2_EVENT_SCHEMA",
    "LoopReceiptMonitorCheckResult",
    "LoopReceiptMonitorResponse",
    "LoopReceiptMonitorStream",
    "LoopReceiptConfig",
    "LoopReceiptRecorder",
    "LoopReceiptRun",
    "LoopReceiptValidationResult",
    "backfill_loop_receipt_artifact_index",
    "check_loop_receipt_monitor_contract",
    "create_loop_receipt_monitor_server",
    "loop_receipt_loop2_events",
    "loop_receipt_summary",
    "loop_receipt_monitor_response",
    "loop_receipt_monitor_stream",
    "run_loop2_sanity",
    "validate_loop2_contract_file",
    "validate_native_loop2_run_with_contracts",
    "validate_loop_receipt_with_loop2_contracts",
    "ModelChoice",
    "SessionTreeBranchResult",
    "SessionTreeChoice",
    "AnthropicProviderConfig",
    "OpenAICompatibleProviderConfig",
    "OpenAICodexProviderConfig",
    "OAuthCredential",
    "PrintOutputMode",
    "ProjectContextFile",
    "PromptTemplate",
    "ProviderCatalogEntry",
    "ProviderConfig",
    "ProviderConfigError",
    "ProviderSelection",
    "ProviderSettings",
    "ScopedModelConfig",
    "ResourceDiagnostic",
    "ResourceError",
    "SessionManager",
    "SessionExportError",
    "Skill",
    "SlashCommand",
    "TauPaths",
    "TauResourcePaths",
    "ToolDefinition",
    "TranscriptRenderer",
    "ThinkingLevel",
    "ThinkingParameter",
    "ReasoningEffort",
    "anthropic_config_from_provider",
    "build_skill_index",
    "build_system_prompt",
    "builtin_provider_configs",
    "builtin_provider_entry",
    "collect_prompt_guidelines",
    "CredentialStoreError",
    "expand_prompt_template_command",
    "create_bash_tool",
    "create_bash_tool_definition",
    "create_coding_tools",
    "create_edit_tool",
    "create_edit_tool_definition",
    "create_default_command_registry",
    "create_event_renderer",
    "create_find_tool",
    "create_find_tool_definition",
    "create_grep_tool",
    "create_grep_tool_definition",
    "create_ls_tool",
    "create_ls_tool_definition",
    "create_read_tool",
    "create_read_tool_definition",
    "create_write_tool",
    "create_write_tool_definition",
    "credentials_path",
    "default_session_path",
    "default_session_export_path",
    "default_openai_provider_config",
    "discover_project_context",
    "discover_project_context_with_diagnostics",
    "DEFAULT_COMPACTION_KEEP_RECENT_TOKENS",
    "DEFAULT_COMPACTION_RESERVE_TOKENS",
    "DEFAULT_CONTEXT_WINDOW_TOKENS",
    "CONTEXT_MANIFEST_PREFIX",
    "CONTEXT_MANIFEST_SCHEMA",
    "GraphContextAssembly",
    "MemoryContextOptions",
    "PinnedContext",
    "assemble_graph_context",
    "auto_compaction_threshold_for_context_window",
    "estimate_context_tokens",
    "estimate_message_tokens",
    "estimate_text_tokens",
    "estimate_tool_tokens",
    "build_compaction_summary_prompt",
    "build_graph_context_compaction_summary",
    "context_manifest_from_summary",
    "context_messages_from_compaction_summary",
    "serialize_messages_for_compaction",
    "SUMMARIZATION_SYSTEM_PROMPT",
    "THINKING_LEVELS",
    "summarize_messages_for_compaction",
    "expand_skill_command",
    "format_skill_invocation",
    "parse_skill_invocation",
    "format_available_tools",
    "format_guidelines",
    "format_project_context",
    "format_skills_for_prompt",
    "FileCredentialStore",
    "jsonl_session_storage",
    "load_provider_settings",
    "load_prompt_templates",
    "load_prompt_templates_with_diagnostics",
    "load_skills",
    "load_skills_with_diagnostics",
    "openai_compatible_config_from_provider",
    "provider_config_from_catalog_entry",
    "provider_default_thinking_level",
    "provider_has_usable_credentials",
    "provider_kind",
    "provider_settings_path",
    "provider_thinking_levels",
    "provider_thinking_unavailable_reason",
    "normalize_thinking_levels",
    "new_loop_receipt_run_id",
    "reasoning_effort_for_level",
    "render_prompt_template",
    "render_session_html",
    "resolve_provider_selection",
    "save_default_provider_model",
    "save_provider_settings",
    "toggle_saved_scoped_model",
    "export_session_html",
    "upsert_provider",
    "upsert_openai_compatible_provider",
    "upsert_saved_provider",
]
